import sys
import time
import random
import numpy as np
import cv2
import math
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla
import torch
from scipy.optimize import linear_sum_assignment

camera_image = None

# ============================================
# STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=8)
        self.prev_steer = 0.0
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        weights = np.linspace(0.5, 1.0, len(self.history))
        weighted_avg = np.average(list(self.history), weights=weights)
        smoothed = self.prev_steer + 0.15 * (weighted_avg - self.prev_steer)
        diff = smoothed - self.prev_steer
        if abs(diff) > 0.03:
            smoothed = self.prev_steer + 0.03 * np.sign(diff)
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        
    def get_speed_kmh(self):
        vel = self.vehicle.get_velocity()
        return 3.6 * math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
    
    def get_waypoints(self, count=12, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def get_steering(self, lookahead=5.0):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, False
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, True
        
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        return steering, True

# ============================================
# SIMPLE TRACKER
# ============================================

class SimpleTrack:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0

class SimpleTracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
        self.max_missed = 10
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(SimpleTrack(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        # Match detections to tracks
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.3
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        # Update missed tracks
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        # Add new tracks
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(SimpleTrack(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        # Remove old tracks
        self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
        
        return self.tracks

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts = [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 100, 0))
        frame = cv2.addWeighted(frame, 0.75, overlay, 0.25, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 2)
    
    return frame

def draw_tracks(frame, tracks):
    colors = {
        'car': (0, 255, 0),
        'truck': (0, 255, 0),
        'bus': (0, 255, 0),
        'person': (0, 0, 255),
        'bicycle': (255, 165, 0),
        'motorcycle': (255, 165, 0),
        'traffic light': (0, 255, 255),
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        color = colors.get(track.label, (255, 255, 255))
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        label = "ID" + str(track.id) + " " + track.label[:6]
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    # Load YOLOv5 - use pretrained COCO model (better for CARLA)
    print("Loading YOLOv5...")
    model = torch.hub.load(yolo_path, 'yolov5s', source='local', pretrained=True)
    model.conf = 0.5  # Higher confidence to reduce false positives
    model.classes = [0, 1, 2, 3, 5, 7, 9]  # person, bicycle, car, motorcycle, bus, truck, traffic light
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    # Use Town02 - simpler and lighter
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Smaller camera for performance
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn fewer NPCs (10 vehicles, 5 pedestrians)
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = blueprint_library.filter('vehicle.*')
    
    for i in range(1, min(11, len(spawn_points))):
        bp = random.choice(list(vehicle_bps))
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = blueprint_library.filter('walker.pedestrian.*')
    
    for i in range(5):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(list(walker_bps))
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    
    controller_bp = blueprint_library.find('controller.ai.walker')
    for walker in walkers:
        try:
            ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
            controllers.append(ctrl)
            ctrl.start()
            ctrl.go_to_location(world.get_random_location_from_navigation())
            ctrl.set_max_speed(1.2)
        except:
            pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = SimpleTracker()
    
    throttle = 0.28
    frame_count = 0
    detect_interval = 3  # Run YOLO every 3 frames
    current_tracks = []
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("AUTONOMOUS DRIVING (Lite)")
    print("========================================")
    print("Q - Quit | W/S - Speed")
    print("========================================")
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                frame_count += 1
                
                # Run YOLO every N frames (saves CPU)
                if frame_count % detect_interval == 0:
                    results = model(frame)
                    dets = results.pandas().xyxy[0]
                    
                    detections = []
                    for _, det in dets.iterrows():
                        # Filter by size (ignore tiny/huge detections)
                        bw = det['xmax'] - det['xmin']
                        bh = det['ymax'] - det['ymin']
                        if 20 < bw < 400 and 20 < bh < 400:
                            detections.append({
                                'bbox': [int(det['xmin']), int(det['ymin']), int(det['xmax']), int(det['ymax'])],
                                'label': det['name'],
                                'conf': det['confidence']
                            })
                    
                    current_tracks = tracker.update(detections)
                
                # Lane keeping
                raw_steer, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                
                # Check for obstacles in front
                brake = 0.0
                current_throttle = throttle
                danger = False
                
                for track in current_tracks:
                    x1, y1, x2, y2 = track.bbox
                    cx = (x1 + x2) // 2
                    
                    # Object in center and close (bottom of frame)
                    if 200 < cx < 440 and y2 > 380:
                        danger = True
                        if y2 > 420:
                            brake = 0.7
                            current_throttle = 0.0
                        else:
                            current_throttle = throttle * 0.5
                        break
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = current_throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                # Draw
                waypoints = lane_keeper.get_waypoints()
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks)
                
                # HUD
                speed = lane_keeper.get_speed_kmh()
                cv2.rectangle(frame, (5, 5), (180, 80), (0, 0, 0), -1)
                cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Objects: " + str(len(current_tracks)), (10, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                if danger:
                    cv2.putText(frame, "!! OBSTACLE !!", (250, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                
                cv2.imshow('Autonomous Driving', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.45, throttle + 0.02)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('s'):
                throttle = max(0.15, throttle - 0.02)
                print("Throttle: " + str(round(throttle, 2)))
                
    finally:
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()