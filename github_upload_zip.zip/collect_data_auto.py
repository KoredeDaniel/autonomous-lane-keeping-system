import sys
import os
import random
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

data_dir = r"c:\users\CARLACODES\1_code\data"
images_dir = os.path.join(data_dir, "images")
labels_dir = os.path.join(data_dir, "labels")

for folder in [data_dir, images_dir, labels_dir]:
    if not os.path.exists(folder):
        os.makedirs(folder)

camera_image = None
image_count = 0

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    array = array[:, :, :3]
    camera_image = array

def main():
    global camera_image, image_count
    
    TARGET_IMAGES = 150
    SAVE_INTERVAL = 0.5  # Save every 0.5 seconds
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    vehicle.set_autopilot(True)
    print("Ego vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda image: process_image(image))
    print("Camera attached!")
    
    npc_vehicles = []
    vehicle_bps = blueprint_library.filter('vehicle.*')
    for i in range(1, min(31, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " NPC vehicles")
    
    walkers = []
    controllers = []
    walker_bps = blueprint_library.filter('walker.pedestrian.*')
    for i in range(20):
        loc = world.get_random_location_from_navigation()
        if loc is not None:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    
    controller_bp = blueprint_library.find('controller.ai.walker')
    for walker in walkers:
        try:
            controller = world.spawn_actor(controller_bp, carla.Transform(), walker)
            controllers.append(controller)
            controller.start()
            controller.go_to_location(world.get_random_location_from_navigation())
            controller.set_max_speed(1.5)
        except:
            pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("AUTO DATA COLLECTION")
    print("========================================")
    print("Collecting " + str(TARGET_IMAGES) + " images automatically")
    print("Press Q to stop early")
    print("========================================")
    print("")
    
    last_save = time.time()
    
    try:
        while image_count < TARGET_IMAGES:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Auto save every SAVE_INTERVAL seconds
                if time.time() - last_save >= SAVE_INTERVAL:
                    filename = "carla_" + str(image_count).zfill(4) + ".jpg"
                    filepath = os.path.join(images_dir, filename)
                    cv2.imwrite(filepath, camera_image)
                    image_count += 1
                    last_save = time.time()
                    print("Saved: " + filename + " (" + str(image_count) + "/" + str(TARGET_IMAGES) + ")")
                
                text = "Auto-saving: " + str(image_count) + "/" + str(TARGET_IMAGES) + " | Q=quit"
                cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                
                cv2.imshow('Auto Data Collection', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    finally:
        print("")
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        
        for c in controllers:
            c.stop()
            c.destroy()
        for w in walkers:
            w.destroy()
        for v in npc_vehicles:
            v.destroy()
        
        cv2.destroyAllWindows()
        print("")
        print("========================================")
        print("DONE! Collected " + str(image_count) + " images")
        print("Images saved in: " + images_dir)
        print("========================================")

if __name__ == "__main__":
    main()