# -*- coding: utf-8 -*-
import sys
import os
import time
import numpy as np
import cv2
import torch

# ---- CARLA egg path ----
carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)
import carla

# ---- ByteTrack ----
from bytetrack.byte_tracker import BYTETracker

# ---- Globals ----
camera_image = None

# BDD class names (your trained dataset)
# 0 vehicle, 1 pedestrian, 2 traffic_light, 3 traffic_sign
NAMES = ['vehicle', 'pedestrian', 'traffic_light', 'traffic_sign']

# Step 0 tuning
MIN_AREA = 30 * 30          # Base tiny-box filter
TRACK_CLASSES = None        # Set to {0,1} to only track vehicle+pedestrian (cleanest demo)

def process_image(image):
    global camera_image
    arr = np.frombuffer(image.raw_data, dtype=np.uint8)
    arr = arr.reshape((image.height, image.width, 4))
    camera_image = arr[:, :, :3].copy()

def filter_carla_dets(dets, w, h):
    """
    Aggressive CARLA-specific filtering to reduce:
    - buildings/houses detected as vehicles
    - trees/streetlights detected as traffic_lights
    dets: Nx6 [x1,y1,x2,y2,conf,cls]
    """
    if dets is None or dets.shape[0] == 0:
        return dets

    out = []
    frame_area = float(w * h)

    for d in dets:
        x1, y1, x2, y2, conf, cls_id = d
        cls_id = int(cls_id)
        conf = float(conf)

        bw = float(x2 - x1)
        bh = float(y2 - y1)
        if bw <= 1 or bh <= 1:
            continue

        area = bw * bh
        aspect = bw / (bh + 1e-6)  # width/height
        cx = 0.5 * (x1 + x2)
        cy = 0.5 * (y1 + y2)

        # Reject extreme edges (artefacts/buildings/poles at edges)
        if cx < 0.03 * w or cx > 0.97 * w:
            continue

        # Global reject: very large boxes are rarely valid
        if area > 0.20 * frame_area:
            continue

        # -------------------------
        # VEHICLE (cls 0)
        # -------------------------
        if cls_id == 0:
            # A bit higher conf for CARLA (reduces building-like hits)
            if conf < 0.50:
                continue

            # Road ROI (key anti-house rule)
            if y1 < 0.45 * h:
                continue
            if y2 < 0.55 * h:
                continue

            # Vehicle-like geometry
            if aspect < 0.9 or aspect > 3.2:
                continue

            # Building-like geometry
            if bh > 0.45 * h:
                continue
            if bw > 0.75 * w:
                continue

            # Too small -> noise
            if area < MIN_AREA:
                continue

        # -------------------------
        # PEDESTRIAN (cls 1)
        # -------------------------
        elif cls_id == 1:
            if conf < 0.45:
                continue
            if y1 < 0.30 * h:
                continue
            # people are taller than wide -> width/height should be small
            if aspect > 0.75:
                continue
            if bh < 50:
                continue
            if area > 0.12 * frame_area:
                continue

        # -------------------------
        # TRAFFIC LIGHT (cls 2)
        # -------------------------
        elif cls_id == 2:
            # Make this STRICT to prevent trees/poles/street lamps being classified as TL
            if conf < 0.60:
                continue

            # Traffic lights should be in upper/mid upper part of image
            # (too low often means poles/street lamps close to camera)
            if y2 > 0.60 * h:
                continue
            if y1 < 0.02 * h:
                # if it's extremely top-edge clipped, usually false
                continue

            # Must be small-ish
            if area < 12 * 12:
                continue
            if area > 0.008 * frame_area:   # very small fraction of frame
                continue

            # Must be "tall-ish": width/height should be <= ~0.9
            # Street lamps/poles can be too thin (very small aspect),
            # but most false positives from trees are wider blobs (aspect too large)
            if aspect > 0.90:
                continue

            # Also reject very elongated vertical poles (super thin)
            if aspect < 0.10:
                continue

            # Usually closer to the road center in forward camera
            if cx < 0.12 * w or cx > 0.88 * w:
                continue

        # -------------------------
        # TRAFFIC SIGN (cls 3)
        # -------------------------
        elif cls_id == 3:
            if conf < 0.55:
                continue

            # Signs are typically upper/middle, not extreme bottom
            if y2 > 0.75 * h:
                continue
            if y1 < 0.05 * h:
                continue

            if area < 14 * 14:
                continue
            if area > 0.02 * frame_area:
                continue

            if aspect < 0.35 or aspect > 2.2:
                continue

        else:
            continue

        out.append(d)

    if len(out) == 0:
        return np.zeros((0, 6), dtype=np.float32)

    return np.stack(out, axis=0).astype(np.float32)

def main():
    global camera_image

    yolov5_root = r"C:\Users\CARLACODES\1_code\yolov5"
    weights = os.path.join(yolov5_root, r"runs\train\yolov5n_bdd100k_src\weights\best.pt")

    print("[INFO] Loading YOLO weights:", weights)
    model = torch.hub.load(yolov5_root, 'custom', path=weights, source='local')

    # Tighten thresholds to reduce false positives
    model.conf = 0.45   # base threshold (class-specific thresholds are in filter)
    model.iou = 0.40
    model.max_det = 200

    print("[INFO] YOLO ready.")
    tracker = BYTETracker(track_thresh=0.5, match_thresh=0.8, low_thresh=0.1, max_time_lost=30)
    print("[INFO] ByteTrack ready.")

    # ---- Connect CARLA ----
    print("[INFO] Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    bp_lib = world.get_blueprint_library()
    print("[INFO] Connected.")

    # ---- Spawn ego vehicle (autopilot ON for now) ----
    spawn_points = world.get_map().get_spawn_points()
    vehicle_bp = bp_lib.filter('vehicle.tesla.model3')[0]
    ego = world.spawn_actor(vehicle_bp, spawn_points[0])
    ego.set_autopilot(True)
    print("[INFO] Ego vehicle spawned (autopilot ON).")

    # ---- Camera ----
    cam_bp = bp_lib.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', '800')
    cam_bp.set_attribute('image_size_y', '600')
    cam_bp.set_attribute('fov', '90')
    cam_tf = carla.Transform(carla.Location(x=2.0, z=1.4))
    cam = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    cam.listen(process_image)
    print("[INFO] Camera attached.")

    cv2.namedWindow("CARLA YOLO + ByteTrack (LIVE)", cv2.WINDOW_NORMAL)

    try:
        # wait for first frame
        for _ in range(80):
            time.sleep(0.05)
            if camera_image is not None:
                break

        print("[INFO] Running. Press Q to quit.")
        while True:
            if camera_image is None:
                continue

            frame = camera_image.copy()
            h, w = frame.shape[:2]

            # YOLO inference -> dets = [x1,y1,x2,y2,conf,cls]
            res = model(frame, size=640)
            dets = res.xyxy[0].cpu().numpy() if len(res.xyxy) else np.zeros((0, 6), dtype=np.float32)

            # Aggressive CARLA filter (anti-house + anti-tree-as-trafficlight)
            dets = filter_carla_dets(dets, w, h)

            # Optional: track only specific classes
            if dets.shape[0] > 0 and TRACK_CLASSES is not None:
                cls_ids_tmp = dets[:, 5].astype(np.int32)
                keep = np.array([c in TRACK_CLASSES for c in cls_ids_tmp], dtype=bool)
                dets = dets[keep]

            # Prepare ByteTrack inputs
            if dets.shape[0] > 0:
                tlbr = dets[:, 0:4].astype(np.float32)
                scores = dets[:, 4].astype(np.float32)
                cls_ids = dets[:, 5].astype(np.int32)
            else:
                tlbr = np.zeros((0, 4), dtype=np.float32)
                scores = np.zeros((0,), dtype=np.float32)
                cls_ids = np.zeros((0,), dtype=np.int32)

            tracks = tracker.update(tlbr, scores, cls_ids)

            # Draw tracks
            for t in tracks:
                x, y, bw, bh = t.tlwh
                x1, y1, x2, y2 = int(x), int(y), int(x + bw), int(y + bh)
                tid = int(t.track_id)
                cid = int(t.cls_id) if t.cls_id is not None else -1
                label = NAMES[cid] if 0 <= cid < len(NAMES) else f"class{cid}"

                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, f"ID {tid} {label}", (x1, max(0, y1 - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 2)

            cv2.imshow("CARLA YOLO + ByteTrack (LIVE)", frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    finally:
        print("[INFO] Cleaning up...")
        try:
            cam.stop()
            cam.destroy()
        except Exception:
            pass
        try:
            ego.destroy()
        except Exception:
            pass
        cv2.destroyAllWindows()
        print("[DONE]")

if __name__ == "__main__":
    main()