import sys
import time
import random
import numpy as np
import cv2
import torch

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

def filter_detections(results, frame_width, frame_height):
    """Strict filtering to remove false positives"""
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        label = det['name']
        conf = det['confidence']
        
        box_width = x2 - x1
        box_height = y2 - y1
        box_area = box_width * box_height
        frame_area = frame_width * frame_height
        aspect_ratio = box_width / box_height if box_height > 0 else 0
        
        # 1. High confidence only
        if conf < 0.6:
            continue
        
        # 2. Ignore detections in top 25% of frame (sky, buildings)
        if y1 < frame_height * 0.25:
            continue
        
        # 3. Size constraints
        if box_width < 30 or box_height < 30:
            continue
        if box_area > frame_area * 0.5:
            continue
        
        # 4. Vehicle-specific filters
        if label == 'vehicle':
            if aspect_ratio < 0.5 or aspect_ratio > 4.0:
                continue
            if y1 < frame_height * 0.3:
                continue
        
        # 5. Pedestrian-specific filters
        if label == 'pedestrian':
            if aspect_ratio > 1.0:
                continue
            if box_height < 50:
                continue
        
        # 6. Ignore if detection spans almost full width
        if box_width > frame_width * 0.7:
            continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Loading YOLOv5 (BDD100K)...")
    model_path = r"c:\users\CARLACODES\1_code\yolov5\runs\train\exp3\weights\best.pt"
    model = torch.hub.load(yolo_path, 'custom', path=model_path, source='local')
    model.conf = 0.5
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPC vehicles
    print("Spawning NPC vehicles...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(10, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    if camera_image is None:
        print("ERROR: Camera not receiving images!")
        camera.destroy()
        vehicle.destroy()
        return
    
    print("")
    print("========================================")
    print("YOLO DETECTION TEST (Filtered)")
    print("========================================")
    print("Q - Quit")
    print("========================================")
    
    # Create window
    cv2.namedWindow('YOLO Test', cv2.WINDOW_NORMAL)
    
    control = carla.VehicleControl()
    control.throttle = 0.3
    
    try:
        while True:
            world.tick()
            vehicle.apply_control(control)
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # Run YOLO
                results = model(frame)
                
                raw_dets = results.pandas().xyxy[0]
                raw_count = len(raw_dets)
                
                filtered_dets = filter_detections(results, w, h)
                
                colors = {
                    'vehicle': (0, 255, 0),
                    'pedestrian': (0, 0, 255),
                    'traffic_light': (0, 255, 255),
                    'traffic_sign': (255, 0, 255)
                }
                
                for det in filtered_dets:
                    x1, y1, x2, y2 = det['bbox']
                    label = det['label']
                    conf = det['conf']
                    color = colors.get(label, (255, 255, 255))
                    
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    text = label + " " + str(round(conf, 2))
                    cv2.putText(frame, text, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                cv2.rectangle(frame, (5, 5), (250, 70), (0, 0, 0), -1)
                cv2.putText(frame, "YOLO Detection Test", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(frame, "Raw: " + str(raw_count) + " | Filtered: " + str(len(filtered_dets)), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                cv2.imshow('YOLO Test', frame)
            
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                break
                
    finally:
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()