# -*- coding: utf-8 -*-
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional


@dataclass
class TrackedObject:
    track_id: int
    cls: int                 # 0 vehicle, 1 pedestrian, 2 traffic_light, 3 traffic_sign
    label: str
    score: float
    bbox: List[int]          # [x1,y1,x2,y2]
    hits: int
    age: int
    in_corridor: bool
    bottom_y: int
    center_x: int


@dataclass
class SceneState:
    frame_id: int
    speed_kmh: float
    cte_m: float
    steer: float
    curvature: float

    traffic_light_state: str   # RED|YELLOW|GREEN|NONE
    objects_ahead: List[TrackedObject]

    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        # dataclasses nested are already dictified by asdict
        return d

    def compact_text(self, max_objects: int = 5) -> str:
        objs = sorted(self.objects_ahead, key=lambda o: o.bottom_y, reverse=True)[:max_objects]
        lines = []
        lines.append(f"speed_kmh={self.speed_kmh:.1f}, cte_m={self.cte_m:.2f}, steer={self.steer:.3f}, curvature={self.curvature:.3f}")
        lines.append(f"traffic_light={self.traffic_light_state}")
        if len(objs) == 0:
            lines.append("objects_ahead: none")
        else:
            lines.append("objects_ahead:")
            for o in objs:
                lines.append(
                    f"- id={o.track_id}, label={o.label}, score={o.score:.2f}, hits={o.hits}, in_corridor={o.in_corridor}, bottom_y={o.bottom_y}"
                )
        if self.notes:
            lines.append(f"notes={self.notes}")
        return "\n".join(lines)