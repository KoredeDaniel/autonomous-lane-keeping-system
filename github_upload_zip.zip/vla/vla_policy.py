# -*- coding: utf-8 -*-
import json
from typing import Dict, Any, Tuple
from .scene_state import SceneState


class VLAReasoner:
    """
    VLA-inspired decision module.
    Default: deterministic policy that produces a language explanation.
    Optional: you can plug an LLM later by implementing call_llm().
    """

    def __init__(self, mode: str = "heuristic"):
        self.mode = mode  # "heuristic" or "llm"

    def decide(self, scene: SceneState) -> Dict[str, Any]:
        if self.mode == "llm":
            try:
                return self._decide_llm(scene)
            except Exception:
                # Fail-safe fallback
                return self._decide_heuristic(scene, notes="llm_failed_fallback")
        return self._decide_heuristic(scene)

    def _decide_heuristic(self, scene: SceneState, notes: str = "") -> Dict[str, Any]:
        tl = scene.traffic_light_state.upper()

        # Find closest corridor object (highest bottom_y)
        corridor_objs = [o for o in scene.objects_ahead if o.in_corridor and o.label in ["vehicle", "pedestrian"]]
        corridor_objs = sorted(corridor_objs, key=lambda o: o.bottom_y, reverse=True)
        closest = corridor_objs[0] if corridor_objs else None

        # Curvature based speed suggestion
        if scene.curvature > 0.10:
            curve_cap = 18.0
        elif scene.curvature > 0.06:
            curve_cap = 25.0
        else:
            curve_cap = 35.0

        # Traffic light intent
        if tl == "RED":
            return {
                "action": "STOP",
                "target_speed_kmh": 0.0,
                "reason": "Traffic light is RED. Full stop required.",
                "notes": notes
            }
        if tl == "YELLOW":
            base = min(curve_cap, 12.0)
            return {
                "action": "YIELD",
                "target_speed_kmh": base,
                "reason": "Traffic light is YELLOW. Slow down and prepare to stop.",
                "notes": notes
            }

        # Object intent
        if closest is not None:
            # bottom_y is a proxy for closeness in image
            by = closest.bottom_y
            # thresholds tuned for 640x480
            if by > 395:
                return {
                    "action": "STOP",
                    "target_speed_kmh": 0.0,
                    "reason": f"{closest.label} is very close in lane corridor. Emergency stop.",
                    "notes": notes
                }
            if by > 345:
                return {
                    "action": "SLOW",
                    "target_speed_kmh": min(curve_cap, 10.0),
                    "reason": f"{closest.label} ahead in lane corridor. Strong deceleration.",
                    "notes": notes
                }
            if by > 290:
                return {
                    "action": "FOLLOW",
                    "target_speed_kmh": min(curve_cap, 18.0),
                    "reason": f"{closest.label} ahead. Following at reduced speed.",
                    "notes": notes
                }

        # Lane stability intent
        if abs(scene.cte_m) > 0.9:
            return {
                "action": "SLOW",
                "target_speed_kmh": min(curve_cap, 15.0),
                "reason": "High cross-track error. Reduce speed to stabilise lane keeping.",
                "notes": notes
            }

        return {
            "action": "CRUISE",
            "target_speed_kmh": curve_cap,
            "reason": "Road is clear. Maintain cruise speed within curvature limits.",
            "notes": notes
        }

    def _decide_llm(self, scene: SceneState) -> Dict[str, Any]:
        """
        Optional later. Keep this stub for dissertation.
        If you want to connect to a local LLM server, implement call_llm().

        Must return JSON dict:
          { action, target_speed_kmh, reason }
        """
        prompt = self._build_prompt(scene)
        _ = prompt  # placeholder to avoid lint warnings
        raise RuntimeError("LLM mode is not implemented yet.")

    def _build_prompt(self, scene: SceneState) -> str:
        schema = {
            "action": "STOP|YIELD|SLOW|FOLLOW|CRUISE",
            "target_speed_kmh": "number",
            "reason": "short string"
        }
        return (
            "You are an autonomous driving decision module.\n"
            "Given the scene state, output ONLY a valid JSON object matching this schema:\n"
            f"{json.dumps(schema)}\n\n"
            "Scene state:\n"
            f"{json.dumps(scene.to_dict())}\n"
        )