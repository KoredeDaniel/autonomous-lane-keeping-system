import sys
import os
import random
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla
import torch

camera_image = None

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    array = array[:, :, :3]
    camera_image = array

def main():
    global camera_image
    
    print("Loading custom trained model...")
    custom_weights = r"c:\users\CARLACODES\1_code\yolov5\runs\train\exp2\weights\best.pt"
    model = torch.hub.load(yolo_path, 'custom', path=custom_weights, source='local')
    model.conf = 0.25  # Lower confidence
    print("Custom model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    vehicle.set_autopilot(True)
    print("Ego vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda image: process_image(image))
    print("Camera attached!")
    
    npc_vehicles = []
    vehicle_bps = blueprint_library.filter('vehicle.*')
    for i in range(1, min(21, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " NPC vehicles")
    
    walkers = []
    controllers = []
    walker_bps = blueprint_library.filter('walker.pedestrian.*')
    for i in range(15):
        loc = world.get_random_location_from_navigation()
        if loc is not None:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    
    controller_bp = blueprint_library.find('controller.ai.walker')
    for walker in walkers:
        try:
            controller = world.spawn_actor(controller_bp, carla.Transform(), walker)
            controllers.append(controller)
            controller.start()
            controller.go_to_location(world.get_random_location_from_navigation())
            controller.set_max_speed(1.5)
        except:
            pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    print("")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("Press Q to quit")
    print("")
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                results = model(frame)
                dets = results.pandas().xyxy[0]
                
                for idx, det in dets.iterrows():
                    x1 = int(det['xmin'])
                    y1 = int(det['ymin'])
                    x2 = int(det['xmax'])
                    y2 = int(det['ymax'])
                    conf = det['confidence']
                    label = det['name']
                    
                    color = (0, 255, 0)
                    if label == 'pedestrian':
                        color = (255, 0, 0)
                    elif label == 'traffic_light':
                        color = (0, 255, 255)
                    
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    text = label + " " + str(round(conf, 2))
                    cv2.putText(frame, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                info = "Detections: " + str(len(dets))
                cv2.putText(frame, info, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                
                cv2.imshow('Custom YOLOv5 Test', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    finally:
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        
        for c in controllers:
            c.stop()
            c.destroy()
        for w in walkers:
            w.destroy()
        for v in npc_vehicles:
            v.destroy()
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()