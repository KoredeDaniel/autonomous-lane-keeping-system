import os
import json
import shutil

# Paths
base_dir = os.path.expanduser("~/Downloads")
output_dir = os.path.expanduser("~/Desktop/bdd100k_yolo")

# Class mapping
class_map = {
    "car": 0,
    "bus": 0,
    "truck": 0,
    "vehicle": 0,
    "person": 1,
    "pedestrian": 1,
    "rider": 1,
    "bike": 1,
    "motor": 1,
    "traffic light": 2,
    "traffic sign": 3
}

def convert_to_yolo(json_path, img_width, img_height):
    with open(json_path, 'r') as f:
        data = json.load(f)
    
    lines = []
    for obj in data.get("objects", []):
        class_title = obj.get("classTitle", "").lower()
        geometry = obj.get("geometryType", "")
        
        if geometry != "rectangle":
            continue
        
        if class_title not in class_map:
            continue
        
        class_id = class_map[class_title]
        points = obj.get("points", {}).get("exterior", [])
        
        if len(points) != 2:
            continue
        
        x1, y1 = points[0]
        x2, y2 = points[1]
        
        x_center = ((x1 + x2) / 2) / img_width
        y_center = ((y1 + y2) / 2) / img_height
        width = abs(x2 - x1) / img_width
        height = abs(y2 - y1) / img_height
        
        x_center = max(0, min(1, x_center))
        y_center = max(0, min(1, y_center))
        width = max(0, min(1, width))
        height = max(0, min(1, height))
        
        lines.append(f"{class_id} {x_center:.6f} {y_center:.6f} {width:.6f} {height:.6f}")
    
    return lines

def process_split(split_name, max_images=500):
    img_dir = os.path.join(base_dir, split_name, "img")
    ann_dir = os.path.join(base_dir, split_name, "ann")
    
    out_img_dir = os.path.join(output_dir, split_name, "images")
    out_lbl_dir = os.path.join(output_dir, split_name, "labels")
    
    os.makedirs(out_img_dir, exist_ok=True)
    os.makedirs(out_lbl_dir, exist_ok=True)
    
    count = 0
    for img_file in os.listdir(img_dir):
        if count >= max_images:
            break
        
        if not img_file.endswith(('.jpg', '.png')):
            continue
        
        json_file = img_file + ".json"
        json_path = os.path.join(ann_dir, json_file)
        
        if not os.path.exists(json_path):
            continue
        
        with open(json_path, 'r') as f:
            data = json.load(f)
        
        img_width = data.get("size", {}).get("width", 1280)
        img_height = data.get("size", {}).get("height", 720)
        
        yolo_lines = convert_to_yolo(json_path, img_width, img_height)
        
        if len(yolo_lines) == 0:
            continue
        
        shutil.copy(os.path.join(img_dir, img_file), os.path.join(out_img_dir, img_file))
        
        label_file = img_file.rsplit('.', 1)[0] + ".txt"
        with open(os.path.join(out_lbl_dir, label_file), 'w') as f:
            f.write("\n".join(yolo_lines))
        
        count += 1
        if count % 50 == 0:
            print(f"  Processed {count} images")
    
    print(f"  {split_name}: {count} images converted")
    return count

def main():
    print("Converting BDD100K to YOLO format...")
    print("")
    
    if os.path.exists(output_dir):
        shutil.rmtree(output_dir)
    
    train_count = process_split("train", max_images=500)
    val_count = process_split("val", max_images=100)
    
    yaml_content = f"""train: {output_dir}/train/images
val: {output_dir}/val/images

nc: 4
names: ['vehicle', 'pedestrian', 'traffic_light', 'traffic_sign']
"""
    
    yaml_path = os.path.join(output_dir, "data.yaml")
    with open(yaml_path, 'w') as f:
        f.write(yaml_content)
    
    print("")
    print("========================================")
    print("CONVERSION COMPLETE!")
    print("========================================")
    print(f"Train images: {train_count}")
    print(f"Val images: {val_count}")
    print(f"Output: {output_dir}")
    print("")
    print("Now copy this folder to Windows and train!")

if __name__ == "__main__":
    main()