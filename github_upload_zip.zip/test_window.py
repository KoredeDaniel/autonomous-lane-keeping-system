import numpy as np
import cv2

print("Creating test window...")
print("Press Q to close")

img = np.zeros((400, 600, 3), dtype=np.uint8)
cv2.putText(img, "OpenCV Window Test", (100, 200), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

while True:
    cv2.imshow('Test Window', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()
print("Done!")