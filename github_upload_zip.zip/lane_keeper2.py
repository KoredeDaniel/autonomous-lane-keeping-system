import sys
import os
import random
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-1.0, min(1.0, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

class LaneDetector:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.prev_left = None
        self.prev_right = None
    
    def filter_lane_colors(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        
        # White lane detection
        lower_white = np.array([0, 0, 200])
        upper_white = np.array([180, 30, 255])
        white_mask = cv2.inRange(hsv, lower_white, upper_white)
        
        # Yellow lane detection
        lower_yellow = np.array([15, 80, 100])
        upper_yellow = np.array([35, 255, 255])
        yellow_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)
        
        # Combine masks
        combined = cv2.bitwise_or(white_mask, yellow_mask)
        
        return combined
    
    def region_of_interest(self, img):
        height, width = img.shape[:2]
        
        # Tighter trapezoid focusing on road ahead
        polygons = np.array([
            [(int(width * 0.1), height),
             (int(width * 0.4), int(height * 0.55)),
             (int(width * 0.6), int(height * 0.55)),
             (int(width * 0.9), height)]
        ])
        
        mask = np.zeros_like(img)
        cv2.fillPoly(mask, polygons, 255)
        masked = cv2.bitwise_and(img, mask)
        return masked
    
    def detect_lanes(self, frame):
        # Filter for lane colors
        color_mask = self.filter_lane_colors(frame)
        
        # Apply region of interest
        roi = self.region_of_interest(color_mask)
        
        # Apply morphological operations to clean up
        kernel = np.ones((3, 3), np.uint8)
        roi = cv2.morphologyEx(roi, cv2.MORPH_CLOSE, kernel)
        roi = cv2.morphologyEx(roi, cv2.MORPH_OPEN, kernel)
        
        # Detect lines
        lines = cv2.HoughLinesP(
            roi,
            rho=1,
            theta=np.pi/180,
            threshold=30,
            minLineLength=40,
            maxLineGap=100
        )
        
        return lines, roi
    
    def separate_lines(self, lines, frame):
        left_lines = []
        right_lines = []
        
        if lines is None:
            return left_lines, right_lines
        
        height, width = frame.shape[:2]
        center_x = width // 2
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            if x2 - x1 == 0:
                continue
            
            slope = (y2 - y1) / (x2 - x1)
            
            # Filter by slope - lanes should have significant slope
            if abs(slope) < 0.4 or abs(slope) > 3.0:
                continue
            
            # Calculate line center
            line_center_x = (x1 + x2) / 2
            
            # Left lane: negative slope, on left side
            if slope < 0 and line_center_x < center_x:
                left_lines.append(line[0])
            # Right lane: positive slope, on right side
            elif slope > 0 and line_center_x > center_x:
                right_lines.append(line[0])
        
        return left_lines, right_lines
    
    def fit_line(self, lines, frame):
        if len(lines) == 0:
            return None
        
        # Collect all points
        x_coords = []
        y_coords = []
        
        for line in lines:
            x1, y1, x2, y2 = line
            x_coords.extend([x1, x2])
            y_coords.extend([y1, y2])
        
        if len(x_coords) < 2:
            return None
        
        # Fit a line using polyfit
        try:
            coeffs = np.polyfit(y_coords, x_coords, 1)
        except:
            return None
        
        height = frame.shape[0]
        
        # Calculate x for bottom and middle of frame
        y1 = height
        y2 = int(height * 0.55)
        
        x1 = int(coeffs[0] * y1 + coeffs[1])
        x2 = int(coeffs[0] * y2 + coeffs[1])
        
        return [x1, y1, x2, y2]
    
    def smooth_line(self, current, previous, alpha=0.7):
        if current is None:
            return previous
        if previous is None:
            return current
        
        smoothed = []
        for c, p in zip(current, previous):
            smoothed.append(int(alpha * c + (1 - alpha) * p))
        return smoothed
    
    def calculate_center_offset(self, left_line, right_line, frame):
        height, width = frame.shape[:2]
        car_center = width // 2
        
        if left_line is not None and right_line is not None:
            left_x = left_line[0]
            right_x = right_line[0]
            lane_center = (left_x + right_x) // 2
        elif left_line is not None:
            lane_center = left_line[0] + 180
        elif right_line is not None:
            lane_center = right_line[0] - 180
        else:
            return 0, False
        
        offset = (lane_center - car_center) / (width / 2)
        return offset, True
    
    def draw_lanes(self, frame, left_line, right_line, roi_mask):
        overlay = frame.copy()
        
        # Draw ROI boundary
        height, width = frame.shape[:2]
        roi_pts = np.array([
            [(int(width * 0.1), height),
             (int(width * 0.4), int(height * 0.55)),
             (int(width * 0.6), int(height * 0.55)),
             (int(width * 0.9), height)]
        ], np.int32)
        cv2.polylines(overlay, roi_pts, True, (100, 100, 100), 2)
        
        # Draw lane lines
        if left_line is not None:
            cv2.line(overlay, (left_line[0], left_line[1]), (left_line[2], left_line[3]), (255, 0, 0), 8)
        
        if right_line is not None:
            cv2.line(overlay, (right_line[0], right_line[1]), (right_line[2], right_line[3]), (0, 0, 255), 8)
        
        # Draw lane area
        if left_line is not None and right_line is not None:
            pts = np.array([
                [left_line[0], left_line[1]],
                [left_line[2], left_line[3]],
                [right_line[2], right_line[3]],
                [right_line[0], right_line[1]]
            ], np.int32)
            lane_overlay = frame.copy()
            cv2.fillPoly(lane_overlay, [pts], (0, 255, 0))
            overlay = cv2.addWeighted(overlay, 0.8, lane_overlay, 0.2, 0)
        
        return overlay
    
    def process(self, frame):
        # Detect lanes
        lines, roi = self.detect_lanes(frame)
        
        # Separate left and right
        left_lines, right_lines = self.separate_lines(lines, frame)
        
        # Fit lines
        left_line = self.fit_line(left_lines, frame)
        right_line = self.fit_line(right_lines, frame)
        
        # Smooth with previous frame
        left_line = self.smooth_line(left_line, self.prev_left)
        right_line = self.smooth_line(right_line, self.prev_right)
        
        # Store for next frame
        self.prev_left = left_line
        self.prev_right = right_line
        
        # Calculate offset
        offset, detected = self.calculate_center_offset(left_line, right_line, frame)
        
        # Draw visualization
        display = self.draw_lanes(frame, left_line, right_line, roi)
        
        return display, offset, detected, roi

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    array = array[:, :, :3]
    camera_image = array

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Attach camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda image: process_image(image))
    print("Camera attached!")
    
    # Initialize
    lane_detector = LaneDetector(640, 480)
    steering_pid = PIDController(kp=0.8, ki=0.01, kd=0.2)
    
    base_throttle = 0.35
    show_debug = False
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("LANE KEEPING SYSTEM v2")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W - Increase speed")
    print("  S - Decrease speed")
    print("  D - Toggle debug view")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            last_time = current_time
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Process frame
                display, offset, lanes_detected, roi = lane_detector.process(frame)
                
                # Calculate steering
                if lanes_detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = steering
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Draw info
                status = "LANES DETECTED" if lanes_detected else "SEARCHING..."
                color = (0, 255, 0) if lanes_detected else (0, 165, 255)
                cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Throttle: " + str(round(base_throttle, 2)), (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                
                # Draw center reference
                cv2.line(display, (320, 480), (320, 350), (255, 255, 0), 2)
                
                cv2.imshow('Lane Keeping v2', display)
                
                # Show debug view
                if show_debug:
                    roi_colored = cv2.cvtColor(roi, cv2.COLOR_GRAY2BGR)
                    cv2.imshow('Debug: Lane Mask', roi_colored)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.8, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('d'):
                show_debug = not show_debug
                if not show_debug:
                    cv2.destroyWindow('Debug: Lane Mask')
                print("Debug view: " + str(show_debug))
                
    finally:
        print("Stopping vehicle...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()