import sys
import os
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

rgb_image = None
seg_image = None

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-1.0, min(1.0, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

class SemanticLaneDetector:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        
        # CARLA semantic segmentation colors
        # Road = 128, 64, 128 (purple)
        # Road line = 157, 234, 50 (green/yellow)
        # Sidewalk = 244, 35, 232 (pink)
        
    def detect_road_center(self, seg_frame):
        height, width = seg_frame.shape[:2]
        
        # Look at bottom portion of image (where road is)
        roi_top = int(height * 0.6)
        roi = seg_frame[roi_top:height, :]
        
        # Detect road pixels (purple: BGR = 128, 64, 128)
        road_mask = cv2.inRange(roi, (125, 60, 125), (135, 70, 135))
        
        # Detect lane line pixels (green/yellow: BGR = 50, 234, 157)
        lane_mask = cv2.inRange(roi, (45, 230, 150), (60, 240, 165))
        
        return road_mask, lane_mask, roi_top
    
    def find_lane_center(self, road_mask, lane_mask, frame_width):
        height, width = road_mask.shape
        
        # Use bottom rows for detection
        bottom_rows = height // 3
        
        # Find road boundaries
        road_bottom = road_mask[height - bottom_rows:height, :]
        lane_bottom = lane_mask[height - bottom_rows:height, :]
        
        # Find left and right road edges
        road_cols = np.where(np.sum(road_bottom, axis=0) > 0)[0]
        
        if len(road_cols) < 10:
            return None, None, None
        
        left_road = road_cols[0]
        right_road = road_cols[-1]
        road_center = (left_road + right_road) // 2
        
        # Find lane markings
        lane_cols = np.where(np.sum(lane_bottom, axis=0) > 0)[0]
        
        left_lane = None
        right_lane = None
        
        if len(lane_cols) > 0:
            center = width // 2
            left_lanes = lane_cols[lane_cols < center]
            right_lanes = lane_cols[lane_cols > center]
            
            if len(left_lanes) > 0:
                left_lane = int(np.median(left_lanes))
            if len(right_lanes) > 0:
                right_lane = int(np.median(right_lanes))
        
        # Calculate lane center
        if left_lane is not None and right_lane is not None:
            lane_center = (left_lane + right_lane) // 2
        elif left_lane is not None:
            lane_center = left_lane + 150
        elif right_lane is not None:
            lane_center = right_lane - 150
        else:
            lane_center = road_center
        
        return lane_center, left_lane, right_lane
    
    def calculate_steering(self, lane_center, frame_width):
        if lane_center is None:
            return 0, False
        
        car_center = frame_width // 2
        offset = (lane_center - car_center) / (frame_width / 2)
        
        return offset, True
    
    def draw_visualization(self, rgb_frame, seg_frame, road_mask, lane_mask, roi_top, lane_center, left_lane, right_lane):
        display = rgb_frame.copy()
        height, width = display.shape[:2]
        
        # Draw ROI line
        cv2.line(display, (0, roi_top), (width, roi_top), (100, 100, 100), 1)
        
        # Draw detected lanes on RGB frame
        if left_lane is not None:
            x = left_lane
            cv2.line(display, (x, roi_top), (x, height), (255, 0, 0), 3)
        
        if right_lane is not None:
            x = right_lane
            cv2.line(display, (x, roi_top), (x, height), (0, 0, 255), 3)
        
        # Draw lane center
        if lane_center is not None:
            cv2.line(display, (lane_center, roi_top), (lane_center, height), (0, 255, 0), 2)
        
        # Draw car center reference
        car_center = width // 2
        cv2.line(display, (car_center, height - 50), (car_center, height), (255, 255, 0), 3)
        
        # Draw lane area
        if left_lane is not None and right_lane is not None:
            overlay = display.copy()
            pts = np.array([
                [left_lane, roi_top],
                [left_lane, height],
                [right_lane, height],
                [right_lane, roi_top]
            ], np.int32)
            cv2.fillPoly(overlay, [pts], (0, 255, 0))
            display = cv2.addWeighted(display, 0.8, overlay, 0.2, 0)
        
        return display

def process_rgb(image):
    global rgb_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    rgb_image = array[:, :, :3].copy()

def process_seg(image):
    global seg_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    seg_image = array[:, :, :3].copy()

def main():
    global rgb_image, seg_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # RGB Camera
    rgb_bp = blueprint_library.find('sensor.camera.rgb')
    rgb_bp.set_attribute('image_size_x', '640')
    rgb_bp.set_attribute('image_size_y', '480')
    rgb_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    rgb_camera = world.spawn_actor(rgb_bp, camera_transform, attach_to=vehicle)
    rgb_camera.listen(lambda img: process_rgb(img))
    print("RGB camera attached!")
    
    # Semantic Segmentation Camera
    seg_bp = blueprint_library.find('sensor.camera.semantic_segmentation')
    seg_bp.set_attribute('image_size_x', '640')
    seg_bp.set_attribute('image_size_y', '480')
    seg_bp.set_attribute('fov', '90')
    
    seg_camera = world.spawn_actor(seg_bp, camera_transform, attach_to=vehicle)
    seg_camera.listen(lambda img: process_seg(img))
    print("Semantic camera attached!")
    
    # Initialize
    lane_detector = SemanticLaneDetector(640, 480)
    steering_pid = PIDController(kp=0.8, ki=0.01, kd=0.25)
    
    base_throttle = 0.4
    show_seg = False
    
    print("")
    print("Waiting for cameras...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if rgb_image is not None and seg_image is not None:
            break
    
    print("")
    print("========================================")
    print("SEMANTIC LANE KEEPING SYSTEM")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W - Increase speed")
    print("  S - Decrease speed")
    print("  D - Toggle segmentation view")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            last_time = current_time
            
            if rgb_image is not None and seg_image is not None:
                # Detect road and lanes from segmentation
                road_mask, lane_mask, roi_top = lane_detector.detect_road_center(seg_image)
                
                # Find lane center
                lane_center, left_lane, right_lane = lane_detector.find_lane_center(
                    road_mask, lane_mask, 640
                )
                
                # Calculate steering offset
                offset, detected = lane_detector.calculate_steering(lane_center, 640)
                
                # PID control
                if detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = steering
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Visualization
                display = lane_detector.draw_visualization(
                    rgb_image, seg_image, road_mask, lane_mask,
                    roi_top, lane_center, left_lane, right_lane
                )
                
                # Info overlay
                status = "LANE DETECTED" if detected else "SEARCHING..."
                color = (0, 255, 0) if detected else (0, 165, 255)
                cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Throttle: " + str(round(base_throttle, 2)), (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                
                cv2.imshow('Semantic Lane Keeping', display)
                
                if show_seg:
                    # Show segmentation with masks
                    seg_display = seg_image.copy()
                    cv2.imshow('Segmentation View', seg_display)
                    
                    # Show road mask
                    road_display = cv2.cvtColor(road_mask, cv2.COLOR_GRAY2BGR)
                    cv2.imshow('Road Mask', road_display)
                    
                    # Show lane mask
                    lane_display = cv2.cvtColor(lane_mask, cv2.COLOR_GRAY2BGR)
                    cv2.imshow('Lane Mask', lane_display)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.8, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('d'):
                show_seg = not show_seg
                if not show_seg:
                    cv2.destroyWindow('Segmentation View')
                    cv2.destroyWindow('Road Mask')
                    cv2.destroyWindow('Lane Mask')
                print("Segmentation view: " + str(show_seg))
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        rgb_camera.stop()
        rgb_camera.destroy()
        seg_camera.stop()
        seg_camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()