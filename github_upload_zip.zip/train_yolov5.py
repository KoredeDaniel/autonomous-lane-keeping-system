import os
import shutil
import random

# Paths
data_dir = r"Z:\Users\egbebiakorededaniel\Desktop\carla_data"
images_dir = os.path.join(data_dir, "images")
labels_dir = os.path.join(data_dir, "labels")

train_images = os.path.join(data_dir, "train", "images")
train_labels = os.path.join(data_dir, "train", "labels")
val_images = os.path.join(data_dir, "val", "images")
val_labels = os.path.join(data_dir, "val", "labels")

# Create folders
for folder in [train_images, train_labels, val_images, val_labels]:
    if not os.path.exists(folder):
        os.makedirs(folder)

# Get all images that have labels
images = []
for f in os.listdir(images_dir):
    if f.endswith('.jpg') or f.endswith('.png'):
        label_file = f.replace('.jpg', '.txt').replace('.png', '.txt')
        if os.path.exists(os.path.join(labels_dir, label_file)):
            images.append(f)

print("Found " + str(len(images)) + " labeled images")

# Shuffle and split 80% train, 20% val
random.shuffle(images)
split = int(len(images) * 0.8)
train_list = images[:split]
val_list = images[split:]

print("Train: " + str(len(train_list)) + " images")
print("Val: " + str(len(val_list)) + " images")

# Copy files
print("Copying train files...")
for f in train_list:
    shutil.copy(os.path.join(images_dir, f), os.path.join(train_images, f))
    label = f.replace('.jpg', '.txt').replace('.png', '.txt')
    shutil.copy(os.path.join(labels_dir, label), os.path.join(train_labels, label))

print("Copying val files...")
for f in val_list:
    shutil.copy(os.path.join(images_dir, f), os.path.join(val_images, f))
    label = f.replace('.jpg', '.txt').replace('.png', '.txt')
    shutil.copy(os.path.join(labels_dir, label), os.path.join(val_labels, label))

# Create data.yaml
yaml_content = """train: Z:/Users/egbebiakorededaniel/Desktop/carla_data/train/images
val: Z:/Users/egbebiakorededaniel/Desktop/carla_data/val/images

nc: 4
names: ['vehicle', 'pedestrian', 'traffic_light', 'road_sign']
"""

yaml_path = os.path.join(data_dir, "data.yaml")
with open(yaml_path, 'w') as f:
    f.write(yaml_content)

print("")
print("Created data.yaml")
print("")
print("========================================")
print("SETUP COMPLETE!")
print("========================================")
print("")
print("Now run this command to train:")
print("")
print("py -3.7 train.py --img 640 --batch 8 --epochs 50 --data Z:/Users/egbebiakorededaniel/Desktop/carla_data/data.yaml --weights yolov5s.pt")
print("")