import sys
import os
import time
import numpy as np
import cv2
import torch
import scipy.special

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

# Add UFLD to path
ufld_path = r"c:\users\CARLACODES\1_code\ufld"
sys.path.insert(0, ufld_path)

import carla

camera_image = None

# ============================================
# Ultra-Fast Lane Detection Model
# ============================================

class UFLDLaneDetector:
    def __init__(self, model_path):
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print("Using device: " + str(self.device))
        
        # Model parameters (TuSimple)
        self.cls_num_per_lane = 56
        self.griding_num = 100
        self.row_anchor = [64, 68, 72, 76, 80, 84, 88, 92, 96, 100, 104, 108, 112,
                          116, 120, 124, 128, 132, 136, 140, 144, 148, 152, 156, 160, 164,
                          168, 172, 176, 180, 184, 188, 192, 196, 200, 204, 208, 212, 216,
                          220, 224, 228, 232, 236, 240, 244, 248, 252, 256, 260, 264, 268,
                          272, 276, 280, 284]
        
        self.img_w = 1280
        self.img_h = 720
        self.input_w = 800
        self.input_h = 288
        
        # Load model
        print("Loading UFLD model...")
        self.model = self.load_model(model_path)
        print("Model loaded!")
        
        # Smoothing
        self.prev_lanes = None
        self.alpha = 0.7
    
    def load_model(self, model_path):
        from model.model import parsingNet
        
        net = parsingNet(
            pretrained=False,
            backbone='18',
            cls_dim=(self.griding_num + 1, self.cls_num_per_lane, 4),
            use_aux=False
        ).to(self.device)
        
        state_dict = torch.load(model_path, map_location=self.device)['model']
        compatible_state_dict = {}
        for k, v in state_dict.items():
            if 'module.' in k:
                compatible_state_dict[k.replace('module.', '')] = v
            else:
                compatible_state_dict[k] = v
        
        net.load_state_dict(compatible_state_dict, strict=False)
        net.eval()
        
        return net
    
    def preprocess(self, img):
        # Resize to model input size
        img = cv2.resize(img, (self.input_w, self.input_h))
        img = img / 255.0
        img = (img - [0.485, 0.456, 0.406]) / [0.229, 0.224, 0.225]
        img = np.transpose(img, (2, 0, 1))
        img = torch.from_numpy(img).float().unsqueeze(0).to(self.device)
        return img
    
    def postprocess(self, output, original_shape):
        out_j = output[0].data.cpu().numpy()
        out_j = out_j[:, ::-1, :]
        prob = scipy.special.softmax(out_j[:-1, :, :], axis=0)
        idx = np.arange(self.griding_num) + 1
        idx = idx.reshape(-1, 1, 1)
        loc = np.sum(prob * idx, axis=0)
        out_j = np.argmax(out_j, axis=0)
        loc[out_j == self.griding_num] = 0
        out_j = loc
        
        # Scale to original image size
        col_sample = np.linspace(0, self.input_w - 1, self.griding_num)
        col_sample_w = col_sample[1] - col_sample[0]
        
        lanes = []
        for i in range(out_j.shape[1]):
            lane_points = []
            if np.sum(out_j[:, i] != 0) > 2:
                for k in range(out_j.shape[0]):
                    if out_j[k, i] > 0:
                        x = int(out_j[k, i] * col_sample_w * original_shape[1] / self.input_w)
                        y = int(self.row_anchor[self.cls_num_per_lane - 1 - k] * original_shape[0] / self.input_h)
                        lane_points.append((x, y))
                if len(lane_points) > 2:
                    lanes.append(lane_points)
        
        return lanes
    
    def detect(self, frame):
        original_shape = frame.shape[:2]
        
        # Preprocess
        input_tensor = self.preprocess(frame)
        
        # Inference
        with torch.no_grad():
            output = self.model(input_tensor)
        
        # Postprocess
        lanes = self.postprocess(output, original_shape)
        
        return lanes
    
    def smooth_lanes(self, lanes):
        if self.prev_lanes is None:
            self.prev_lanes = lanes
            return lanes
        
        if len(lanes) == 0:
            return self.prev_lanes
        
        self.prev_lanes = lanes
        return lanes
    
    def calculate_offset(self, lanes, frame_width, frame_height):
        if len(lanes) < 2:
            if len(lanes) == 1:
                # Single lane detected
                lane = lanes[0]
                bottom_points = [p for p in lane if p[1] > frame_height * 0.7]
                if len(bottom_points) > 0:
                    lane_x = np.mean([p[0] for p in bottom_points])
                    center = frame_width / 2
                    # Guess if it's left or right lane
                    if lane_x < center:
                        lane_center = lane_x + 150
                    else:
                        lane_center = lane_x - 150
                    offset = (lane_center - center) / (frame_width / 2)
                    return offset, True
            return 0, False
        
        # Get bottom points of each lane
        left_lane = None
        right_lane = None
        center = frame_width / 2
        
        for lane in lanes:
            bottom_points = [p for p in lane if p[1] > frame_height * 0.7]
            if len(bottom_points) > 0:
                lane_x = np.mean([p[0] for p in bottom_points])
                if lane_x < center:
                    if left_lane is None or lane_x > left_lane:
                        left_lane = lane_x
                else:
                    if right_lane is None or lane_x < right_lane:
                        right_lane = lane_x
        
        if left_lane is not None and right_lane is not None:
            lane_center = (left_lane + right_lane) / 2
            offset = (lane_center - center) / (frame_width / 2)
            return offset, True
        elif left_lane is not None:
            lane_center = left_lane + 150
            offset = (lane_center - center) / (frame_width / 2)
            return offset, True
        elif right_lane is not None:
            lane_center = right_lane - 150
            offset = (lane_center - center) / (frame_width / 2)
            return offset, True
        
        return 0, False
    
    def draw_lanes(self, frame, lanes):
        colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
        
        for i, lane in enumerate(lanes):
            color = colors[i % len(colors)]
            for j in range(len(lane) - 1):
                cv2.line(frame, lane[j], lane[j + 1], color, 4)
            for point in lane:
                cv2.circle(frame, point, 5, color, -1)
        
        return frame

# ============================================
# PID Controller
# ============================================

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-0.5, min(0.5, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    # Load UFLD model
    model_path = r"c:\users\CARLACODES\1_code\ufld\tusimple_18.pth"
    
    if not os.path.exists(model_path):
        print("ERROR: Model not found!")
        print("Please run: py -3.7 download_ufld.py")
        return
    
    print("Initializing UFLD Lane Detector...")
    lane_detector = UFLDLaneDetector(model_path)
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera (higher resolution for UFLD)
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '1280')
    camera_bp.set_attribute('image_size_y', '720')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # PID Controller
    steering_pid = PIDController(kp=0.9, ki=0.01, kd=0.25)
    
    base_throttle = 0.35
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("ULTRA-FAST LANE DETECTION")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            if dt < 0.01:
                dt = 0.01
            last_time = current_time
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Detect lanes
                lanes = lane_detector.detect(frame)
                lanes = lane_detector.smooth_lanes(lanes)
                
                # Calculate offset
                offset, detected = lane_detector.calculate_offset(lanes, frame.shape[1], frame.shape[0])
                
                # PID steering
                if detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = float(steering)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Draw lanes
                display = lane_detector.draw_lanes(frame, lanes)
                
                # Info overlay
                status = "LANES: " + str(len(lanes)) if detected else "NO LANES"
                color = (0, 255, 0) if detected else (0, 165, 255)
                cv2.putText(display, status, (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 1.0, color, 2)
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                cv2.putText(display, "Speed: " + str(round(base_throttle, 2)), (10, 150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                
                # Center line
                cv2.line(display, (640, 600), (640, 720), (0, 255, 255), 3)
                
                # Steering indicator
                steer_x = 640 + int(steering * 200)
                cv2.arrowedLine(display, (640, 680), (steer_x, 680), (255, 255, 0), 4)
                
                # Resize for display
                display_small = cv2.resize(display, (960, 540))
                cv2.imshow('UFLD Lane Keeping', display_small)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.7, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()