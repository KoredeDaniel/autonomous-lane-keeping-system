import sys
import os
import time
import numpy as np
import cv2
import math

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-1.0, min(1.0, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

class WaypointLaneKeeper:
    def __init__(self, vehicle, world):
        self.vehicle = vehicle
        self.world = world
        self.map = world.get_map()
        
        # Lookahead distance for waypoints
        self.lookahead_distance = 5.0
        
    def get_vehicle_transform(self):
        return self.vehicle.get_transform()
    
    def get_vehicle_location(self):
        return self.vehicle.get_location()
    
    def get_current_waypoint(self):
        location = self.get_vehicle_location()
        waypoint = self.map.get_waypoint(location, project_to_road=True)
        return waypoint
    
    def get_next_waypoints(self, distance=10.0, spacing=2.0):
        current_wp = self.get_current_waypoint()
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        next_wp = current_wp
        
        traveled = 0
        while traveled < distance:
            next_wps = next_wp.next(spacing)
            if len(next_wps) == 0:
                break
            next_wp = next_wps[0]
            waypoints.append(next_wp)
            traveled += spacing
        
        return waypoints
    
    def calculate_steering(self, lookahead=5.0):
        vehicle_transform = self.get_vehicle_transform()
        vehicle_location = vehicle_transform.location
        vehicle_rotation = vehicle_transform.rotation
        
        # Get waypoint ahead
        current_wp = self.get_current_waypoint()
        if current_wp is None:
            return 0.0, False
        
        # Get waypoint at lookahead distance
        next_wps = current_wp.next(lookahead)
        if len(next_wps) == 0:
            return 0.0, False
        
        target_wp = next_wps[0]
        target_location = target_wp.transform.location
        
        # Calculate vector to target
        dx = target_location.x - vehicle_location.x
        dy = target_location.y - vehicle_location.y
        
        # Get vehicle forward vector
        yaw = math.radians(vehicle_rotation.yaw)
        forward_x = math.cos(yaw)
        forward_y = math.sin(yaw)
        
        # Calculate cross track error (lateral offset)
        # Using cross product to determine left/right
        cross = forward_x * dy - forward_y * dx
        
        # Normalize by lookahead distance
        distance = math.sqrt(dx*dx + dy*dy)
        if distance > 0:
            cross_track_error = cross / distance
        else:
            cross_track_error = 0
        
        return cross_track_error, True
    
    def get_lane_center_offset(self):
        current_wp = self.get_current_waypoint()
        if current_wp is None:
            return 0.0, False
        
        vehicle_location = self.get_vehicle_location()
        lane_center = current_wp.transform.location
        
        # Vector from lane center to vehicle
        dx = vehicle_location.x - lane_center.x
        dy = vehicle_location.y - lane_center.y
        
        # Get lane direction
        lane_yaw = math.radians(current_wp.transform.rotation.yaw)
        lane_right_x = math.sin(lane_yaw)
        lane_right_y = -math.cos(lane_yaw)
        
        # Project offset onto lane right vector (positive = right of center)
        lateral_offset = dx * lane_right_x + dy * lane_right_y
        
        # Normalize by lane width
        lane_width = current_wp.lane_width
        normalized_offset = lateral_offset / (lane_width / 2)
        
        return normalized_offset, True
    
    def draw_waypoints(self, frame, waypoints, color=(0, 255, 0)):
        if len(waypoints) == 0:
            return frame
        
        # Get camera parameters (approximate)
        img_width = frame.shape[1]
        img_height = frame.shape[0]
        fov = 90
        
        vehicle_transform = self.get_vehicle_transform()
        
        # Camera position relative to vehicle
        camera_x = 2.0
        camera_z = 1.4
        
        points_2d = []
        
        for wp in waypoints:
            # Transform waypoint to vehicle coordinates
            wp_loc = wp.transform.location
            
            # World to vehicle transform
            dx = wp_loc.x - vehicle_transform.location.x
            dy = wp_loc.y - vehicle_transform.location.y
            dz = wp_loc.z - vehicle_transform.location.z
            
            # Rotate to vehicle frame
            yaw = math.radians(-vehicle_transform.rotation.yaw)
            local_x = dx * math.cos(yaw) - dy * math.sin(yaw)
            local_y = dx * math.sin(yaw) + dy * math.cos(yaw)
            local_z = dz
            
            # Adjust for camera position
            local_x -= camera_x
            local_z -= camera_z
            
            # Skip points behind camera
            if local_x < 1.0:
                continue
            
            # Project to image (pinhole camera model)
            f = img_width / (2 * math.tan(math.radians(fov / 2)))
            
            u = int(img_width / 2 - f * local_y / local_x)
            v = int(img_height / 2 - f * local_z / local_x)
            
            if 0 <= u < img_width and 0 <= v < img_height:
                points_2d.append((u, v))
        
        # Draw waypoints
        for i, pt in enumerate(points_2d):
            cv2.circle(frame, pt, 8, color, -1)
            if i > 0:
                cv2.line(frame, points_2d[i-1], pt, color, 3)
        
        return frame
    
    def draw_lane_boundaries(self, frame, waypoints):
        if len(waypoints) == 0:
            return frame
        
        img_width = frame.shape[1]
        img_height = frame.shape[0]
        fov = 90
        
        vehicle_transform = self.get_vehicle_transform()
        camera_x = 2.0
        camera_z = 1.4
        
        left_points = []
        right_points = []
        
        for wp in waypoints:
            wp_loc = wp.transform.location
            wp_yaw = math.radians(wp.transform.rotation.yaw)
            lane_width = wp.lane_width / 2
            
            # Left and right lane boundaries
            left_x = wp_loc.x - lane_width * math.sin(wp_yaw)
            left_y = wp_loc.y + lane_width * math.cos(wp_yaw)
            right_x = wp_loc.x + lane_width * math.sin(wp_yaw)
            right_y = wp_loc.y - lane_width * math.cos(wp_yaw)
            
            for loc_x, loc_y, points_list in [(left_x, left_y, left_points), (right_x, right_y, right_points)]:
                dx = loc_x - vehicle_transform.location.x
                dy = loc_y - vehicle_transform.location.y
                dz = wp_loc.z - vehicle_transform.location.z
                
                yaw = math.radians(-vehicle_transform.rotation.yaw)
                local_x = dx * math.cos(yaw) - dy * math.sin(yaw)
                local_y = dx * math.sin(yaw) + dy * math.cos(yaw)
                local_z = dz
                
                local_x -= camera_x
                local_z -= camera_z
                
                if local_x < 1.0:
                    continue
                
                f = img_width / (2 * math.tan(math.radians(fov / 2)))
                u = int(img_width / 2 - f * local_y / local_x)
                v = int(img_height / 2 - f * local_z / local_x)
                
                if 0 <= u < img_width and 0 <= v < img_height:
                    points_list.append((u, v))
        
        # Draw lane boundaries
        for i in range(1, len(left_points)):
            cv2.line(frame, left_points[i-1], left_points[i], (255, 0, 0), 4)
        
        for i in range(1, len(right_points)):
            cv2.line(frame, right_points[i-1], right_points[i], (0, 0, 255), 4)
        
        # Fill lane area
        if len(left_points) > 2 and len(right_points) > 2:
            all_points = left_points + right_points[::-1]
            if len(all_points) > 2:
                pts = np.array(all_points, np.int32)
                overlay = frame.copy()
                cv2.fillPoly(overlay, [pts], (0, 255, 0))
                frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
        
        return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Initialize lane keeper and PID
    lane_keeper = WaypointLaneKeeper(vehicle, world)
    steering_pid = PIDController(kp=1.5, ki=0.0, kd=0.5)
    
    base_throttle = 0.4
    lookahead = 5.0
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("WAYPOINT-BASED LANE KEEPING")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("  A/D - Decrease/Increase lookahead")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            if dt < 0.01:
                dt = 0.01
            last_time = current_time
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Get waypoints
                waypoints = lane_keeper.get_next_waypoints(distance=30.0, spacing=2.0)
                
                # Calculate steering using pure pursuit
                cross_track_error, valid = lane_keeper.calculate_steering(lookahead)
                
                # Also get lane center offset
                lane_offset, offset_valid = lane_keeper.get_lane_center_offset()
                
                if valid:
                    # Combine cross track error and lane offset
                    combined_error = 0.7 * cross_track_error + 0.3 * lane_offset
                    steering = steering_pid.compute(combined_error, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = float(steering)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Draw visualization
                frame = lane_keeper.draw_lane_boundaries(frame, waypoints)
                frame = lane_keeper.draw_waypoints(frame, waypoints, color=(0, 255, 255))
                
                # Get current speed
                velocity = vehicle.get_velocity()
                speed = 3.6 * math.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
                
                # Info overlay
                cv2.putText(frame, "WAYPOINT LANE KEEPING", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(frame, "Steer: " + str(round(steering, 3)), (10, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(frame, "Offset: " + str(round(lane_offset, 3)), (10, 125), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(frame, "Lookahead: " + str(round(lookahead, 1)) + "m", (10, 155), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                
                # Steering indicator
                center_x = 400
                steer_x = center_x + int(steering * 150)
                cv2.line(frame, (center_x, 570), (center_x, 590), (0, 255, 255), 3)
                cv2.arrowedLine(frame, (center_x, 580), (steer_x, 580), (255, 255, 0), 4)
                
                cv2.imshow('Lane Keeping', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.8, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('a'):
                lookahead = max(2.0, lookahead - 1.0)
                print("Lookahead: " + str(round(lookahead, 1)) + "m")
            elif key == ord('d'):
                lookahead = min(15.0, lookahead + 1.0)
                print("Lookahead: " + str(round(lookahead, 1)) + "m")
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()