import sys

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

print("Connecting to CARLA...")
client = carla.Client('localhost', 2000)
client.set_timeout(10.0)
world = client.get_world()
print("Connected!")

print("Destroying all actors...")
actors = world.get_actors()

vehicles = actors.filter('vehicle.*')
print("  Found " + str(len(vehicles)) + " vehicles")
for v in vehicles:
    v.destroy()

walkers = actors.filter('walker.*')
print("  Found " + str(len(walkers)) + " walkers")
for w in walkers:
    w.destroy()

controllers = actors.filter('controller.*')
print("  Found " + str(len(controllers)) + " controllers")
for c in controllers:
    c.destroy()

sensors = actors.filter('sensor.*')
print("  Found " + str(len(sensors)) + " sensors")
for s in sensors:
    s.destroy()

print("")
print("World cleaned!")