# -*- coding: utf-8 -*-
import os
from collections import Counter

LABEL_DIR = r"carla_dataset\labels"

def main():
    if not os.path.isdir(LABEL_DIR):
        print("ERROR: label dir not found:", LABEL_DIR)
        return

    files = [f for f in os.listdir(LABEL_DIR) if f.lower().endswith(".txt")]
    files.sort()

    total = len(files)
    empty = 0
    nonempty = 0

    class_ids = set()
    class_rows = Counter()

    first_nonempty = None

    for fn in files:
        p = os.path.join(LABEL_DIR, fn)
        try:
            size = os.path.getsize(p)
        except OSError:
            continue

        if size == 0:
            empty += 1
            continue

        nonempty += 1
        if first_nonempty is None:
            first_nonempty = fn

        with open(p, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split()
                if len(parts) < 5:
                    continue
                try:
                    cid = int(parts[0])
                except ValueError:
                    continue
                class_ids.add(cid)
                class_rows[cid] += 1

    print("Label dir:", os.path.abspath(LABEL_DIR))
    print("Total label files:", total)
    print("Empty label files:", empty)
    print("Non-empty label files:", nonempty)
    print("Empty %:", round(100.0 * empty / total, 2) if total else 0)

    if first_nonempty:
        print("Example non-empty file:", first_nonempty)

    if class_ids:
        print("Unique class IDs:", sorted(class_ids))
        print("Rows per class:")
        for cid in sorted(class_rows.keys()):
            print(" ", cid, ":", class_rows[cid])
    else:
        print("No valid label rows found (all empty or malformed).")

if __name__ == "__main__":
    main()