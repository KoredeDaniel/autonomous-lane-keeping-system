import sys
import time
import numpy as np
import cv2
import math
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class PerfectSteering:
    def __init__(self):
        # Steering history for smoothing
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        
        # Tuning parameters
        self.smoothing_factor = 0.12  # Lower = smoother
        self.max_rate = 0.03  # Max steering change per frame
        
    def smooth(self, raw_steer):
        # Add to history
        self.history.append(raw_steer)
        
        # Weighted moving average (recent values weighted more)
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        
        # Exponential smoothing
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        
        # Rate limiting for extra smoothness
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        
        self.prev_steer = smoothed
        return smoothed
    
    def reset(self):
        self.history.clear()
        self.prev_steer = 0.0

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        
        # Vehicle parameters
        self.wheelbase = 2.5  # Tesla Model 3 wheelbase approx
        
        # Control parameters
        self.base_lookahead = 5.0
        self.min_lookahead = 3.0
        self.max_lookahead = 10.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
    
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        """Adjust lookahead based on speed"""
        speed = self.get_speed()
        # Lookahead increases with speed
        lookahead = self.base_lookahead + speed * 0.3
        return max(self.min_lookahead, min(self.max_lookahead, lookahead))
    
    def get_waypoints_ahead(self, count=15, spacing=1.5):
        """Get multiple waypoints ahead"""
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        wp = current_wp
        
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        
        return waypoints
    
    def calculate_curvature(self, waypoints):
        """Calculate path curvature to detect curves"""
        if len(waypoints) < 3:
            return 0.0
        
        # Use 3 points to estimate curvature
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        
        # Menger curvature formula
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        
        # Area of triangle
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        
        area = math.sqrt(area_sq)
        curvature = 4 * area / (a * b * c)
        
        return curvature
    
    def pure_pursuit(self, lookahead):
        """Pure pursuit steering calculation"""
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        # Get current waypoint
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Get target waypoint at lookahead distance
        target_wp = current_wp
        remaining = lookahead
        
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        
        # Transform target to vehicle coordinates
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        # Calculate steering using pure pursuit formula
        # steering = atan(2 * L * sin(alpha) / ld)
        # where L = wheelbase, alpha = angle to target, ld = lookahead distance
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure pursuit steering
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        
        # Convert to normalized steering [-1, 1]
        # Assuming max steering angle of 70 degrees
        max_steer_rad = math.radians(70)
        steering = steering / max_steer_rad
        steering = max(-1.0, min(1.0, steering))
        
        # Calculate cross-track error for display
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        cte = (location.x - wp_loc.x) * math.sin(wp_yaw) - (location.y - wp_loc.y) * math.cos(wp_yaw)
        
        return steering, cte, True
    
    def get_steering(self):
        """Main steering calculation"""
        lookahead = self.get_adaptive_lookahead()
        steering, cte, valid = self.pure_pursuit(lookahead)
        
        # Get waypoints for curvature
        waypoints = self.get_waypoints_ahead()
        curvature = self.calculate_curvature(waypoints)
        
        return steering, cte, curvature, lookahead, valid, waypoints

def draw_lane(frame, vehicle, waypoints):
    """Draw lane visualization"""
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.92
        
        # Left, right, center points
        points_data = [
            (loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
            (loc.x, loc.y, center_pts)
        ]
        
        for px, py, pts in points_data:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    # Fill lane area
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 140, 0))
        frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
    
    # Draw lane lines
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 80, 80), 4)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (80, 80, 255), 4)
    
    # Draw center guideline (dashed)
    for i in range(1, len(center_pts)):
        if i % 2 == 0:
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 220, 220), 2)
    
    return frame

def draw_hud(frame, speed, steer, cte, curvature, lookahead, throttle):
    """Draw heads-up display"""
    h, w = frame.shape[:2]
    
    # Semi-transparent background for info panel
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (220, 160), (0, 0, 0), -1)
    frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
    
    # Title
    cv2.putText(frame, "LANE KEEPING", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
    
    # Info
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (20, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Lookahead: " + str(round(lookahead, 1)) + " m", (20, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Curve indicator
    if curvature > 0.05:
        cv2.putText(frame, "CURVE AHEAD", (w - 150, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 255), 2)
    
    # Steering visualization at bottom
    bar_x = w // 2
    bar_y = h - 40
    bar_width = 150
    
    # Background bar
    cv2.rectangle(frame, (bar_x - bar_width, bar_y - 8), (bar_x + bar_width, bar_y + 8), (40, 40, 40), -1)
    cv2.rectangle(frame, (bar_x - bar_width, bar_y - 8), (bar_x + bar_width, bar_y + 8), (100, 100, 100), 1)
    
    # Center mark
    cv2.line(frame, (bar_x, bar_y - 12), (bar_x, bar_y + 12), (200, 200, 200), 2)
    
    # Steering indicator
    steer_pos = bar_x + int(steer * bar_width)
    cv2.circle(frame, (steer_pos, bar_y), 12, (0, 255, 255), -1)
    cv2.circle(frame, (steer_pos, bar_y), 12, (255, 255, 255), 2)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    world_map = world.get_map()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Controllers
    lane_keeper = LaneKeeper(vehicle, world_map)
    steering_smoother = PerfectSteering()
    
    # Control parameters
    throttle = 0.28
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("PERFECT LANE KEEPING")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Adjust speed")
    print("  R - Reset steering smoother")
    print("========================================")
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Get steering from lane keeper
                raw_steer, cte, curvature, lookahead, valid, waypoints = lane_keeper.get_steering()
                
                # Smooth the steering
                if valid:
                    steer = steering_smoother.smooth(raw_steer)
                else:
                    steer = steering_smoother.smooth(0.0)
                
                # Slow down for curves
                current_throttle = throttle
                if curvature > 0.08:
                    current_throttle = throttle * 0.7
                elif curvature > 0.05:
                    current_throttle = throttle * 0.85
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = current_throttle
                control.steer = float(steer)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Get speed
                speed = lane_keeper.get_speed_kmh()
                
                # Draw visualization
                frame = draw_lane(frame, vehicle, waypoints)
                frame = draw_hud(frame, speed, steer, cte, curvature, lookahead, current_throttle)
                
                cv2.imshow('Perfect Lane Keeping', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.5, throttle + 0.02)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('s'):
                throttle = max(0.15, throttle - 0.02)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('r'):
                steering_smoother.reset()
                print("Steering reset")
                
    finally:
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()