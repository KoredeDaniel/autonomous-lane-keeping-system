import sys
import os
import random
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

class LaneDetector:
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def region_of_interest(self, img):
        height, width = img.shape[:2]
        
        # Define polygon for region of interest (bottom half, trapezoid shape)
        polygons = np.array([
            [(0, height),
             (0, int(height * 0.6)),
             (int(width * 0.4), int(height * 0.4)),
             (int(width * 0.6), int(height * 0.4)),
             (width, int(height * 0.6)),
             (width, height)]
        ])
        
        mask = np.zeros_like(img)
        cv2.fillPoly(mask, polygons, 255)
        masked = cv2.bitwise_and(img, mask)
        return masked
    
    def detect_lanes(self, frame):
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Canny edge detection
        edges = cv2.Canny(blur, 50, 150)
        
        # Apply region of interest mask
        roi = self.region_of_interest(edges)
        
        # Hough line detection
        lines = cv2.HoughLinesP(
            roi,
            rho=1,
            theta=np.pi/180,
            threshold=50,
            minLineLength=50,
            maxLineGap=150
        )
        
        return lines, roi
    
    def separate_lines(self, lines, frame):
        left_lines = []
        right_lines = []
        
        if lines is None:
            return left_lines, right_lines
        
        height, width = frame.shape[:2]
        center_x = width // 2
        
        for line in lines:
            x1, y1, x2, y2 = line[0]
            
            if x2 - x1 == 0:
                continue
            
            slope = (y2 - y1) / (x2 - x1)
            
            # Filter out horizontal lines
            if abs(slope) < 0.3:
                continue
            
            # Left lane has negative slope, right lane has positive slope
            if slope < 0 and x1 < center_x and x2 < center_x:
                left_lines.append(line[0])
            elif slope > 0 and x1 > center_x and x2 > center_x:
                right_lines.append(line[0])
        
        return left_lines, right_lines
    
    def average_line(self, lines, frame):
        if len(lines) == 0:
            return None
        
        x1_avg = int(np.mean([l[0] for l in lines]))
        y1_avg = int(np.mean([l[1] for l in lines]))
        x2_avg = int(np.mean([l[2] for l in lines]))
        y2_avg = int(np.mean([l[3] for l in lines]))
        
        return [x1_avg, y1_avg, x2_avg, y2_avg]
    
    def extrapolate_line(self, line, frame):
        if line is None:
            return None
        
        height, width = frame.shape[:2]
        x1, y1, x2, y2 = line
        
        if x2 - x1 == 0:
            return None
        
        slope = (y2 - y1) / (x2 - x1)
        intercept = y1 - slope * x1
        
        if slope == 0:
            return None
        
        # Extrapolate to bottom and middle of frame
        y1_new = height
        y2_new = int(height * 0.55)
        
        x1_new = int((y1_new - intercept) / slope)
        x2_new = int((y2_new - intercept) / slope)
        
        return [x1_new, y1_new, x2_new, y2_new]
    
    def calculate_center_offset(self, left_line, right_line, frame):
        height, width = frame.shape[:2]
        car_center = width // 2
        
        if left_line is not None and right_line is not None:
            # Both lanes detected
            left_x = left_line[0]
            right_x = right_line[0]
            lane_center = (left_x + right_x) // 2
        elif left_line is not None:
            # Only left lane - assume lane is 400 pixels wide
            lane_center = left_line[0] + 200
        elif right_line is not None:
            # Only right lane
            lane_center = right_line[0] - 200
        else:
            # No lanes detected
            return 0, False
        
        # Positive offset means car is to the right of center
        offset = (lane_center - car_center) / (width / 2)
        return offset, True
    
    def draw_lanes(self, frame, left_line, right_line):
        overlay = frame.copy()
        
        if left_line is not None:
            cv2.line(overlay, (left_line[0], left_line[1]), (left_line[2], left_line[3]), (255, 0, 0), 5)
        
        if right_line is not None:
            cv2.line(overlay, (right_line[0], right_line[1]), (right_line[2], right_line[3]), (0, 0, 255), 5)
        
        # Draw lane area
        if left_line is not None and right_line is not None:
            pts = np.array([
                [left_line[0], left_line[1]],
                [left_line[2], left_line[3]],
                [right_line[2], right_line[3]],
                [right_line[0], right_line[1]]
            ], np.int32)
            cv2.fillPoly(overlay, [pts], (0, 255, 0, 50))
        
        result = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
        return result

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    array = array[:, :, :3]
    camera_image = array

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Attach camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda image: process_image(image))
    print("Camera attached!")
    
    # Initialize lane detector and PID controller
    lane_detector = LaneDetector(640, 480)
    steering_pid = PIDController(kp=1.0, ki=0.0, kd=0.3)
    
    # Set initial throttle
    base_throttle = 0.4
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("LANE KEEPING SYSTEM")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W - Increase speed")
    print("  S - Decrease speed")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            last_time = current_time
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Detect lanes
                lines, roi = lane_detector.detect_lanes(frame)
                
                # Separate left and right lines
                left_lines, right_lines = lane_detector.separate_lines(lines, frame)
                
                # Average and extrapolate lines
                left_avg = lane_detector.average_line(left_lines, frame)
                right_avg = lane_detector.average_line(right_lines, frame)
                
                left_line = lane_detector.extrapolate_line(left_avg, frame)
                right_line = lane_detector.extrapolate_line(right_avg, frame)
                
                # Calculate center offset
                offset, lanes_detected = lane_detector.calculate_center_offset(left_line, right_line, frame)
                
                # Calculate steering using PID
                if lanes_detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = steering
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Draw visualization
                display = lane_detector.draw_lanes(frame, left_line, right_line)
                
                # Draw info
                status = "LANES DETECTED" if lanes_detected else "NO LANES"
                color = (0, 255, 0) if lanes_detected else (0, 0, 255)
                cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                cv2.putText(display, "Speed: " + str(round(base_throttle, 2)), (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
                
                # Draw center line
                cv2.line(display, (320, 480), (320, 300), (255, 255, 0), 2)
                
                cv2.imshow('Lane Keeping System', display)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(1.0, base_throttle + 0.1)
                print("Speed: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.1)
                print("Speed: " + str(round(base_throttle, 2)))
                
    finally:
        print("Stopping vehicle...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()