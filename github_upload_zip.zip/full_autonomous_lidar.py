import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None
lidar_data = None

COCO_VEHICLE_CLASSES = [2, 3, 5, 7]
COCO_PERSON_CLASS = 0
COCO_TRAFFIC_LIGHT = 9
COCO_STOP_SIGN = 11

# ============================================
# LIDAR PROCESSOR
# ============================================

class LiDARProcessor:
    def __init__(self, camera_fov=90, image_width=800, image_height=600):
        self.camera_fov = camera_fov
        self.image_width = image_width
        self.image_height = image_height
        
        # Camera intrinsics
        self.focal = image_width / (2.0 * math.tan(math.radians(camera_fov / 2)))
        
        # Camera position relative to vehicle (must match camera_transform)
        self.cam_x = 2.0
        self.cam_z = 1.4
        
        # LiDAR position relative to vehicle
        self.lidar_x = 0.0
        self.lidar_z = 2.4
    
    def get_points_in_bbox(self, points, bbox, margin=0.5):
        """
        Find LiDAR points that project into a 2D bounding box.
        Returns the points and their distances.
        """
        if points is None or len(points) == 0:
            return [], float('inf')
        
        x1, y1, x2, y2 = bbox
        
        # Filter points in front of camera
        front_points = points[points[:, 0] > 0.5]
        
        if len(front_points) == 0:
            return [], float('inf')
        
        # Transform LiDAR points to camera frame
        # LiDAR is at (0, 0, 2.4), Camera is at (2.0, 0, 1.4)
        cam_points = front_points.copy()
        cam_points[:, 0] = front_points[:, 0] - (self.cam_x - self.lidar_x)  # x offset
        cam_points[:, 2] = front_points[:, 2] - (self.lidar_z - self.cam_z)  # z offset
        
        # Project to image plane
        # Camera coordinates: x=forward, y=left, z=up
        # Image coordinates: u=right, v=down
        valid_mask = cam_points[:, 0] > 0.5
        cam_points = cam_points[valid_mask]
        front_points = front_points[valid_mask]
        
        if len(cam_points) == 0:
            return [], float('inf')
        
        # Project
        u = self.image_width / 2 - (self.focal * cam_points[:, 1] / cam_points[:, 0])
        v = self.image_height / 2 - (self.focal * cam_points[:, 2] / cam_points[:, 0])
        
        # Find points within bounding box (with margin)
        in_bbox = ((u >= x1 - margin * (x2 - x1)) & 
                   (u <= x2 + margin * (x2 - x1)) &
                   (v >= y1 - margin * (y2 - y1)) & 
                   (v <= y2 + margin * (y2 - y1)))
        
        bbox_points = front_points[in_bbox]
        
        if len(bbox_points) == 0:
            return [], float('inf')
        
        # Calculate distances
        distances = np.sqrt(bbox_points[:, 0]**2 + bbox_points[:, 1]**2)
        min_distance = np.min(distances)
        
        return bbox_points, min_distance
    
    def get_obstacle_distance(self, points, lane_width=3.5):
        """
        Get distance to closest obstacle in the driving corridor.
        """
        if points is None or len(points) == 0:
            return float('inf'), None
        
        # Filter points:
        # - In front (x > 1m)
        # - Within lane width (|y| < lane_width/2)
        # - Above ground, below 3m (reasonable obstacle height)
        corridor_mask = ((points[:, 0] > 1) & 
                         (points[:, 0] < 50) &
                         (np.abs(points[:, 1]) < lane_width / 2) &
                         (points[:, 2] > -1.5) &
                         (points[:, 2] < 3))
        
        corridor_points = points[corridor_mask]
        
        if len(corridor_points) == 0:
            return float('inf'), None
        
        # Find closest point
        distances = np.sqrt(corridor_points[:, 0]**2 + corridor_points[:, 1]**2)
        min_idx = np.argmin(distances)
        
        return distances[min_idx], corridor_points[min_idx]
    
    def create_top_down_view(self, points, size=200, scale=4):
        """Create a top-down visualization of LiDAR points"""
        view = np.zeros((size, size, 3), dtype=np.uint8)
        
        if points is None or len(points) == 0:
            return view
        
        # Filter relevant points
        mask = ((points[:, 0] > -5) & (points[:, 0] < 45) &
                (np.abs(points[:, 1]) < 20) &
                (points[:, 2] > -2) & (points[:, 2] < 4))
        filtered = points[mask]
        
        if len(filtered) == 0:
            return view
        
        # Project to top-down
        cx, cy = size // 2, size - 20
        
        px = (cx - filtered[:, 1] * scale).astype(int)
        py = (cy - filtered[:, 0] * scale).astype(int)
        
        # Filter valid pixels
        valid = (px >= 0) & (px < size) & (py >= 0) & (py < size)
        px, py = px[valid], py[valid]
        heights = filtered[valid, 2]
        
        # Color by height
        for i in range(len(px)):
            z = heights[i]
            if z < -1:
                color = (80, 80, 80)  # Ground
            elif z < 0.5:
                color = (0, 200, 0)  # Low
            elif z < 1.5:
                color = (0, 255, 255)  # Medium
            else:
                color = (0, 0, 255)  # High
            cv2.circle(view, (px[i], py[i]), 1, color, -1)
        
        # Draw ego vehicle
        cv2.rectangle(view, (cx - 4, cy - 2), (cx + 4, cy + 8), (255, 255, 0), -1)
        
        # Draw lane boundaries
        lane_px = int(1.75 * scale)
        cv2.line(view, (cx - lane_px, 0), (cx - lane_px, size), (100, 100, 100), 1)
        cv2.line(view, (cx + lane_px, 0), (cx + lane_px, size), (100, 100, 100), 1)
        
        return view

# ============================================
# STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        self.smoothing_factor = 0.12
        self.max_rate = 0.03
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 5.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.3
        return max(3.0, min(10.0, lookahead))
    
    def get_waypoints(self, count=15, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        cte = dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
        return cte
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        lookahead = self.get_adaptive_lookahead()
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        cte = self.get_cross_track_error()
        
        return steering, cte, True

# ============================================
# OBJECT TRACKER WITH LIDAR FUSION
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0
        self.distance = float('inf')  # LiDAR distance
        self.lidar_points = []

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
        self.max_missed = 8
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
        
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                track = Track(self.next_id, det['bbox'], det['label'], det['conf'])
                track.distance = det.get('distance', float('inf'))
                self.tracks.append(track)
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.25
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].distance = det.get('distance', float('inf'))
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                track = Track(self.next_id, det['bbox'], det['label'], det['conf'])
                track.distance = det.get('distance', float('inf'))
                self.tracks.append(track)
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE WITH LIDAR
# ============================================

class CollisionAvoidance:
    def __init__(self):
        # Distance thresholds in meters (from LiDAR)
        self.emergency_dist = 5.0   # Emergency brake
        self.brake_dist = 10.0      # Hard brake
        self.slow_dist = 20.0       # Slow down
        
    def check(self, tracks, lidar_corridor_dist):
        """
        Check for collision risk using both tracked objects and LiDAR corridor.
        """
        closest_dist = float('inf')
        danger_track = None
        
        # Check tracked objects
        for track in tracks:
            if track.label not in ['vehicle', 'pedestrian']:
                continue
            
            if track.distance < closest_dist:
                closest_dist = track.distance
                danger_track = track
        
        # Also check raw LiDAR corridor distance
        if lidar_corridor_dist < closest_dist:
            closest_dist = lidar_corridor_dist
        
        # Determine action based on distance
        if closest_dist < self.emergency_dist:
            return 'EMERGENCY', 0.0, 1.0, danger_track, closest_dist
        elif closest_dist < self.brake_dist:
            return 'BRAKE', 0.0, 0.7, danger_track, closest_dist
        elif closest_dist < self.slow_dist:
            # Proportional slowdown
            throttle_mult = (closest_dist - self.brake_dist) / (self.slow_dist - self.brake_dist)
            throttle_mult = max(0.3, min(1.0, throttle_mult))
            return 'SLOW', throttle_mult, 0.0, danger_track, closest_dist
        else:
            return 'CLEAR', 1.0, 0.0, None, closest_dist

# ============================================
# METRICS
# ============================================

class Metrics:
    def __init__(self):
        self.fps_history = deque(maxlen=30)
        self.last_time = time.time()
        self.frame_count = 0
        self.start_time = time.time()
        self.cte_history = deque(maxlen=100)
        self.yolo_latency = deque(maxlen=30)
        self.brake_events = 0
        self.emergency_events = 0
    
    def update_fps(self):
        current_time = time.time()
        dt = current_time - self.last_time
        if dt > 0:
            self.fps_history.append(1.0 / dt)
        self.last_time = current_time
        self.frame_count += 1
    
    def get_fps(self):
        return np.mean(self.fps_history) if len(self.fps_history) > 0 else 0.0
    
    def get_runtime(self):
        return time.time() - self.start_time
    
    def get_avg_cte(self):
        return np.mean(np.abs(list(self.cte_history))) if len(self.cte_history) > 0 else 0.0
    
    def get_avg_yolo_latency(self):
        return np.mean(self.yolo_latency) * 1000 if len(self.yolo_latency) > 0 else 0.0

# ============================================
# DETECTION FILTER WITH LIDAR FUSION
# ============================================

def filter_detections(results, frame_width, frame_height, lidar_processor, lidar_points):
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        if class_id in COCO_VEHICLE_CLASSES:
            label = 'vehicle'
        elif class_id == COCO_PERSON_CLASS:
            label = 'pedestrian'
        elif class_id == COCO_TRAFFIC_LIGHT:
            label = 'traffic_light'
        elif class_id == COCO_STOP_SIGN:
            label = 'traffic_sign'
        else:
            continue
        
        box_width = x2 - x1
        box_height = y2 - y1
        box_area = box_width * box_height
        frame_area = frame_width * frame_height
        aspect_ratio = box_width / box_height if box_height > 0 else 0
        
        if conf < 0.5:
            continue
        if box_width < 25 or box_height < 25:
            continue
        if box_area > frame_area * 0.4:
            continue
        if label == 'vehicle' and y1 < frame_height * 0.2:
            continue
        if label == 'vehicle' and (aspect_ratio < 0.4 or aspect_ratio > 3.5):
            continue
        if label == 'pedestrian' and aspect_ratio > 0.9:
            continue
        
        # Get LiDAR distance for this detection
        bbox = [x1, y1, x2, y2]
        _, distance = lidar_processor.get_points_in_bbox(lidar_points, bbox)
        
        filtered.append({
            'bbox': bbox,
            'label': label,
            'conf': conf,
            'distance': distance
        })
    
    return filtered

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
                            (loc.x, loc.y, center_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 100, 0))
        frame = cv2.addWeighted(frame, 0.75, overlay, 0.25, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 2)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 200, 200), 2)
    
    return frame

def draw_tracks(frame, tracks, danger_track):
    colors = {
        'vehicle': (0, 255, 0),
        'pedestrian': (0, 165, 255),
        'traffic_light': (0, 255, 255),
        'traffic_sign': (255, 0, 255)
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = colors.get(track.label, (255, 255, 255))
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        
        # Show distance from LiDAR
        if track.distance < float('inf'):
            label = track.label[:4] + " " + str(round(track.distance, 1)) + "m"
        else:
            label = track.label[:6]
        
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)
    
    return frame

def draw_hud(frame, metrics, speed, steer, cte, action, track_count, throttle, 
             closest_dist, lidar_points_count, lidar_view):
    h, w = frame.shape[:2]
    
    # Left panel - Vehicle State
    cv2.rectangle(frame, (5, 5), (210, 150), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (210, 150), (100, 100, 100), 1)
    
    cv2.putText(frame, "LIDAR + CAMERA", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 58), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (10, 74), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Objects: " + str(track_count), (10, 106), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "LiDAR pts: " + str(lidar_points_count), (10, 122), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # Closest obstacle
    if closest_dist < float('inf'):
        dist_color = (0, 255, 0) if closest_dist > 20 else ((0, 165, 255) if closest_dist > 10 else (0, 0, 255))
        cv2.putText(frame, "Closest: " + str(round(closest_dist, 1)) + "m", (10, 138), cv2.FONT_HERSHEY_SIMPLEX, 0.4, dist_color, 1)
    
    # Status
    status_y = 155
    if action == 'EMERGENCY':
        cv2.rectangle(frame, (5, status_y), (210, status_y + 25), (0, 0, 150), -1)
        cv2.putText(frame, "!! EMERGENCY BRAKE !!", (10, status_y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)
    elif action == 'BRAKE':
        cv2.rectangle(frame, (5, status_y), (210, status_y + 25), (0, 100, 150), -1)
        cv2.putText(frame, "BRAKING", (10, status_y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    elif action == 'SLOW':
        cv2.rectangle(frame, (5, status_y), (210, status_y + 25), (0, 150, 150), -1)
        cv2.putText(frame, "SLOWING DOWN", (10, status_y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    else:
        cv2.rectangle(frame, (5, status_y), (210, status_y + 25), (0, 100, 0), -1)
        cv2.putText(frame, "CLEAR", (10, status_y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Right panel - Metrics
    cv2.rectangle(frame, (w - 160, 5), (w - 5, 100), (0, 0, 0), -1)
    cv2.rectangle(frame, (w - 160, 5), (w - 5, 100), (100, 100, 100), 1)
    
    fps = metrics.get_fps()
    yolo_lat = metrics.get_avg_yolo_latency()
    
    cv2.putText(frame, "METRICS", (w - 155, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (w - 155, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "YOLO: " + str(round(yolo_lat, 1)) + "ms", (w - 155, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Avg CTE: " + str(round(metrics.get_avg_cte(), 3)), (w - 155, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Brakes: " + str(metrics.brake_events), (w - 155, 86), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # LiDAR top-down view (bottom right)
    view_size = lidar_view.shape[0]
    frame[h - view_size - 10:h - 10, w - view_size - 10:w - 10] = lidar_view
    cv2.rectangle(frame, (w - view_size - 10, h - view_size - 10), (w - 10, h - 10), (255, 255, 255), 1)
    cv2.putText(frame, "LiDAR Top-Down", (w - view_size - 5, h - view_size - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    
    # Runtime
    mins = int(metrics.get_runtime() // 60)
    secs = int(metrics.get_runtime() % 60)
    cv2.putText(frame, "Time: " + str(mins) + "m " + str(secs) + "s | Frames: " + str(metrics.frame_count), 
                (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def process_lidar(data):
    global lidar_data
    points = np.frombuffer(data.raw_data, dtype=np.float32)
    points = points.reshape(-1, 4)  # x, y, z, intensity
    lidar_data = points[:, :3]  # Only use x, y, z

# ============================================
# MAIN
# ============================================

def main():
    global camera_image, lidar_data
    
    print("Loading YOLOv5s (COCO)...")
    model = torch.hub.load(yolo_path, 'yolov5s', source='local', pretrained=True)
    model.conf = 0.4
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # RGB Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # LiDAR Sensor
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '32')
    lidar_bp.set_attribute('points_per_second', '100000')
    lidar_bp.set_attribute('rotation_frequency', '20')
    lidar_bp.set_attribute('range', '50')
    lidar_bp.set_attribute('upper_fov', '10')
    lidar_bp.set_attribute('lower_fov', '-30')
    lidar_transform = carla.Transform(carla.Location(x=0, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_transform, attach_to=ego_vehicle)
    lidar.listen(lambda data: process_lidar(data))
    print("LiDAR attached!")
    
    # Spawn NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(12, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(8):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = Tracker()
    lidar_processor = LiDARProcessor()
    collision_avoidance = CollisionAvoidance()
    metrics = Metrics()
    
    base_throttle = 0.30
    detect_interval = 2
    current_tracks = []
    
    print("")
    print("Waiting for sensors...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None and lidar_data is not None:
            print("Sensors ready!")
            break
    
    print("")
    print("========================================")
    print("FULL AUTONOMOUS SYSTEM WITH LIDAR")
    print("========================================")
    print("Sensors: RGB Camera + 32-channel LiDAR")
    print("Detection: YOLOv5s (COCO)")
    print("Tracking: IoU-based multi-object")
    print("Lane Keeping: Pure Pursuit")
    print("Collision: LiDAR distance-based")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Print stats")
    print("========================================")
    
    cv2.namedWindow('Autonomous Driving + LiDAR', cv2.WINDOW_NORMAL)
    
    try:
        while True:
            world.tick()
            metrics.update_fps()
            
            if camera_image is not None and lidar_data is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                lidar_points = lidar_data.copy()
                
                # === YOLO Detection with LiDAR fusion ===
                if metrics.frame_count % detect_interval == 0:
                    yolo_start = time.time()
                    results = model(frame)
                    detections = filter_detections(results, w, h, lidar_processor, lidar_points)
                    metrics.yolo_latency.append(time.time() - yolo_start)
                else:
                    detections = []
                
                # === Tracking ===
                if len(detections) > 0 or metrics.frame_count % detect_interval == 0:
                    current_tracks = tracker.update(detections)
                
                # === Lane Keeping ===
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                
                metrics.cte_history.append(cte)
                
                # === LiDAR corridor check ===
                lidar_corridor_dist, _ = lidar_processor.get_obstacle_distance(lidar_points)
                
                # === Collision Avoidance ===
                action, throttle_mult, brake, danger_track, closest_dist = collision_avoidance.check(
                    current_tracks, lidar_corridor_dist)
                
                if action in ['BRAKE', 'EMERGENCY']:
                    metrics.brake_events += 1
                if action == 'EMERGENCY':
                    metrics.emergency_events += 1
                
                # === Control ===
                final_throttle = base_throttle * throttle_mult
                
                if curvature > 0.08:
                    final_throttle *= 0.7
                elif curvature > 0.05:
                    final_throttle *= 0.85
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                # === Create LiDAR view ===
                lidar_view = lidar_processor.create_top_down_view(lidar_points)
                
                # === Visualization ===
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks, danger_track)
                frame = draw_hud(frame, metrics, speed, steer, cte, action, 
                                len(current_tracks), final_throttle, closest_dist,
                                len(lidar_points), lidar_view)
                
                cv2.imshow('Autonomous Driving + LiDAR', frame)
            
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('p'):
                print("")
                print("=== STATS ===")
                print("Runtime: " + str(round(metrics.get_runtime(), 1)) + " s")
                print("Frames: " + str(metrics.frame_count))
                print("FPS: " + str(round(metrics.get_fps(), 1)))
                print("YOLO Latency: " + str(round(metrics.get_avg_yolo_latency(), 1)) + " ms")
                print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
                print("Brake Events: " + str(metrics.brake_events))
                print("Emergency Events: " + str(metrics.emergency_events))
                print("=============")
                
    finally:
        print("")
        print("=== FINAL STATS ===")
        print("Runtime: " + str(round(metrics.get_runtime(), 1)) + " s")
        print("Frames: " + str(metrics.frame_count))
        print("Avg FPS: " + str(round(metrics.get_fps(), 1)))
        print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
        print("Brake Events: " + str(metrics.brake_events))
        print("Emergency Events: " + str(metrics.emergency_events))
        print("===================")
        
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        lidar.stop()
        camera.destroy()
        lidar.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()