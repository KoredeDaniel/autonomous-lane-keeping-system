# -*- coding: utf-8 -*-
import csv
import os
import time


class DecisionLogger:
    def __init__(self, out_csv: str):
        self.out_csv = out_csv
        self._init()

    def _init(self):
        os.makedirs(os.path.dirname(self.out_csv), exist_ok=True)
        new_file = not os.path.exists(self.out_csv)
        self.f = open(self.out_csv, "a", newline="")
        self.w = csv.writer(self.f)
        if new_file:
            self.w.writerow([
                "timestamp", "frame_id",
                "speed_kmh", "cte_m", "curvature",
                "traffic_light",
                "action", "target_speed_kmh", "reason"
            ])
            self.f.flush()

    def write(self, frame_id, scene, decision):
        self.w.writerow([
            time.time(), frame_id,
            round(scene.speed_kmh, 2),
            round(scene.cte_m, 3),
            round(scene.curvature, 3),
            scene.traffic_light_state,
            decision.get("action", ""),
            round(float(decision.get("target_speed_kmh", 0.0)), 2),
            decision.get("reason", "").replace("\n", " ")
        ])
        self.f.flush()

    def close(self):
        try:
            self.f.close()
        except:
            pass