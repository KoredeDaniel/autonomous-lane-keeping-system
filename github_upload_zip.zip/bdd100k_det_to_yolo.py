# -*- coding: utf-8 -*-
import json
import os
from pathlib import Path

# =========================================================
# CONFIG: BDD100K location (INSIDE YOUR YOLOV5 DIRECTORY)
# =========================================================
YOLOV5_DIR = r"c:\users\CARLACODES\1_code\yolov5"
BDD_ROOT = os.path.join(YOLOV5_DIR, r"datasets\bdd100k")

TRAIN_JSON = os.path.join(BDD_ROOT, r"labels\det_20\det_train.json")
VAL_JSON   = os.path.join(BDD_ROOT, r"labels\det_20\det_val.json")

TRAIN_IMG_DIR = os.path.join(BDD_ROOT, r"images\100k\train")
VAL_IMG_DIR   = os.path.join(BDD_ROOT, r"images\100k\val")

# Output YOLO dataset
YOLO_OUT = os.path.join(BDD_ROOT, r"bdd_yolo")

# =========================================================
# CLASS MAPPING (BDD -> YOLO ids)
# =========================================================
# 0 person
# 1 car
# 2 motorcycle
# 3 bus
# 4 truck
# 5 traffic_light
# 6 traffic_sign
BDD_TO_YOLO = {
    "person": 0,
    "car": 1,
    "motorcycle": 2,
    "bus": 3,
    "truck": 4,
    "traffic light": 5,
    "traffic sign": 6,
}

YOLO_NAMES = [
    "person",
    "car",
    "motorcycle",
    "bus",
    "truck",
    "traffic_light",
    "traffic_sign",
]

def ensure_dir(p):
    Path(p).mkdir(parents=True, exist_ok=True)

def clamp01(x):
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x

def convert_one_json(json_path, img_dir, out_labels_dir):
    if not os.path.exists(json_path):
        raise FileNotFoundError("Missing JSON: " + json_path)
    if not os.path.isdir(img_dir):
        raise FileNotFoundError("Missing image dir: " + img_dir)

    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    ensure_dir(out_labels_dir)

    total_imgs = 0
    missing_imgs = 0
    total_boxes = 0
    kept_boxes = 0

    for item in data:
        total_imgs += 1
        img_name = item.get("name")
        if not img_name:
            continue

        img_path = os.path.join(img_dir, img_name)
        if not os.path.exists(img_path):
            missing_imgs += 1
            continue

        attrs = item.get("attributes", {})
        w = attrs.get("width", None)
        h = attrs.get("height", None)

        # BDD det JSON normally includes width/height in attributes.
        if not w or not h:
            # If your JSON does not contain w/h, you can add OpenCV read here.
            continue

        yolo_lines = []
        labels = item.get("labels", []) or []

        for lab in labels:
            cat = lab.get("category", "")
            box = lab.get("box2d", None)
            if not box:
                continue

            total_boxes += 1

            if cat not in BDD_TO_YOLO:
                continue

            x1 = float(box["x1"])
            y1 = float(box["y1"])
            x2 = float(box["x2"])
            y2 = float(box["y2"])

            # sanitize bounds
            x1 = max(0.0, min(x1, w - 1))
            y1 = max(0.0, min(y1, h - 1))
            x2 = max(0.0, min(x2, w - 1))
            y2 = max(0.0, min(y2, h - 1))

            bw = x2 - x1
            bh = y2 - y1
            if bw <= 1.0 or bh <= 1.0:
                continue

            xc = (x1 + x2) / 2.0 / w
            yc = (y1 + y2) / 2.0 / h
            wn = bw / w
            hn = bh / h

            xc = clamp01(xc)
            yc = clamp01(yc)
            wn = clamp01(wn)
            hn = clamp01(hn)

            cls = BDD_TO_YOLO[cat]
            yolo_lines.append("%d %.6f %.6f %.6f %.6f" % (cls, xc, yc, wn, hn))
            kept_boxes += 1

        out_txt = os.path.join(out_labels_dir, Path(img_name).with_suffix(".txt").name)
        with open(out_txt, "w", encoding="utf-8") as f:
            f.write("\n".join(yolo_lines))

    print("====================================")
    print("JSON:", json_path)
    print("Images in JSON:", total_imgs)
    print("Missing images skipped:", missing_imgs)
    print("Total boxes:", total_boxes)
    print("Kept boxes:", kept_boxes)
    print("Labels out:", out_labels_dir)
    print("====================================")

def write_yaml(yolo_root):
    yaml_path = os.path.join(yolo_root, "bdd.yaml")
    lines = []
    lines.append("path: " + yolo_root)
    lines.append("train: images/train")
    lines.append("val: images/val")
    lines.append("")
    lines.append("names:")
    for i, n in enumerate(YOLO_NAMES):
        lines.append("  %d: %s" % (i, n))

    with open(yaml_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print("[OK] Wrote:", yaml_path)

def main():
    # output directories
    img_out_train = os.path.join(YOLO_OUT, r"images\train")
    img_out_val   = os.path.join(YOLO_OUT, r"images\val")
    lab_out_train = os.path.join(YOLO_OUT, r"labels\train")
    lab_out_val   = os.path.join(YOLO_OUT, r"labels\val")

    ensure_dir(img_out_train)
    ensure_dir(img_out_val)
    ensure_dir(lab_out_train)
    ensure_dir(lab_out_val)

    # IMPORTANT:
    # For simplicity: copy images into bdd_yolo/images/train and val yourself
    # or run training using the original image folders by editing yaml later.
    #
    # Here we do NOT create junctions automatically.

    print("\n[INFO] NOTE: This script does NOT copy images.")
    print("[INFO] Copy your images into:")
    print("  " + img_out_train)
    print("  " + img_out_val)
    print("OR we can edit bdd.yaml to point to the original image dirs.\n")

    # Convert labels
    convert_one_json(TRAIN_JSON, TRAIN_IMG_DIR, lab_out_train)
    convert_one_json(VAL_JSON, VAL_IMG_DIR, lab_out_val)

    # Write yaml
    write_yaml(YOLO_OUT)

    print("\nDONE.\nNext step: make sure images exist under bdd_yolo/images/train and val.")
    print("Then train with: py -3.7 train.py --data datasets\\bdd100k\\bdd_yolo\\bdd.yaml ...")

if __name__ == "__main__":
    main()