import sys
import time
import random
import numpy as np
import cv2
import math
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla
import torch
from scipy.optimize import linear_sum_assignment

camera_image = None

# ============================================
# STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        self.smoothing_factor = 0.12
        self.max_rate = 0.03
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 5.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
    
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.3
        return max(3.0, min(10.0, lookahead))
    
    def get_waypoints_ahead(self, count=15, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        wp = current_wp
        
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def pure_pursuit(self, lookahead):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        target_wp = current_wp
        remaining = lookahead
        
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = steering / math.radians(70)
        steering = max(-1.0, min(1.0, steering))
        
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        cte = (location.x - wp_loc.x) * math.sin(wp_yaw) - (location.y - wp_loc.y) * math.cos(wp_yaw)
        
        return steering, cte, True
    
    def get_steering(self):
        lookahead = self.get_adaptive_lookahead()
        steering, cte, valid = self.pure_pursuit(lookahead)
        waypoints = self.get_waypoints_ahead()
        curvature = self.calculate_curvature(waypoints)
        return steering, cte, curvature, lookahead, valid, waypoints

# ============================================
# BYTETRACK TRACKER
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.hits = 1
        self.missed = 0
        self.age = 0

class ByteTracker:
    def __init__(self, max_age=30, iou_threshold=0.3):
        self.max_age = max_age
        self.iou_threshold = iou_threshold
        self.tracks = []
        self.next_id = 1
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        for track in self.tracks:
            track.age += 1
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        if len(detections) == 0:
            for track in self.tracks:
                track.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_age]
            return self.tracks
        
        cost_matrix = np.zeros((len(self.tracks), len(detections)))
        for i, track in enumerate(self.tracks):
            for j, det in enumerate(detections):
                cost_matrix[i, j] = 1 - self.iou(track.bbox, det['bbox'])
        
        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        
        matched_tracks = set()
        matched_dets = set()
        
        for i, j in zip(row_ind, col_ind):
            if cost_matrix[i, j] < (1 - self.iou_threshold):
                self.tracks[i].bbox = detections[j]['bbox']
                self.tracks[i].label = detections[j]['label']
                self.tracks[i].conf = detections[j]['conf']
                self.tracks[i].hits += 1
                self.tracks[i].missed = 0
                matched_tracks.add(i)
                matched_dets.add(j)
        
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < self.max_age]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE
# ============================================

class CollisionAvoidance:
    def __init__(self):
        self.danger_zone_y = 400  # Bottom of frame
        self.danger_zone_width = 300  # Center region
        self.brake_distance = 150  # Pixels
        
    def check_danger(self, tracks, frame_width, frame_height):
        """Check if any tracked object is in danger zone"""
        center_x = frame_width // 2
        danger_left = center_x - self.danger_zone_width // 2
        danger_right = center_x + self.danger_zone_width // 2
        
        closest_distance = float('inf')
        danger_object = None
        
        for track in tracks:
            x1, y1, x2, y2 = track.bbox
            obj_center_x = (x1 + x2) // 2
            obj_bottom = y2
            
            # Check if object is in front of vehicle (center region)
            if danger_left < obj_center_x < danger_right:
                # Distance is how close to bottom of frame
                distance = frame_height - obj_bottom
                
                if distance < closest_distance:
                    closest_distance = distance
                    danger_object = track
        
        # Determine action
        if closest_distance < self.brake_distance:
            return 'BRAKE', danger_object, closest_distance
        elif closest_distance < self.brake_distance * 2:
            return 'SLOW', danger_object, closest_distance
        else:
            return 'CLEAR', None, closest_distance

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts = [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.92
        
        points_data = [
            (loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
        ]
        
        for px, py, pts in points_data:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 120, 0))
        frame = cv2.addWeighted(frame, 0.75, overlay, 0.25, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 80, 80), 3)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (80, 80, 255), 3)
    
    return frame

def draw_tracks(frame, tracks):
    colors = {
        'vehicle': (0, 255, 0),
        'pedestrian': (0, 0, 255),
        'traffic_light': (0, 255, 255),
        'traffic_sign': (255, 0, 255)
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        color = colors.get(track.label, (255, 255, 255))
        
        # Draw box
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        
        # Draw label
        label = "ID:" + str(track.id) + " " + track.label
        label_size = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]
        cv2.rectangle(frame, (x1, y1 - 20), (x1 + label_size[0], y1), color, -1)
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
    
    return frame

def draw_hud(frame, speed, steer, status, track_count, danger_status):
    h, w = frame.shape[:2]
    
    # Info panel
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (250, 150), (0, 0, 0), -1)
    frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
    
    # Title
    cv2.putText(frame, "AUTONOMOUS DRIVING", (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    
    # Info
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (20, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Tracking: " + str(track_count) + " objects", (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Status: " + status, (20, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # Danger status
    if danger_status == 'BRAKE':
        cv2.putText(frame, "!! BRAKING !!", (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
    elif danger_status == 'SLOW':
        cv2.putText(frame, "SLOWING DOWN", (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 1)
    else:
        cv2.putText(frame, "Path Clear", (20, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    
    # Steering bar
    bar_x = w // 2
    bar_y = h - 30
    cv2.rectangle(frame, (bar_x - 100, bar_y - 6), (bar_x + 100, bar_y + 6), (40, 40, 40), -1)
    cv2.line(frame, (bar_x, bar_y - 10), (bar_x, bar_y + 10), (200, 200, 200), 2)
    steer_pos = bar_x + int(steer * 100)
    cv2.circle(frame, (steer_pos, bar_y), 10, (0, 255, 255), -1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    # Load YOLOv5 model
    print("Loading YOLOv5 model...")
    model_path = r"c:\users\CARLACODES\1_code\yolov5\runs\train\exp3\weights\best.pt"
    model = torch.hub.load(yolo_path, 'custom', path=model_path, source='local')
    model.conf = 0.4
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    world_map = world.get_map()
    print("Connected!")
    
    # Change to Town03 (more complex)
    print("Loading Town03...")
    world = client.load_world('Town03')
    world_map = world.get_map()
    time.sleep(2)
    print("Town03 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPC vehicles
    print("Spawning NPC vehicles...")
    npc_vehicles = []
    vehicle_bps = blueprint_library.filter('vehicle.*')
    
    for i in range(1, min(30, len(spawn_points))):
        bp = random.choice(list(vehicle_bps))
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " NPC vehicles")
    
    # Spawn pedestrians
    print("Spawning pedestrians...")
    walkers = []
    controllers = []
    walker_bps = blueprint_library.filter('walker.pedestrian.*')
    
    for i in range(20):
        loc = world.get_random_location_from_navigation()
        if loc is not None:
            bp = random.choice(list(walker_bps))
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    
    # Start walkers
    controller_bp = blueprint_library.find('controller.ai.walker')
    for walker in walkers:
        try:
            controller = world.spawn_actor(controller_bp, carla.Transform(), walker)
            controllers.append(controller)
            controller.start()
            controller.go_to_location(world.get_random_location_from_navigation())
            controller.set_max_speed(1.5)
        except:
            pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = ByteTracker(max_age=20, iou_threshold=0.3)
    collision_avoidance = CollisionAvoidance()
    
    # Control parameters
    base_throttle = 0.30
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("FULL AUTONOMOUS DRIVING SYSTEM")
    print("========================================")
    print("- Lane Keeping (Pure Pursuit)")
    print("- Object Detection (YOLOv5)")
    print("- Object Tracking (ByteTrack)")
    print("- Collision Avoidance")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("========================================")
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # === OBJECT DETECTION ===
                results = model(frame)
                dets = results.pandas().xyxy[0]
                
                detections = []
                for idx, det in dets.iterrows():
                    detections.append({
                        'bbox': [int(det['xmin']), int(det['ymin']), int(det['xmax']), int(det['ymax'])],
                        'label': det['name'],
                        'conf': det['confidence']
                    })
                
                # === TRACKING ===
                tracks = tracker.update(detections)
                
                # === COLLISION AVOIDANCE ===
                danger_status, danger_obj, danger_dist = collision_avoidance.check_danger(tracks, w, h)
                
                # === LANE KEEPING ===
                raw_steer, cte, curvature, lookahead, valid, waypoints = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                
                # === CONTROL LOGIC ===
                throttle = base_throttle
                brake = 0.0
                
                # Slow for curves
                if curvature > 0.08:
                    throttle *= 0.7
                elif curvature > 0.05:
                    throttle *= 0.85
                
                # Collision avoidance overrides
                if danger_status == 'BRAKE':
                    throttle = 0.0
                    brake = 0.8
                elif danger_status == 'SLOW':
                    throttle *= 0.5
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                # === VISUALIZATION ===
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, tracks)
                
                # Highlight danger object
                if danger_obj is not None:
                    x1, y1, x2, y2 = danger_obj.bbox
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 4)
                    cv2.putText(frame, "DANGER!", (x1, y1 - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                
                speed = lane_keeper.get_speed_kmh()
                status = "Lane Keeping" if valid else "Searching"
                frame = draw_hud(frame, speed, steer, status, len(tracks), danger_status)
                
                cv2.imshow('Autonomous Driving', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
                
    finally:
        print("Cleaning up...")
        
        # Stop vehicle
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        # Destroy actors
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()