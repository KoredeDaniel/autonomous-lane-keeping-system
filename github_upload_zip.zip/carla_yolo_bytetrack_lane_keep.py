# -*- coding: utf-8 -*-
import sys
import time
import math
import numpy as np
import cv2
import torch
from collections import deque

# -----------------------------
# PATHS
# -----------------------------
carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
yolo_path = r"C:\Users\CARLACODES\1_code\yolov5"
weights_path = r"runs\train\yolov5n_bdd_to_carla_4class\weights\best.pt"

sys.path.append(carla_egg)
sys.path.append(yolo_path)

import carla
from bytetrack.byte_tracker import BYTETracker

camera_image = None
NAMES = ['vehicle', 'pedestrian', 'traffic_light', 'traffic_sign']

# -----------------------------
# CAMERA CALLBACK
# -----------------------------
def process_image(image):
    global camera_image
    arr = np.frombuffer(image.raw_data, dtype=np.uint8)
    arr = arr.reshape((image.height, image.width, 4))
    camera_image = arr[:, :, :3].copy()

# -----------------------------
# STEERING SMOOTHER
# -----------------------------
class StableSteering:
    def __init__(self):
        self.prev_steer = 0.0

    def smooth(self, raw):
        if abs(raw) < 0.01:
            raw = 0.0
        max_rate = 0.05
        diff = raw - self.prev_steer
        if abs(diff) > max_rate:
            raw = self.prev_steer + max_rate * np.sign(diff)
        raw = float(np.clip(raw, -1.0, 1.0))
        self.prev_steer = raw
        return raw

# -----------------------------
# LANE KEEPER (PURE PURSUIT)
# -----------------------------
class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5

    def speed(self):
        v = self.vehicle.get_velocity()
        return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z)

    def speed_kmh(self):
        return self.speed() * 3.6

    def get_waypoints(self, count=35, spacing=1.5):
        loc = self.vehicle.get_location()
        wp = self.map.get_waypoint(loc, project_to_road=True)
        if wp is None:
            return []
        wps = [wp]
        cur = wp
        for _ in range(count):
            nxt = cur.next(spacing)
            if not nxt:
                break
            cur = nxt[0]
            wps.append(cur)
        return wps

    def get_steering(self):
        tf = self.vehicle.get_transform()
        loc = tf.location
        yaw = math.radians(tf.rotation.yaw)

        wp = self.map.get_waypoint(loc, project_to_road=True)
        if wp is None:
            return 0.0, 0.0, False

        v = self.speed()
        lookahead = max(4.0, min(8.0, 4.0 + 0.25*v))

        target = wp
        remaining = lookahead
        while remaining > 0:
            nxt = target.next(min(remaining, 1.5))
            if not nxt:
                break
            target = nxt[0]
            remaining -= 1.5

        tloc = target.transform.location
        dx = tloc.x - loc.x
        dy = tloc.y - loc.y

        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)

        ld2 = local_x*local_x + local_y*local_y
        if ld2 < 0.1:
            return 0.0, 0.0, True

        steer = math.atan2(2.0 * self.wheelbase * local_y, ld2)
        steer = steer / math.radians(60.0)
        steer = float(np.clip(steer, -1.0, 1.0))

        # CTE signed
        wp_loc = wp.transform.location
        wp_yaw = math.radians(wp.transform.rotation.yaw)
        ex = loc.x - wp_loc.x
        ey = loc.y - wp_loc.y
        cte = ex * math.sin(wp_yaw) - ey * math.cos(wp_yaw)

        return steer, cte, True

# -----------------------------
# LANE VISUALIZATION
# -----------------------------
def draw_lane_lines(frame, vehicle, waypoints, fov_deg=90.0):
    if not waypoints or len(waypoints) < 2:
        return frame

    h, w = frame.shape[:2]
    f = w / (2.0 * math.tan(math.radians(fov_deg) / 2.0))

    tf = vehicle.get_transform()
    vx, vy, vz = tf.location.x, tf.location.y, tf.location.z
    vyaw = math.radians(-tf.rotation.yaw)

    center_pts, left_pts, right_pts = [], [], []

    for i, wp in enumerate(waypoints):
        if i % 2 != 0 and i < len(waypoints) - 1:
            continue

        loc = wp.transform.location
        half_w = (wp.lane_width * 0.5) * 0.9

        dx, dy, dz = loc.x - vx, loc.y - vy, loc.z - vz
        lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
        ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
        lz = dz - 1.4

        if lx <= 0.5:
            continue

        u = int(w * 0.5 - f * (ly / lx))
        v = int(h * 0.5 - f * (lz / lx))
        if not (0 <= u < w and 0 <= v < h):
            continue

        center_pts.append((u, v))
        u_left = int(w * 0.5 - f * ((ly + half_w) / lx))
        u_right = int(w * 0.5 - f * ((ly - half_w) / lx))

        if 0 <= u_left < w:
            left_pts.append((u_left, v))
        if 0 <= u_right < w:
            right_pts.append((u_right, v))

    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 100, 100), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (100, 100, 255), 2)
    for i in range(1, len(center_pts)):
        cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)

    return frame

# -----------------------------
# YOLO -> DET ARRAY (anti-house vehicle filter)
# -----------------------------
def yolo_to_dets(results, w, h):
    dets = results.pandas().xyxy[0]
    out = []
    frame_area = float(w * h)

    for _, d in dets.iterrows():
        x1, y1, x2, y2 = int(d['xmin']), int(d['ymin']), int(d['xmax']), int(d['ymax'])
        conf = float(d['confidence'])
        cls = int(d['class'])

        if cls < 0 or cls >= 4:
            continue

        bw = x2 - x1
        bh = y2 - y1
        if bw <= 1 or bh <= 1:
            continue

        area = float(bw * bh)
        ar = float(bw) / float(bh + 1e-6)
        cx = (x1 + x2) * 0.5
        cy = (y1 + y2) * 0.5

        if cls == 0:  # vehicle
            if conf < 0.60:
                continue
            if y1 < int(0.52 * h):
                continue
            if y2 < int(0.62 * h):
                continue
            if cy < (0.62 * h):
                continue
            if bw < 34 or bh < 18:
                continue
            if area > 0.12 * frame_area:
                continue
            if bh > 0.28 * h:
                continue
            if ar < 1.10 or ar > 2.80:
                continue
            if cx < 0.12 * w or cx > 0.88 * w:
                continue

        elif cls == 1:  # pedestrian
            if conf < 0.45:
                continue
            if y2 < int(0.45 * h):
                continue
            if ar > 0.80:
                continue
            if bh < 24:
                continue
            if area > 0.10 * frame_area:
                continue

        elif cls == 2:  # traffic_light
            if conf < 0.40:
                continue
            if area < 70 or area > 0.06 * frame_area:
                continue
            if ar > 1.4:
                continue
            if y1 > int(0.78 * h):
                continue

        elif cls == 3:  # traffic_sign
            if conf < 0.40:
                continue
            if area < 90 or area > 0.08 * frame_area:
                continue
            if ar < 0.55 or ar > 2.0:
                continue

        out.append([x1, y1, x2, y2, conf, cls])

    if len(out) == 0:
        return np.zeros((0, 6), dtype=np.float32)
    return np.array(out, dtype=np.float32)

# -----------------------------
# TRAFFIC CONTROLLER (CARLA ground truth)
# -----------------------------
class TrafficController:
    def __init__(self, vehicle):
        self.vehicle = vehicle

    def get_light_state(self):
        """
        Returns: ('RED'|'YELLOW'|'GREEN'|'NONE')
        """
        try:
            if self.vehicle.is_at_traffic_light():
                tl = self.vehicle.get_traffic_light()
                if tl is None:
                    return 'NONE'
                st = tl.get_state()
                if st == carla.TrafficLightState.Red:
                    return 'RED'
                if st == carla.TrafficLightState.Yellow:
                    return 'YELLOW'
                if st == carla.TrafficLightState.Green:
                    return 'GREEN'
        except:
            pass
        return 'NONE'

    def apply_rule(self, base_throttle):
        """
        Outputs: (throttle_mult, brake, status_text)
        """
        st = self.get_light_state()
        if st == 'RED':
            return 0.0, 0.85, "TL:RED"
        if st == 'YELLOW':
            return 0.3, 0.10, "TL:YELLOW"
        if st == 'GREEN':
            return 1.0, 0.0, "TL:GREEN"
        return 1.0, 0.0, "TL:NONE"

# -----------------------------
# COLLISION GATE (vision + tracking)
# -----------------------------
class CollisionGate:
    def __init__(self, w, h):
        cx = w // 2
        self.left = cx - 140
        self.right = cx + 140
        self.slow_y = int(0.60 * h)
        self.brake_y = int(0.72 * h)
        self.emerg_y = int(0.82 * h)

    def decide(self, tracks):
        """
        Returns: (throttle_mult, brake, mode_text)
        Only uses vehicles/pedestrians in a forward corridor.
        """
        closest_y = 0
        closest_cls = None

        for t in tracks:
            if t.cls not in [0, 1]:  # vehicle or pedestrian
                continue

            # Require stable track before acting (reduces false brakes)
            if getattr(t, "hits", 1) < 2:
                continue

            x1, y1, x2, y2 = map(int, t.bbox)
            cx = (x1 + x2) // 2
            by = y2

            if self.left < cx < self.right:
                if by > closest_y:
                    closest_y = by
                    closest_cls = t.cls

        if closest_y > self.emerg_y:
            return 0.0, 1.0, "EMERGENCY"
        if closest_y > self.brake_y:
            # stronger brake for pedestrian
            if closest_cls == 1:
                return 0.0, 0.8, "PED_BRAKE"
            return 0.10, 0.6, "BRAKE"
        if closest_y > self.slow_y:
            if closest_cls == 1:
                return 0.20, 0.0, "PED_SLOW"
            return 0.45, 0.0, "SLOW"
        return 1.0, 0.0, "CLEAR"

# -----------------------------
# DRAW
# -----------------------------
def draw_tracks(frame, tracks):
    for t in tracks:
        x1, y1, x2, y2 = map(int, t.bbox)
        cls = int(t.cls)
        name = NAMES[cls] if 0 <= cls < len(NAMES) else str(cls)
        txt = f"ID:{t.track_id} {name} {t.score:.2f}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 255), 2)
        cv2.putText(frame, txt, (x1, max(0, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
    return frame

def draw_hud(frame, speed, steer, cte, mode, tl_status, fps):
    h, w = frame.shape[:2]
    cv2.rectangle(frame, (10, 10), (360, 130), (0, 0, 0), -1)
    cv2.putText(frame, "CARLA Perception Stack Demo", (15, 32), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 0), 1)
    cv2.putText(frame, f"Speed: {speed:.1f} km/h", (15, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 1)
    cv2.putText(frame, f"Steer: {steer:.3f}", (15, 76), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 1)
    cv2.putText(frame, f"CTE: {cte:.2f} m", (15, 98), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255, 255, 255), 1)
    cv2.putText(frame, f"Decision: {mode} | {tl_status}", (15, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (0, 255, 255), 1)

    cv2.rectangle(frame, (w - 120, 10), (w - 10, 45), (0, 0, 0), -1)
    cv2.putText(frame, f"{fps:.0f} FPS", (w - 110, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.60, (0, 255, 0), 1)
    return frame

# -----------------------------
# MAIN
# -----------------------------
def main():
    global camera_image

    print("Loading YOLOv5 weights...")
    model = torch.hub.load(yolo_path, 'custom', path=weights_path, source='local')
    model.conf = 0.25
    model.iou = 0.45
    model.max_det = 60
    print("Loaded:", weights_path)

    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(20.0)

    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2.0)
    world_map = world.get_map()
    print("Town02 loaded.")

    blueprint_library = world.get_blueprint_library()
    spawn_points = world_map.get_spawn_points()
    if not spawn_points:
        raise RuntimeError("No spawn points found in Town02.")

    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego = world.spawn_actor(vehicle_bp, spawn_points[0])
    ego.set_autopilot(False)
    print("Ego spawned.")

    cam_bp = blueprint_library.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', '640')
    cam_bp.set_attribute('image_size_y', '480')
    cam_bp.set_attribute('fov', '90')
    cam_tf = carla.Transform(carla.Location(x=2.0, z=1.4))
    cam = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    cam.listen(lambda img: process_image(img))
    print("Camera attached.")

    lane = LaneKeeper(ego, world_map)
    smoother = StableSteering()
    traffic = TrafficController(ego)

    tracker = BYTETracker(track_thresh=0.45, low_thresh=0.15, match_thresh=0.30, max_time_lost=25)
    gate = CollisionGate(640, 480)

    base_throttle = 0.30
    detect_interval = 2
    frame_i = 0

    fps_hist = deque(maxlen=30)
    last_t = time.time()

    print("Waiting for camera...")
    for _ in range(90):
        world.tick()
        time.sleep(0.05)
        if camera_image is not None:
            break

    cv2.namedWindow("CARLA Demo", cv2.WINDOW_NORMAL)
    print("Running. Q quit, W/S throttle.")

    try:
        while True:
            world.tick()
            frame_i += 1

            now = time.time()
            dt = now - last_t
            last_t = now
            if dt > 0:
                fps_hist.append(1.0 / dt)
            fps = float(np.mean(fps_hist)) if len(fps_hist) else 0.0

            if camera_image is None:
                continue

            frame = camera_image.copy()

            # Lane keep
            raw_steer, cte, ok = lane.get_steering()
            steer = smoother.smooth(raw_steer if ok else 0.0)
            waypoints = lane.get_waypoints()

            # Detect
            if frame_i % detect_interval == 0:
                res = model(frame, size=640)
                det_arr = yolo_to_dets(res, 640, 480)
            else:
                det_arr = np.zeros((0, 6), dtype=np.float32)

            # Track
            tracks = tracker.update(det_arr)

            # Vision collision decision
            vis_th_mult, vis_brake, vis_mode = gate.decide(tracks)

            # Traffic light rule decision (ground truth)
            tl_th_mult, tl_brake, tl_status = traffic.apply_rule(base_throttle)

            # Combine rules: traffic light has priority
            # If RED, full stop regardless of perception
            final_throttle = base_throttle
            final_brake = 0.0
            mode = vis_mode

            if tl_status == "TL:RED":
                final_throttle = 0.0
                final_brake = max(final_brake, tl_brake)
                mode = "STOP_RED"
            else:
                # apply vision gating
                final_throttle = base_throttle * vis_th_mult
                final_brake = max(final_brake, vis_brake)

                # apply yellow slow-down
                if tl_status == "TL:YELLOW":
                    final_throttle = min(final_throttle, base_throttle * 0.25)
                    final_brake = max(final_brake, tl_brake)
                    mode = "SLOW_YELLOW" if mode == "CLEAR" else mode

            # Speed cap for stability
            sp = lane.speed_kmh()
            if sp > 35 and final_brake < 0.1:
                final_throttle = min(final_throttle, 0.22)

            # Apply control
            control = carla.VehicleControl()
            control.throttle = float(np.clip(final_throttle, 0.0, 1.0))
            control.steer = float(steer)
            control.brake = float(np.clip(final_brake, 0.0, 1.0))
            ego.apply_control(control)

            # Visualize lane + tracks + HUD
            frame = draw_lane_lines(frame, ego, waypoints, fov_deg=90.0)
            frame = draw_tracks(frame, tracks)
            frame = draw_hud(frame, sp, steer, cte, mode, tl_status, fps)
            cv2.imshow("CARLA Demo", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            if key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle:", round(base_throttle, 2))
            if key == ord('s'):
                base_throttle = max(0.12, base_throttle - 0.02)
                print("Throttle:", round(base_throttle, 2))

    finally:
        print("Cleaning up...")
        try:
            cam.stop()
            cam.destroy()
        except:
            pass
        try:
            ego.destroy()
        except:
            pass
        cv2.destroyAllWindows()
        print("Done.")

if __name__ == "__main__":
    main()