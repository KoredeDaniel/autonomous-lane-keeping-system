import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None
lidar_data = None

COCO_VEHICLE_CLASSES = [2, 3, 5, 7]
COCO_PERSON_CLASS = 0

# ============================================
# LIDAR PROCESSOR (FIXED GROUND FILTERING)
# ============================================

class LiDARProcessor:
    def __init__(self):
        self.lidar_z = 2.4  # LiDAR height on vehicle
        
    def get_obstacle_distance(self, points, lane_width=4.0):
        """Get distance to closest obstacle - FIXED ground filtering"""
        if points is None or len(points) == 0:
            return float('inf')
        
        # Points are in LiDAR frame (LiDAR at z=2.4m above ground)
        # So ground is at approximately z = -2.4 in LiDAR frame
        # Filter:
        # - In front (x > 2m to avoid hood)
        # - Within lane (|y| < lane_width/2)
        # - Above ground (z > -2.0, meaning real z > 0.4m)
        # - Below reasonable height (z < 1.5, meaning real z < 3.9m)
        
        corridor_mask = ((points[:, 0] > 2.0) &   # At least 2m ahead (avoid detecting own car)
                         (points[:, 0] < 50) &     # Within 50m
                         (np.abs(points[:, 1]) < lane_width / 2) &  # Within lane
                         (points[:, 2] > -1.8) &   # Above ground (allow some margin)
                         (points[:, 2] < 1.5))     # Below 4m height
        
        corridor_points = points[corridor_mask]
        
        if len(corridor_points) == 0:
            return float('inf')
        
        # Find closest point
        distances = np.sqrt(corridor_points[:, 0]**2 + corridor_points[:, 1]**2)
        
        return float(np.min(distances))
    
    def create_top_down_view(self, points, size=150, scale=3):
        """Smaller, faster top-down view"""
        view = np.zeros((size, size, 3), dtype=np.uint8)
        
        if points is None or len(points) == 0:
            return view
        
        # Downsample points for speed
        if len(points) > 2000:
            idx = np.random.choice(len(points), 2000, replace=False)
            points = points[idx]
        
        # Filter
        mask = ((points[:, 0] > -5) & (points[:, 0] < 40) &
                (np.abs(points[:, 1]) < 15) &
                (points[:, 2] > -2.5) & (points[:, 2] < 2))
        filtered = points[mask]
        
        if len(filtered) == 0:
            return view
        
        cx, cy = size // 2, size - 15
        
        px = (cx - filtered[:, 1] * scale).astype(int)
        py = (cy - filtered[:, 0] * scale).astype(int)
        
        valid = (px >= 0) & (px < size) & (py >= 0) & (py < size)
        px, py = px[valid], py[valid]
        heights = filtered[valid, 2]
        
        for i in range(len(px)):
            z = heights[i]
            if z < -1.8:
                color = (60, 60, 60)  # Ground
            elif z < 0:
                color = (0, 150, 0)   # Low
            else:
                color = (0, 0, 200)   # High (obstacles)
            cv2.circle(view, (px[i], py[i]), 1, color, -1)
        
        # Ego vehicle
        cv2.rectangle(view, (cx - 3, cy - 2), (cx + 3, cy + 6), (255, 255, 0), -1)
        
        return view

# ============================================
# STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=8)
        self.prev_steer = 0.0
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        weights = np.linspace(0.5, 1.0, len(self.history))
        weighted_avg = np.average(list(self.history), weights=weights)
        smoothed = self.prev_steer + 0.15 * (weighted_avg - self.prev_steer)
        diff = smoothed - self.prev_steer
        if abs(diff) > 0.04:
            smoothed = self.prev_steer + 0.04 * np.sign(diff)
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        
    def get_speed_kmh(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2) * 3.6
    
    def get_waypoints(self, count=12, spacing=2.0):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        return dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Adaptive lookahead
        speed = self.get_speed_kmh() / 3.6
        lookahead = max(4.0, min(10.0, 5.0 + speed * 0.3))
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        cte = self.get_cross_track_error()
        return steering, cte, True

# ============================================
# SIMPLE TRACKER
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf, distance):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.distance = distance
        self.missed = 0

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < 5]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], 
                                         det['conf'], det.get('distance', 999)))
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.2
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].distance = det.get('distance', 999)
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i in range(len(self.tracks)):
            if i not in matched_tracks:
                self.tracks[i].missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'],
                                         det['conf'], det.get('distance', 999)))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < 5]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE (FIXED THRESHOLDS)
# ============================================

class CollisionAvoidance:
    def __init__(self):
        # More reasonable thresholds
        self.emergency_dist = 4.0   # Emergency brake
        self.brake_dist = 8.0       # Hard brake
        self.slow_dist = 15.0       # Slow down
        
    def check(self, tracks, lidar_dist):
        closest_dist = lidar_dist
        danger_track = None
        
        # Check tracked objects
        for track in tracks:
            if track.label in ['vehicle', 'pedestrian']:
                if track.distance < closest_dist:
                    closest_dist = track.distance
                    danger_track = track
        
        if closest_dist < self.emergency_dist:
            return 'EMERGENCY', 0.0, 1.0, danger_track, closest_dist
        elif closest_dist < self.brake_dist:
            return 'BRAKE', 0.1, 0.6, danger_track, closest_dist
        elif closest_dist < self.slow_dist:
            mult = (closest_dist - self.brake_dist) / (self.slow_dist - self.brake_dist)
            return 'SLOW', max(0.4, mult), 0.0, danger_track, closest_dist
        else:
            return 'CLEAR', 1.0, 0.0, None, closest_dist

# ============================================
# FAST DETECTION FILTER
# ============================================

def filter_detections(results, w, h):
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        if class_id in COCO_VEHICLE_CLASSES:
            label = 'vehicle'
        elif class_id == COCO_PERSON_CLASS:
            label = 'pedestrian'
        else:
            continue
        
        # Quick filters
        if conf < 0.5:
            continue
        if (x2 - x1) < 30 or (y2 - y1) < 30:
            continue
        if y1 < h * 0.2:  # Skip top of frame
            continue
        
        # Estimate distance from bbox (rough approximation)
        # Lower in frame = closer
        bbox_bottom = y2
        est_distance = max(3, 50 * (1 - bbox_bottom / h))
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf,
            'distance': est_distance
        })
    
    return filtered

# ============================================
# SIMPLE VISUALIZATION
# ============================================

def draw_lane_simple(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    center_pts = []
    
    for wp in waypoints:
        loc = wp.transform.location
        dx, dy, dz = loc.x - vx, loc.y - vy, loc.z - vz
        lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
        ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
        lz = dz - 1.4
        
        if lx > 0.5:
            u = int(w/2 - f * ly / lx)
            v = int(h/2 - f * lz / lx)
            if 0 <= u < w and 0 <= v < h:
                center_pts.append((u, v))
    
    # Draw path line
    for i in range(1, len(center_pts)):
        cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)
    
    return frame

def draw_tracks_simple(frame, tracks, danger_track):
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = (0, 255, 0) if track.label == 'vehicle' else (0, 165, 255)
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        
        # Distance label
        if track.distance < 100:
            label = str(round(track.distance, 1)) + "m"
            cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def draw_hud_simple(frame, speed, steer, action, closest_dist, fps, lidar_view):
    h, w = frame.shape[:2]
    
    # Compact left panel
    cv2.rectangle(frame, (5, 5), (160, 80), (0, 0, 0), -1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 2)), (10, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (10, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    
    if closest_dist < 100:
        dist_color = (0, 255, 0) if closest_dist > 15 else ((0, 165, 255) if closest_dist > 8 else (0, 0, 255))
        cv2.putText(frame, "Dist: " + str(round(closest_dist, 1)) + "m", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.4, dist_color, 1)
    
    # Status bar
    if action == 'EMERGENCY':
        cv2.rectangle(frame, (5, 85), (160, 105), (0, 0, 200), -1)
        cv2.putText(frame, "EMERGENCY", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    elif action == 'BRAKE':
        cv2.rectangle(frame, (5, 85), (160, 105), (0, 100, 200), -1)
        cv2.putText(frame, "BRAKING", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    elif action == 'SLOW':
        cv2.rectangle(frame, (5, 85), (160, 105), (0, 150, 200), -1)
        cv2.putText(frame, "SLOWING", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    else:
        cv2.rectangle(frame, (5, 85), (160, 105), (0, 150, 0), -1)
        cv2.putText(frame, "CLEAR", (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    # LiDAR view (smaller)
    view_size = lidar_view.shape[0]
    frame[h - view_size - 5:h - 5, w - view_size - 5:w - 5] = lidar_view
    cv2.rectangle(frame, (w - view_size - 5, h - view_size - 5), (w - 5, h - 5), (255, 255, 255), 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def process_lidar(data):
    global lidar_data
    points = np.frombuffer(data.raw_data, dtype=np.float32)
    points = points.reshape(-1, 4)
    lidar_data = points[:, :3]

# ============================================
# MAIN (OPTIMIZED FOR SPEED)
# ============================================

def main():
    global camera_image, lidar_data
    
    print("Loading YOLOv5n (fastest model)...")
    model = torch.hub.load(yolo_path, 'yolov5n', source='local', pretrained=True)  # yolov5n is faster than yolov5s
    model.conf = 0.45
    model.iou = 0.45
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Camera (smaller resolution for speed)
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')  # Reduced from 800
    camera_bp.set_attribute('image_size_y', '480')  # Reduced from 600
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached (640x480)!")
    
    # LiDAR (reduced for speed)
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '16')           # Reduced from 32
    lidar_bp.set_attribute('points_per_second', '50000')  # Reduced from 100000
    lidar_bp.set_attribute('rotation_frequency', '10')    # Reduced from 20
    lidar_bp.set_attribute('range', '40')                 # Reduced from 50
    lidar_bp.set_attribute('upper_fov', '5')
    lidar_bp.set_attribute('lower_fov', '-20')
    lidar_transform = carla.Transform(carla.Location(x=0, z=2.4))
    lidar = world.spawn_actor(lidar_bp, lidar_transform, attach_to=ego_vehicle)
    lidar.listen(lambda data: process_lidar(data))
    print("LiDAR attached (16 channels)!")
    
    # Spawn NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(8, len(spawn_points))):  # Reduced NPCs
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(4):  # Reduced pedestrians
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = Tracker()
    lidar_processor = LiDARProcessor()
    collision_avoidance = CollisionAvoidance()
    
    base_throttle = 0.30
    detect_interval = 3  # Run YOLO every 3 frames (was 2)
    frame_count = 0
    current_tracks = []
    
    # FPS tracking
    fps_history = deque(maxlen=30)
    last_time = time.time()
    
    print("")
    print("Waiting for sensors...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None and lidar_data is not None:
            print("Sensors ready!")
            break
    
    print("")
    print("========================================")
    print("OPTIMIZED AUTONOMOUS + LIDAR")
    print("========================================")
    print("Camera: 640x480 | LiDAR: 16ch | YOLO: n")
    print("Q - Quit | W/S - Speed")
    print("========================================")
    
    cv2.namedWindow('Autonomous + LiDAR', cv2.WINDOW_NORMAL)
    
    try:
        while True:
            world.tick()
            frame_count += 1
            
            # FPS calculation
            current_time = time.time()
            dt = current_time - last_time
            if dt > 0:
                fps_history.append(1.0 / dt)
            last_time = current_time
            fps = np.mean(fps_history) if len(fps_history) > 0 else 0
            
            if camera_image is not None and lidar_data is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                lidar_points = lidar_data.copy()
                
                # === YOLO (every N frames) ===
                if frame_count % detect_interval == 0:
                    results = model(frame, size=480)  # Smaller inference size
                    detections = filter_detections(results, w, h)
                    current_tracks = tracker.update(detections)
                
                # === Lane Keeping ===
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                
                # === LiDAR distance ===
                lidar_dist = lidar_processor.get_obstacle_distance(lidar_points)
                
                # === Collision Avoidance ===
                action, throttle_mult, brake, danger_track, closest_dist = collision_avoidance.check(
                    current_tracks, lidar_dist)
                
                # === Control ===
                final_throttle = base_throttle * throttle_mult
                
                if curvature > 0.08:
                    final_throttle *= 0.7
                elif curvature > 0.05:
                    final_throttle *= 0.85
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                # === Visualization (only every 2 frames) ===
                if frame_count % 2 == 0:
                    lidar_view = lidar_processor.create_top_down_view(lidar_points)
                    frame = draw_lane_simple(frame, ego_vehicle, waypoints)
                    frame = draw_tracks_simple(frame, current_tracks, danger_track)
                    frame = draw_hud_simple(frame, speed, steer, action, closest_dist, fps, lidar_view)
                    cv2.imshow('Autonomous + LiDAR', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
                
    finally:
        print("")
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        lidar.stop()
        camera.destroy()
        lidar.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()