import sys
import os
import time
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

rgb_image = None
seg_image = None

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-0.5, min(0.5, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

def process_rgb(image):
    global rgb_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    rgb_image = array[:, :, :3].copy()

def process_seg(image):
    global seg_image
    # Semantic segmentation stores class ID in red channel
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    # Red channel contains class IDs
    seg_image = array[:, :, 2].copy()  # BGRA format, so index 2 is Red

def get_lane_center(seg_frame):
    height, width = seg_frame.shape
    
    # CARLA semantic segmentation class IDs:
    # 6 = RoadLine
    # 7 = Road
    # 8 = Sidewalk
    
    # Look at bottom portion of frame
    roi_start = int(height * 0.7)
    roi = seg_frame[roi_start:height, :]
    
    # Create masks
    road_mask = (roi == 7).astype(np.uint8) * 255
    lane_mask = (roi == 6).astype(np.uint8) * 255
    
    # Find road boundaries
    road_cols = np.where(np.sum(road_mask, axis=0) > 0)[0]
    
    if len(road_cols) < 20:
        return None, None, None, road_mask, lane_mask, roi_start
    
    # Find lane markings
    lane_cols = np.where(np.sum(lane_mask, axis=0) > 0)[0]
    
    center_x = width // 2
    left_lane = None
    right_lane = None
    lane_center = None
    
    if len(lane_cols) > 5:
        # Separate left and right lane markings
        left_markings = lane_cols[lane_cols < center_x]
        right_markings = lane_cols[lane_cols > center_x]
        
        if len(left_markings) > 0:
            left_lane = int(np.mean(left_markings))
        
        if len(right_markings) > 0:
            right_lane = int(np.mean(right_markings))
    
    # Calculate lane center
    if left_lane is not None and right_lane is not None:
        lane_center = (left_lane + right_lane) // 2
    elif left_lane is not None:
        lane_center = left_lane + 150
    elif right_lane is not None:
        lane_center = right_lane - 150
    else:
        # Fall back to road center
        lane_center = (road_cols[0] + road_cols[-1]) // 2
    
    return lane_center, left_lane, right_lane, road_mask, lane_mask, roi_start

def main():
    global rgb_image, seg_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # RGB Camera
    rgb_bp = blueprint_library.find('sensor.camera.rgb')
    rgb_bp.set_attribute('image_size_x', '640')
    rgb_bp.set_attribute('image_size_y', '480')
    rgb_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    rgb_camera = world.spawn_actor(rgb_bp, camera_transform, attach_to=vehicle)
    rgb_camera.listen(lambda img: process_rgb(img))
    print("RGB camera attached!")
    
    # Semantic Segmentation Camera
    seg_bp = blueprint_library.find('sensor.camera.semantic_segmentation')
    seg_bp.set_attribute('image_size_x', '640')
    seg_bp.set_attribute('image_size_y', '480')
    seg_bp.set_attribute('fov', '90')
    
    seg_camera = world.spawn_actor(seg_bp, camera_transform, attach_to=vehicle)
    seg_camera.listen(lambda img: process_seg(img))
    print("Semantic camera attached!")
    
    # PID Controller for steering
    steering_pid = PIDController(kp=1.2, ki=0.01, kd=0.3)
    
    base_throttle = 0.4
    show_debug = True
    
    print("")
    print("Waiting for cameras...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if rgb_image is not None and seg_image is not None:
            break
    
    if rgb_image is None or seg_image is None:
        print("ERROR: Cameras not working!")
        vehicle.destroy()
        return
    
    print("")
    print("========================================")
    print("SEMANTIC LANE KEEPING v2")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("  D - Toggle debug view")
    print("  A - Auto/Manual toggle")
    print("========================================")
    print("")
    
    last_time = time.time()
    auto_mode = True
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            if dt < 0.01:
                dt = 0.01
            last_time = current_time
            
            if rgb_image is not None and seg_image is not None:
                # Get lane center
                lane_center, left_lane, right_lane, road_mask, lane_mask, roi_start = get_lane_center(seg_image)
                
                # Calculate offset from center
                car_center = 320  # Half of 640
                
                if lane_center is not None:
                    offset = (lane_center - car_center) / 320.0  # Normalize to -1 to 1
                    detected = True
                else:
                    offset = 0
                    detected = False
                
                # Calculate steering
                if auto_mode and detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    if not detected:
                        steering_pid.reset()
                
                # Apply control
                if auto_mode:
                    control = carla.VehicleControl()
                    control.throttle = base_throttle
                    control.steer = float(steering)
                    control.brake = 0.0
                    vehicle.apply_control(control)
                
                # Draw on RGB image
                display = rgb_image.copy()
                height, width = display.shape[:2]
                
                # Draw ROI line
                cv2.line(display, (0, roi_start), (width, roi_start), (100, 100, 100), 1)
                
                # Draw lane lines
                if left_lane is not None:
                    cv2.line(display, (left_lane, roi_start), (left_lane, height), (255, 0, 0), 4)
                    cv2.putText(display, "L", (left_lane - 10, roi_start - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)
                
                if right_lane is not None:
                    cv2.line(display, (right_lane, roi_start), (right_lane, height), (0, 0, 255), 4)
                    cv2.putText(display, "R", (right_lane - 10, roi_start - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
                
                # Draw lane center (green)
                if lane_center is not None:
                    cv2.line(display, (lane_center, roi_start), (lane_center, height), (0, 255, 0), 3)
                
                # Draw car center (yellow)
                cv2.line(display, (car_center, height - 80), (car_center, height), (0, 255, 255), 4)
                cv2.circle(display, (car_center, height - 40), 8, (0, 255, 255), -1)
                
                # Draw steering indicator
                steer_x = car_center + int(steering * 100)
                cv2.arrowedLine(display, (car_center, 450), (steer_x, 450), (255, 255, 0), 3)
                
                # Info text
                mode_text = "AUTO" if auto_mode else "MANUAL"
                mode_color = (0, 255, 0) if auto_mode else (0, 0, 255)
                cv2.putText(display, mode_text, (550, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, mode_color, 2)
                
                status = "LANE OK" if detected else "NO LANE"
                status_color = (0, 255, 0) if detected else (0, 165, 255)
                cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
                
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(display, "Speed: " + str(round(base_throttle, 2)), (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                cv2.imshow('Lane Keeping', display)
                
                # Debug views
                if show_debug:
                    # Colorize segmentation for viewing
                    seg_colored = np.zeros((seg_image.shape[0], seg_image.shape[1], 3), dtype=np.uint8)
                    seg_colored[seg_image == 6] = [0, 255, 255]  # RoadLine = Yellow
                    seg_colored[seg_image == 7] = [128, 64, 128]  # Road = Purple
                    seg_colored[seg_image == 8] = [244, 35, 232]  # Sidewalk = Pink
                    seg_colored[seg_image == 4] = [0, 255, 0]     # Vegetation = Green
                    seg_colored[seg_image == 10] = [0, 0, 255]    # Vehicle = Red
                    cv2.imshow('Segmentation', seg_colored)
                    
                    # Show masks
                    combined_mask = np.zeros((road_mask.shape[0], road_mask.shape[1], 3), dtype=np.uint8)
                    combined_mask[:, :, 0] = lane_mask  # Lane in blue
                    combined_mask[:, :, 1] = road_mask  # Road in green
                    cv2.imshow('Road (green) + Lane (blue)', combined_mask)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.8, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('d'):
                show_debug = not show_debug
                if not show_debug:
                    cv2.destroyWindow('Segmentation')
                    cv2.destroyWindow('Road (green) + Lane (blue)')
                print("Debug: " + str(show_debug))
            elif key == ord('a'):
                auto_mode = not auto_mode
                print("Mode: " + ("AUTO" if auto_mode else "MANUAL"))
                if not auto_mode:
                    control = carla.VehicleControl()
                    control.throttle = 0.0
                    control.brake = 1.0
                    vehicle.apply_control(control)
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        rgb_camera.stop()
        rgb_camera.destroy()
        seg_camera.stop()
        seg_camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()