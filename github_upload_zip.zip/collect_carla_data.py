import sys
import os
import time
import random
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None
depth_image = None

# Output directory
output_dir = r"c:\users\CARLACODES\1_code\carla_dataset"
images_dir = os.path.join(output_dir, "images")
labels_dir = os.path.join(output_dir, "labels")

os.makedirs(images_dir, exist_ok=True)
os.makedirs(labels_dir, exist_ok=True)

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def get_bounding_boxes(world, camera, vehicle):
    """Get 2D bounding boxes for all vehicles and pedestrians"""
    bboxes = []
    
    # Camera parameters
    image_w = int(camera.attributes['image_size_x'])
    image_h = int(camera.attributes['image_size_y'])
    fov = float(camera.attributes['fov'])
    
    # Camera intrinsic matrix
    focal = image_w / (2.0 * np.tan(fov * np.pi / 360.0))
    K = np.array([
        [focal, 0, image_w / 2],
        [0, focal, image_h / 2],
        [0, 0, 1]
    ])
    
    # Get camera transform
    cam_transform = camera.get_transform()
    cam_loc = cam_transform.location
    cam_rot = cam_transform.rotation
    
    # World to camera matrix
    cam_matrix = np.array(cam_transform.get_inverse_matrix())
    
    # Get all actors
    actors = world.get_actors()
    vehicles = actors.filter('vehicle.*')
    walkers = actors.filter('walker.pedestrian.*')
    
    ego_id = vehicle.id
    
    for actor in list(vehicles) + list(walkers):
        if actor.id == ego_id:
            continue
        
        # Get actor bounding box
        bbox = actor.bounding_box
        actor_transform = actor.get_transform()
        
        # Get 8 corners of bounding box
        corners = []
        extent = bbox.extent
        
        for x in [-extent.x, extent.x]:
            for y in [-extent.y, extent.y]:
                for z in [-extent.z, extent.z]:
                    corner = carla.Location(x=x, y=y, z=z)
                    corner = bbox.location + corner
                    corner = actor_transform.transform(corner)
                    corners.append(corner)
        
        # Project corners to image
        points_2d = []
        for corner in corners:
            # World to camera
            point = np.array([corner.x, corner.y, corner.z, 1])
            cam_point = np.dot(cam_matrix, point)
            
            # Camera coordinates
            x = cam_point[1]
            y = -cam_point[2]
            z = cam_point[0]
            
            if z > 0:  # In front of camera
                px = int(K[0, 0] * x / z + K[0, 2])
                py = int(K[1, 1] * y / z + K[1, 2])
                points_2d.append((px, py))
        
        if len(points_2d) >= 4:
            xs = [p[0] for p in points_2d]
            ys = [p[1] for p in points_2d]
            
            x1 = max(0, min(xs))
            y1 = max(0, min(ys))
            x2 = min(image_w, max(xs))
            y2 = min(image_h, max(ys))
            
            # Filter valid boxes
            if x2 > x1 and y2 > y1:
                box_w = x2 - x1
                box_h = y2 - y1
                
                if box_w > 10 and box_h > 10 and box_w < image_w * 0.9 and box_h < image_h * 0.9:
                    if 'vehicle' in actor.type_id:
                        class_id = 0  # vehicle
                    else:
                        class_id = 1  # pedestrian
                    
                    bboxes.append({
                        'class': class_id,
                        'bbox': [x1, y1, x2, y2]
                    })
    
    return bboxes

def save_yolo_format(bboxes, image_w, image_h, label_path):
    """Save bounding boxes in YOLO format"""
    with open(label_path, 'w') as f:
        for bbox in bboxes:
            x1, y1, x2, y2 = bbox['bbox']
            class_id = bbox['class']
            
            # Convert to YOLO format (center_x, center_y, width, height) normalized
            cx = ((x1 + x2) / 2) / image_w
            cy = ((y1 + y2) / 2) / image_h
            w = (x2 - x1) / image_w
            h = (y2 - y1) / image_h
            
            f.write(str(class_id) + " " + str(cx) + " " + str(cy) + " " + str(w) + " " + str(h) + "\n")

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    vehicle.set_autopilot(True)
    print("Ego vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPC vehicles
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(50, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    # Spawn pedestrians
    walkers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    
    for i in range(20):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("CARLA DATASET COLLECTION")
    print("========================================")
    print("Collecting images with bounding boxes...")
    print("Output: " + output_dir)
    print("Q - Quit | S - Save image manually")
    print("========================================")
    
    frame_count = 0
    saved_count = 0
    save_interval = 10  # Save every 10 frames
    target_images = 500
    
    try:
        while saved_count < target_images:
            world.tick()
            frame_count += 1
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # Get bounding boxes
                bboxes = get_bounding_boxes(world, camera, vehicle)
                
                # Draw boxes for visualization
                for bbox in bboxes:
                    x1, y1, x2, y2 = bbox['bbox']
                    color = (0, 255, 0) if bbox['class'] == 0 else (0, 0, 255)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                
                # Auto-save at interval if there are detections
                if frame_count % save_interval == 0 and len(bboxes) > 0:
                    img_name = "frame_" + str(saved_count).zfill(5) + ".jpg"
                    label_name = "frame_" + str(saved_count).zfill(5) + ".txt"
                    
                    cv2.imwrite(os.path.join(images_dir, img_name), camera_image)
                    save_yolo_format(bboxes, w, h, os.path.join(labels_dir, label_name))
                    
                    saved_count += 1
                    print("Saved " + str(saved_count) + "/" + str(target_images) + " - Objects: " + str(len(bboxes)))
                
                # Display
                cv2.putText(frame, "Collecting: " + str(saved_count) + "/" + str(target_images), (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
                cv2.putText(frame, "Objects: " + str(len(bboxes)), (10, 60), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
                
                cv2.imshow('Data Collection', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('s'):
                # Manual save
                if camera_image is not None and len(bboxes) > 0:
                    img_name = "frame_" + str(saved_count).zfill(5) + ".jpg"
                    label_name = "frame_" + str(saved_count).zfill(5) + ".txt"
                    
                    cv2.imwrite(os.path.join(images_dir, img_name), camera_image)
                    save_yolo_format(bboxes, w, h, os.path.join(labels_dir, label_name))
                    
                    saved_count += 1
                    print("Manually saved " + str(saved_count))
                    
    finally:
        print("")
        print("Collected " + str(saved_count) + " images")
        print("Saved to: " + output_dir)
        print("")
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        cv2.destroyAllWindows()
        print("Done!")
        
        # Create data.yaml for training
        yaml_content = """path: c:/users/CARLACODES/1_code/carla_dataset
train: images
val: images

names:
  0: vehicle
  1: pedestrian
"""
        with open(os.path.join(output_dir, "data.yaml"), 'w') as f:
            f.write(yaml_content)
        print("Created data.yaml")

if __name__ == "__main__":
    main()