import sys
import time
import random
import numpy as np
import cv2
import math
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla
import torch

camera_image = None

# ============================================
# EVALUATION METRICS
# ============================================

class Metrics:
    def __init__(self):
        # FPS tracking
        self.fps_history = deque(maxlen=30)
        self.last_time = time.time()
        
        # Latency tracking
        self.yolo_latency = deque(maxlen=30)
        self.tracking_latency = deque(maxlen=30)
        self.lane_latency = deque(maxlen=30)
        self.total_latency = deque(maxlen=30)
        
        # Detection metrics
        self.detection_counts = deque(maxlen=100)
        self.track_counts = deque(maxlen=100)
        
        # Driving metrics
        self.steering_history = deque(maxlen=100)
        self.speed_history = deque(maxlen=100)
        self.cte_history = deque(maxlen=100)  # Cross-track error
        
        # Safety metrics
        self.brake_events = 0
        self.close_calls = 0
        self.collisions = 0
        
        # Frame counter
        self.frame_count = 0
        self.start_time = time.time()
    
    def update_fps(self):
        current_time = time.time()
        dt = current_time - self.last_time
        if dt > 0:
            fps = 1.0 / dt
            self.fps_history.append(fps)
        self.last_time = current_time
        self.frame_count += 1
    
    def get_fps(self):
        if len(self.fps_history) > 0:
            return np.mean(self.fps_history)
        return 0.0
    
    def get_avg_latency(self, latency_deque):
        if len(latency_deque) > 0:
            return np.mean(latency_deque) * 1000  # Convert to ms
        return 0.0
    
    def get_runtime(self):
        return time.time() - self.start_time
    
    def get_avg_cte(self):
        if len(self.cte_history) > 0:
            return np.mean(np.abs(list(self.cte_history)))
        return 0.0
    
    def get_steering_smoothness(self):
        """Lower is smoother - measures steering changes"""
        if len(self.steering_history) < 2:
            return 0.0
        steers = list(self.steering_history)
        diffs = [abs(steers[i] - steers[i-1]) for i in range(1, len(steers))]
        return np.mean(diffs)

# ============================================
# IMPROVED STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        self.smoothing_factor = 0.12
        self.max_rate = 0.025  # Reduced for smoother steering
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        
        # Exponential smoothing
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        
        # Rate limiting
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        
        self.prev_steer = smoothed
        return smoothed
    
    def reset(self):
        self.history.clear()
        self.prev_steer = 0.0

# ============================================
# IMPROVED LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 5.0
        self.min_lookahead = 3.0
        self.max_lookahead = 10.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        """Adjust lookahead based on speed"""
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.3
        return max(self.min_lookahead, min(self.max_lookahead, lookahead))
    
    def get_waypoints(self, count=15, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        """Calculate path curvature to detect curves"""
        if len(waypoints) < 3:
            return 0.0
        
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        """Calculate cross-track error (distance from lane center)"""
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        
        if current_wp is None:
            return 0.0
        
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        
        # Calculate lateral offset
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        cte = dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
        
        return cte
    
    def get_steering(self):
        """Pure pursuit steering with adaptive lookahead"""
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Adaptive lookahead based on speed
        lookahead = self.get_adaptive_lookahead()
        
        # Get target waypoint
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        # Transform to vehicle coordinates
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure pursuit formula
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        # Get cross-track error
        cte = self.get_cross_track_error()
        
        return steering, cte, True

# ============================================
# TRACKER
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
        self.max_missed = 8
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
        
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.25
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE
# ============================================

class CollisionAvoidance:
    def __init__(self, frame_width, frame_height):
        self.frame_width = frame_width
        self.frame_height = frame_height
        
        center = frame_width // 2
        self.danger_left = center - 150
        self.danger_right = center + 150
        
        self.emergency_brake_y = 400
        self.hard_brake_y = 350
        self.slow_down_y = 280
        
    def check(self, tracks, current_speed):
        closest_y = 0
        danger_track = None
        
        for track in tracks:
            if track.label not in ['vehicle', 'pedestrian']:
                continue
            
            x1, y1, x2, y2 = track.bbox
            center_x = (x1 + x2) // 2
            bottom_y = y2
            
            if self.danger_left < center_x < self.danger_right:
                if bottom_y > closest_y:
                    closest_y = bottom_y
                    danger_track = track
        
        if closest_y > self.emergency_brake_y:
            return 'EMERGENCY', 0.0, 1.0, danger_track
        elif closest_y > self.hard_brake_y:
            return 'BRAKE', 0.0, 0.7, danger_track
        elif closest_y > self.slow_down_y:
            return 'SLOW', 0.3, 0.0, danger_track
        else:
            return 'CLEAR', 1.0, 0.0, None

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
                            (loc.x, loc.y, center_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    # Fill lane
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 100, 0))
        frame = cv2.addWeighted(frame, 0.75, overlay, 0.25, 0)
    
    # Draw lines
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 3)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 3)
    
    # Draw center line (dashed yellow)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 200, 200), 2)
    
    return frame

def draw_tracks(frame, tracks, danger_track):
    colors = {
        'vehicle': (0, 255, 0),
        'pedestrian': (0, 165, 255),
        'traffic_light': (0, 255, 255),
        'traffic_sign': (255, 0, 255)
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = colors.get(track.label, (255, 255, 255))
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        label = "ID" + str(track.id) + " " + track.label[:8]
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def draw_metrics(frame, metrics, speed, steer, cte, action, track_count):
    h, w = frame.shape[:2]
    
    # Main HUD - Left panel
    cv2.rectangle(frame, (5, 5), (210, 130), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (210, 130), (100, 100, 100), 1)
    
    cv2.putText(frame, "AUTONOMOUS DRIVING", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 58), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (10, 74), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Objects: " + str(track_count), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    
    # Status
    if action == 'EMERGENCY':
        cv2.putText(frame, "!! EMERGENCY !!", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    elif action == 'BRAKE':
        cv2.putText(frame, "BRAKING", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 100, 255), 1)
    elif action == 'SLOW':
        cv2.putText(frame, "SLOWING", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 200, 255), 1)
    else:
        cv2.putText(frame, "Clear", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
    
    # Metrics panel - Right side
    cv2.rectangle(frame, (w - 175, 5), (w - 5, 115), (0, 0, 0), -1)
    cv2.rectangle(frame, (w - 175, 5), (w - 5, 115), (100, 100, 100), 1)
    
    fps = metrics.get_fps()
    yolo_lat = metrics.get_avg_latency(metrics.yolo_latency)
    track_lat = metrics.get_avg_latency(metrics.tracking_latency)
    lane_lat = metrics.get_avg_latency(metrics.lane_latency)
    total_lat = metrics.get_avg_latency(metrics.total_latency)
    runtime = metrics.get_runtime()
    
    cv2.putText(frame, "METRICS", (w - 170, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (w - 170, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "YOLO: " + str(round(yolo_lat, 1)) + " ms", (w - 170, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Track: " + str(round(track_lat, 1)) + " ms", (w - 170, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Lane: " + str(round(lane_lat, 1)) + " ms", (w - 170, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Total: " + str(round(total_lat, 1)) + " ms", (w - 170, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # Runtime and frame count at bottom
    mins = int(runtime // 60)
    secs = int(runtime % 60)
    cv2.putText(frame, "Time: " + str(mins) + "m " + str(secs) + "s | Frames: " + str(metrics.frame_count), 
                (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
    
    # Steering indicator
    bar_x = w // 2
    bar_y = h - 35
    cv2.rectangle(frame, (bar_x - 100, bar_y - 6), (bar_x + 100, bar_y + 6), (40, 40, 40), -1)
    cv2.line(frame, (bar_x, bar_y - 10), (bar_x, bar_y + 10), (200, 200, 200), 2)
    steer_pos = bar_x + int(steer * 100)
    cv2.circle(frame, (steer_pos, bar_y), 8, (0, 255, 255), -1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def filter_detections(dets, frame_width, frame_height):
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        label = det['name']
        conf = det['confidence']
        
        bw = x2 - x1
        bh = y2 - y1
        aspect_ratio = bw / bh if bh > 0 else 0
        
        valid = True
        
        if conf < 0.55:
            valid = False
        
        if bw < 25 or bh < 25:
            valid = False
        if bw > frame_width * 0.8 or bh > frame_height * 0.8:
            valid = False
        
        if y1 < frame_height * 0.2 and label == 'vehicle':
            valid = False
        
        if label == 'vehicle':
            if aspect_ratio < 0.3 or aspect_ratio > 4.0:
                valid = False
        
        if label == 'pedestrian':
            if aspect_ratio > 1.5:
                valid = False
        
        if valid:
            filtered.append({
                'bbox': [x1, y1, x2, y2],
                'label': label,
                'conf': conf
            })
    
    return filtered

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    # Load BDD100K model
    print("Loading YOLOv5 (BDD100K)...")
    model_path = r"c:\users\CARLACODES\1_code\yolov5\runs\train\exp3\weights\best.pt"
    model = torch.hub.load(yolo_path, 'custom', path=model_path, source='local')
    model.conf = 0.5
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = blueprint_library.filter('vehicle.*')
    
    for i in range(1, min(12, len(spawn_points))):
        bp = random.choice(list(vehicle_bps))
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = blueprint_library.filter('walker.pedestrian.*')
    
    for i in range(8):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(list(walker_bps))
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
            except:
                pass
    
    controller_bp = blueprint_library.find('controller.ai.walker')
    for walker in walkers:
        try:
            ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
            controllers.append(ctrl)
            ctrl.start()
            ctrl.go_to_location(world.get_random_location_from_navigation())
            ctrl.set_max_speed(1.2)
        except:
            pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = Tracker()
    collision_avoidance = CollisionAvoidance(640, 480)
    metrics = Metrics()
    
    base_throttle = 0.28
    detect_interval = 2
    current_tracks = []
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("AUTONOMOUS DRIVING SYSTEM v3")
    print("========================================")
    print("- Lane Keeping (Pure Pursuit + Adaptive)")
    print("- Object Detection (YOLOv5 BDD100K)")
    print("- Object Tracking (ByteTrack)")
    print("- Collision Avoidance")
    print("- Real-time Metrics")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Print stats")
    print("========================================")
    
    try:
        while True:
            frame_start = time.time()
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # Update FPS
                metrics.update_fps()
                
                # === YOLO DETECTION ===
                yolo_start = time.time()
                if metrics.frame_count % detect_interval == 0:
                    results = model(frame)
                    dets = results.pandas().xyxy[0]
                    detections = filter_detections(dets, w, h)
                    metrics.detection_counts.append(len(detections))
                else:
                    detections = []
                yolo_time = time.time() - yolo_start
                if metrics.frame_count % detect_interval == 0:
                    metrics.yolo_latency.append(yolo_time)
                
                # === TRACKING ===
                track_start = time.time()
                if len(detections) > 0 or metrics.frame_count % detect_interval == 0:
                    current_tracks = tracker.update(detections)
                track_time = time.time() - track_start
                metrics.tracking_latency.append(track_time)
                metrics.track_counts.append(len(current_tracks))
                
                # === LANE KEEPING ===
                lane_start = time.time()
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                lane_time = time.time() - lane_start
                metrics.lane_latency.append(lane_time)
                
                # Record metrics
                metrics.steering_history.append(steer)
                metrics.cte_history.append(cte)
                
                # === COLLISION AVOIDANCE ===
                speed = lane_keeper.get_speed()
                action, throttle_mult, brake, danger_track = collision_avoidance.check(current_tracks, speed)
                
                if action in ['BRAKE', 'EMERGENCY']:
                    metrics.brake_events += 1
                if action == 'EMERGENCY':
                    metrics.close_calls += 1
                
                # === CONTROL ===
                final_throttle = base_throttle * throttle_mult
                
                # Slow for curves
                if curvature > 0.08:
                    final_throttle *= 0.7
                elif curvature > 0.05:
                    final_throttle *= 0.85
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                # Record speed
                speed_kmh = lane_keeper.get_speed_kmh()
                metrics.speed_history.append(speed_kmh)
                
                # Total frame time
                total_time = time.time() - frame_start
                metrics.total_latency.append(total_time)
                
                # === VISUALIZATION ===
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks, danger_track)
                frame = draw_metrics(frame, metrics, speed_kmh, steer, cte, action, len(current_tracks))
                
                cv2.imshow('Autonomous Driving', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.45, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('p'):
                # Print detailed stats
                print("")
                print("=== PERFORMANCE STATS ===")
                print("Runtime: " + str(round(metrics.get_runtime(), 1)) + " seconds")
                print("Frames: " + str(metrics.frame_count))
                print("Avg FPS: " + str(round(metrics.get_fps(), 1)))
                print("")
                print("=== LATENCY ===")
                print("YOLO: " + str(round(metrics.get_avg_latency(metrics.yolo_latency), 1)) + " ms")
                print("Tracking: " + str(round(metrics.get_avg_latency(metrics.tracking_latency), 1)) + " ms")
                print("Lane: " + str(round(metrics.get_avg_latency(metrics.lane_latency), 1)) + " ms")
                print("Total: " + str(round(metrics.get_avg_latency(metrics.total_latency), 1)) + " ms")
                print("")
                print("=== DRIVING ===")
                print("Avg Speed: " + str(round(np.mean(metrics.speed_history), 1)) + " km/h")
                print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
                print("Steering Smoothness: " + str(round(metrics.get_steering_smoothness(), 4)))
                print("")
                print("=== SAFETY ===")
                print("Brake Events: " + str(metrics.brake_events))
                print("Close Calls: " + str(metrics.close_calls))
                print("=========================")
                print("")
                
    finally:
        # Print final stats
        print("")
        print("========== FINAL STATS ==========")
        print("Total Runtime: " + str(round(metrics.get_runtime(), 1)) + " seconds")
        print("Total Frames: " + str(metrics.frame_count))
        print("Average FPS: " + str(round(metrics.get_fps(), 1)))
        print("Average YOLO Latency: " + str(round(metrics.get_avg_latency(metrics.yolo_latency), 1)) + " ms")
        print("Average Tracking Latency: " + str(round(metrics.get_avg_latency(metrics.tracking_latency), 1)) + " ms")
        print("Average Lane Latency: " + str(round(metrics.get_avg_latency(metrics.lane_latency), 1)) + " ms")
        print("Average Total Latency: " + str(round(metrics.get_avg_latency(metrics.total_latency), 1)) + " ms")
        print("Average Speed: " + str(round(np.mean(metrics.speed_history), 1)) + " km/h")
        print("Average CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
        print("Steering Smoothness: " + str(round(metrics.get_steering_smoothness(), 4)))
        print("Brake Events: " + str(metrics.brake_events))
        print("Close Calls: " + str(metrics.close_calls))
        print("=================================")
        print("")
        
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()