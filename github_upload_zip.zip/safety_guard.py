# -*- coding: utf-8 -*-
from typing import Dict, Any
from .scene_state import SceneState


class SafetyGuard:
    def __init__(self):
        pass

    def override(self, scene: SceneState, decision: Dict[str, Any], emergency_flag: bool) -> Dict[str, Any]:
        tl = scene.traffic_light_state.upper()

        # Hard safety constraints
        if tl == "RED":
            decision["action"] = "STOP"
            decision["target_speed_kmh"] = 0.0
            decision["reason"] = "SafetyGuard: RED light override. Stop."
            return decision

        if emergency_flag:
            decision["action"] = "STOP"
            decision["target_speed_kmh"] = 0.0
            decision["reason"] = "SafetyGuard: Emergency collision risk override. Stop."
            return decision

        # Keep bounds sane
        v = float(decision.get("target_speed_kmh", 0.0))
        if v < 0.0:
            decision["target_speed_kmh"] = 0.0
        if v > 45.0:
            decision["target_speed_kmh"] = 45.0
        return decision