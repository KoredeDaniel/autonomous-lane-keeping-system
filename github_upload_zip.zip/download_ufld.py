import os
import urllib.request

ufld_dir = r"c:\users\CARLACODES\1_code\ufld"
model_path = os.path.join(ufld_dir, "tusimple_18.pth")

print("Downloading Ultra-Fast Lane Detection model...")
print("Size: ~45MB, please wait...")

url = "https://github.com/cfzd/Ultra-Fast-Lane-Detection/releases/download/v1.0/tusimple_18.pth"

try:
    urllib.request.urlretrieve(url, model_path)
    print("")
    print("Download complete!")
    print("Saved to: " + model_path)
except Exception as e:
    print("Download failed: " + str(e))
    print("")
    print("Please download manually from:")
    print("https://github.com/cfzd/Ultra-Fast-Lane-Detection/releases")
    print("Save as: " + model_path)