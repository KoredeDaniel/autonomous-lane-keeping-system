import sys
import time
import numpy as np
import cv2
import math

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None
lidar_data = None

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def process_lidar(data):
    global lidar_data
    # LiDAR returns points as (x, y, z, intensity)
    points = np.frombuffer(data.raw_data, dtype=np.float32)
    points = points.reshape(-1, 4)
    lidar_data = points

def lidar_to_2d(points, img_width, img_height):
    """Project LiDAR points to 2D for visualization"""
    # Filter points in front of vehicle
    front_points = points[points[:, 0] > 0]  # x > 0 (forward)
    
    if len(front_points) == 0:
        return []
    
    # Simple top-down projection
    x = front_points[:, 0]  # forward
    y = front_points[:, 1]  # left/right
    z = front_points[:, 2]  # up/down
    
    # Scale to image
    scale = 10  # pixels per meter
    cx, cy = img_width // 2, img_height - 50
    
    px = (cx - y * scale).astype(int)
    py = (cy - x * scale).astype(int)
    
    # Filter valid points
    valid = (px >= 0) & (px < img_width) & (py >= 0) & (py < img_height)
    
    return list(zip(px[valid], py[valid], z[valid]))

def get_closest_obstacle(points):
    """Find closest obstacle in front of vehicle"""
    if points is None or len(points) == 0:
        return None, float('inf')
    
    # Filter points in front and at reasonable height (not ground)
    front = points[(points[:, 0] > 1) &  # At least 1m ahead
                   (points[:, 0] < 50) &  # Within 50m
                   (np.abs(points[:, 1]) < 3) &  # Within 3m left/right
                   (points[:, 2] > -1.5) &  # Above ground
                   (points[:, 2] < 2)]  # Below 2m height
    
    if len(front) == 0:
        return None, float('inf')
    
    # Calculate distance to each point
    distances = np.sqrt(front[:, 0]**2 + front[:, 1]**2)
    min_idx = np.argmin(distances)
    
    return front[min_idx], distances[min_idx]

def main():
    global camera_image, lidar_data
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # RGB Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # LiDAR Sensor
    lidar_bp = blueprint_library.find('sensor.lidar.ray_cast')
    lidar_bp.set_attribute('channels', '32')  # 32 laser channels
    lidar_bp.set_attribute('points_per_second', '100000')
    lidar_bp.set_attribute('rotation_frequency', '20')  # 20 Hz
    lidar_bp.set_attribute('range', '50')  # 50 meters
    lidar_bp.set_attribute('upper_fov', '10')  # degrees
    lidar_bp.set_attribute('lower_fov', '-30')  # degrees
    
    lidar_transform = carla.Transform(carla.Location(x=0, z=2.4))  # On roof
    lidar = world.spawn_actor(lidar_bp, lidar_transform, attach_to=vehicle)
    lidar.listen(lambda data: process_lidar(data))
    print("LiDAR attached!")
    
    # Spawn NPC vehicles
    import random
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(10, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " NPC vehicles")
    
    print("")
    print("Waiting for sensors...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None and lidar_data is not None:
            print("Sensors ready!")
            break
    
    print("")
    print("========================================")
    print("LIDAR + CAMERA TEST")
    print("========================================")
    print("Q - Quit | W/S - Speed")
    print("========================================")
    
    cv2.namedWindow('Camera + LiDAR', cv2.WINDOW_NORMAL)
    
    throttle = 0.3
    
    try:
        while True:
            world.tick()
            
            control = carla.VehicleControl()
            control.throttle = throttle
            vehicle.apply_control(control)
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # Process LiDAR
                if lidar_data is not None:
                    closest_point, closest_dist = get_closest_obstacle(lidar_data)
                    
                    # Draw LiDAR info
                    cv2.rectangle(frame, (5, 5), (300, 100), (0, 0, 0), -1)
                    cv2.putText(frame, "LIDAR + CAMERA", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                    cv2.putText(frame, "LiDAR points: " + str(len(lidar_data)), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                    
                    if closest_dist < float('inf'):
                        cv2.putText(frame, "Closest obstacle: " + str(round(closest_dist, 1)) + " m", (10, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                        
                        # Color based on distance
                        if closest_dist < 5:
                            color = (0, 0, 255)  # Red - danger
                            cv2.putText(frame, "!! DANGER !!", (10, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
                        elif closest_dist < 15:
                            color = (0, 165, 255)  # Orange - caution
                            cv2.putText(frame, "CAUTION", (10, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 1)
                        else:
                            color = (0, 255, 0)  # Green - safe
                            cv2.putText(frame, "CLEAR", (10, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                    else:
                        cv2.putText(frame, "No obstacle detected", (10, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                    
                    # Draw mini LiDAR top-down view
                    lidar_view = np.zeros((200, 200, 3), dtype=np.uint8)
                    lidar_2d = lidar_to_2d(lidar_data, 200, 200)
                    
                    for px, py, z in lidar_2d:
                        # Color by height
                        if z < -1:
                            color = (100, 100, 100)  # Ground - gray
                        elif z < 0:
                            color = (0, 255, 0)  # Low objects - green
                        else:
                            color = (0, 0, 255)  # High objects - red
                        cv2.circle(lidar_view, (px, py), 1, color, -1)
                    
                    # Draw ego vehicle
                    cv2.circle(lidar_view, (100, 150), 5, (255, 255, 0), -1)
                    cv2.putText(lidar_view, "EGO", (90, 170), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (255, 255, 255), 1)
                    
                    # Overlay LiDAR view on frame
                    frame[h-210:h-10, w-210:w-10] = lidar_view
                    cv2.rectangle(frame, (w-210, h-210), (w-10, h-10), (255, 255, 255), 1)
                    cv2.putText(frame, "LiDAR Top-Down", (w-200, h-215), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
                
                cv2.imshow('Camera + LiDAR', frame)
            
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.6, throttle + 0.05)
            elif key == ord('s'):
                throttle = max(0.1, throttle - 0.05)
                
    finally:
        print("Cleaning up...")
        camera.stop()
        lidar.stop()
        camera.destroy()
        lidar.destroy()
        vehicle.destroy()
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()