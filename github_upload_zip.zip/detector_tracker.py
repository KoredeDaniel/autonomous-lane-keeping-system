import sys
import os
import numpy as np
import cv2

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla
import torch
from scipy.optimize import linear_sum_assignment

camera_image = None

class SimpleTrack:
    def __init__(self, track_id, bbox, label):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.age = 0
        self.hits = 1
        self.missed = 0

class ByteTracker:
    def __init__(self, max_age=30, min_hits=3, iou_threshold=0.3):
        self.max_age = max_age
        self.min_hits = min_hits
        self.iou_threshold = iou_threshold
        self.tracks = []
        self.next_id = 1
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        
        if union == 0:
            return 0
        return inter / union
    
    def update(self, detections):
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(SimpleTrack(self.next_id, det['bbox'], det['label']))
                self.next_id += 1
            return self.tracks
        
        if len(detections) == 0:
            for track in self.tracks:
                track.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_age]
            return self.tracks
        
        cost_matrix = np.zeros((len(self.tracks), len(detections)))
        for i, track in enumerate(self.tracks):
            for j, det in enumerate(detections):
                cost_matrix[i, j] = 1 - self.iou(track.bbox, det['bbox'])
        
        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        
        matched_tracks = set()
        matched_dets = set()
        
        for i, j in zip(row_ind, col_ind):
            if cost_matrix[i, j] < (1 - self.iou_threshold):
                self.tracks[i].bbox = detections[j]['bbox']
                self.tracks[i].label = detections[j]['label']
                self.tracks[i].hits += 1
                self.tracks[i].missed = 0
                matched_tracks.add(i)
                matched_dets.add(j)
        
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(SimpleTrack(self.next_id, det['bbox'], det['label']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < self.max_age]
        
        return self.tracks

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    array = array[:, :, :3]
    camera_image = array

def main():
    global camera_image
    
    print("Loading YOLOv5 model...")
    model = torch.hub.load(yolo_path, 'custom', path=os.path.join(yolo_path, 'yolov5s.pt'), source='local')
    model.conf = 0.5
    print("Model loaded!")
    
    tracker = ByteTracker()
    print("ByteTrack initialized!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    spawn_points = world.get_map().get_spawn_points()
    spawn_point = spawn_points[0]
    
    print("Spawning vehicle...")
    vehicle = world.spawn_actor(vehicle_bp, spawn_point)
    vehicle.set_autopilot(True)
    print("Vehicle spawned with autopilot!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda image: process_image(image))
    print("Camera attached!")
    
    print("")
    print("Running detection + tracking... Press Q to quit")
    print("")
    
    colors = {}
    
    try:
        while True:
            if camera_image is not None:
                frame = camera_image.copy()
                
                results = model(frame)
                dets = results.pandas().xyxy[0]
                
                detections = []
                for idx, det in dets.iterrows():
                    detections.append({
                        'bbox': [int(det['xmin']), int(det['ymin']), int(det['xmax']), int(det['ymax'])],
                        'label': det['name'],
                        'conf': det['confidence']
                    })
                
                tracks = tracker.update(detections)
                
                for track in tracks:
                    if track.id not in colors:
                        colors[track.id] = (np.random.randint(0, 255), np.random.randint(0, 255), np.random.randint(0, 255))
                    
                    color = colors[track.id]
                    x1, y1, x2, y2 = track.bbox
                    
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    text = "ID:" + str(track.id) + " " + track.label
                    cv2.putText(frame, text, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
                
                cv2.imshow('CARLA YOLOv5 + ByteTrack', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
                
    finally:
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()