# -*- coding: utf-8 -*-
import sys
import time
import math
import numpy as np
import cv2
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
yolo_path = r"C:\Users\CARLACODES\1_code\yolov5"
weights_path = r"C:\Users\CARLACODES\1_code\yolov5\runs\train\yolov5n_bdd_to_carla_4class\weights\best.pt"

sys.path.append(carla_egg)
sys.path.append(yolo_path)

import carla
from bytetrack.byte_tracker import BYTETracker

from vla.scene_state import SceneState, TrackedObject
from vla.vla_policy import VLAReasoner
from vla.safety_guard import SafetyGuard
from vla.control_mapper import SpeedController
from vla.logger import DecisionLogger

camera_image = None
NAMES = ['vehicle', 'pedestrian', 'traffic_light', 'traffic_sign']


def process_image(image):
    global camera_image
    arr = np.frombuffer(image.raw_data, dtype=np.uint8)
    arr = arr.reshape((image.height, image.width, 4))
    camera_image = arr[:, :, :3].copy()


class StableSteering:
    def __init__(self):
        self.prev_steer = 0.0

    def smooth(self, raw):
        if abs(raw) < 0.01:
            raw = 0.0
        max_rate = 0.05
        diff = raw - self.prev_steer
        if abs(diff) > max_rate:
            raw = self.prev_steer + max_rate * np.sign(diff)
        raw = float(np.clip(raw, -1.0, 1.0))
        self.prev_steer = raw
        return raw


class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.prev_curv = 0.0

    def speed(self):
        v = self.vehicle.get_velocity()
        return math.sqrt(v.x*v.x + v.y*v.y + v.z*v.z)

    def speed_kmh(self):
        return self.speed() * 3.6

    def get_waypoints(self, count=35, spacing=1.5):
        loc = self.vehicle.get_location()
        wp = self.map.get_waypoint(loc, project_to_road=True)
        if wp is None:
            return []
        wps = [wp]
        cur = wp
        for _ in range(count):
            nxt = cur.next(spacing)
            if not nxt:
                break
            cur = nxt[0]
            wps.append(cur)
        return wps

    def curvature(self, waypoints):
        if len(waypoints) < 3:
            return self.prev_curv
        p1 = waypoints[0].transform.location
        p2 = waypoints[min(6, len(waypoints) - 1)].transform.location
        p3 = waypoints[min(12, len(waypoints) - 1)].transform.location

        a = math.hypot(p2.x - p1.x, p2.y - p1.y)
        b = math.hypot(p3.x - p2.x, p3.y - p2.y)
        c = math.hypot(p3.x - p1.x, p3.y - p1.y)
        s = (a + b + c) / 2.0
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a*b*c <= 1e-6:
            return self.prev_curv
        curv = 4.0 * math.sqrt(area_sq) / (a*b*c)
        self.prev_curv = 0.7 * self.prev_curv + 0.3 * curv
        return self.prev_curv

    def get_steering(self):
        tf = self.vehicle.get_transform()
        loc = tf.location
        yaw = math.radians(tf.rotation.yaw)

        wp = self.map.get_waypoint(loc, project_to_road=True)
        if wp is None:
            return 0.0, 0.0, False

        v = self.speed()
        lookahead = max(4.0, min(8.0, 4.0 + 0.25*v))

        target = wp
        remaining = lookahead
        while remaining > 0:
            nxt = target.next(min(remaining, 1.5))
            if not nxt:
                break
            target = nxt[0]
            remaining -= 1.5

        tloc = target.transform.location
        dx = tloc.x - loc.x
        dy = tloc.y - loc.y

        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)

        ld2 = local_x*local_x + local_y*local_y
        if ld2 < 0.1:
            return 0.0, 0.0, True

        steer = math.atan2(2.0 * self.wheelbase * local_y, ld2)
        steer = steer / math.radians(60.0)
        steer = float(np.clip(steer, -1.0, 1.0))

        wp_loc = wp.transform.location
        wp_yaw = math.radians(wp.transform.rotation.yaw)
        ex = loc.x - wp_loc.x
        ey = loc.y - wp_loc.y
        cte = ex * math.sin(wp_yaw) - ey * math.cos(wp_yaw)

        return steer, cte, True


def draw_lane_lines(frame, vehicle, waypoints, fov_deg=90.0):
    if not waypoints or len(waypoints) < 2:
        return frame

    h, w = frame.shape[:2]
    f = w / (2.0 * math.tan(math.radians(fov_deg) / 2.0))

    tf = vehicle.get_transform()
    vx, vy, vz = tf.location.x, tf.location.y, tf.location.z
    vyaw = math.radians(-tf.rotation.yaw)

    center_pts, left_pts, right_pts = [], [], []

    for i, wp in enumerate(waypoints):
        if i % 2 != 0 and i < len(waypoints) - 1:
            continue

        loc = wp.transform.location
        half_w = (wp.lane_width * 0.5) * 0.9

        dx, dy, dz = loc.x - vx, loc.y - vy, loc.z - vz
        lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
        ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
        lz = dz - 1.4

        if lx <= 0.5:
            continue

        u = int(w * 0.5 - f * (ly / lx))
        v = int(h * 0.5 - f * (lz / lx))
        if not (0 <= u < w and 0 <= v < h):
            continue

        center_pts.append((u, v))
        u_left = int(w * 0.5 - f * ((ly + half_w) / lx))
        u_right = int(w * 0.5 - f * ((ly - half_w) / lx))

        if 0 <= u_left < w:
            left_pts.append((u_left, v))
        if 0 <= u_right < w:
            right_pts.append((u_right, v))

    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 100, 100), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (100, 100, 255), 2)
    for i in range(1, len(center_pts)):
        cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)

    return frame


def get_traffic_light_state(vehicle):
    try:
        if vehicle.is_at_traffic_light():
            tl = vehicle.get_traffic_light()
            if tl is None:
                return "NONE"
            st = tl.get_state()
            if st == carla.TrafficLightState.Red:
                return "RED"
            if st == carla.TrafficLightState.Yellow:
                return "YELLOW"
            if st == carla.TrafficLightState.Green:
                return "GREEN"
    except:
        pass
    return "NONE"


def yolo_to_det_array(results, w, h):
    dets = results.pandas().xyxy[0]
    out = []
    frame_area = float(w * h)

    for _, d in dets.iterrows():
        x1, y1, x2, y2 = int(d['xmin']), int(d['ymin']), int(d['xmax']), int(d['ymax'])
        conf = float(d['confidence'])
        cls = int(d['class'])

        if cls < 0 or cls >= 4:
            continue

        bw = x2 - x1
        bh = y2 - y1
        if bw <= 1 or bh <= 1:
            continue

        area = float(bw * bh)
        ar = float(bw) / float(bh + 1e-6)
        cx = (x1 + x2) * 0.5
        cy = (y1 + y2) * 0.5

        # Domain-gap suppressor focused on "vehicle" false positives
        if cls == 0:
            if conf < 0.60:
                continue
            if y1 < int(0.52 * h):
                continue
            if y2 < int(0.62 * h):
                continue
            if cy < (0.62 * h):
                continue
            if bw < 34 or bh < 18:
                continue
            if area > 0.12 * frame_area:
                continue
            if bh > 0.28 * h:
                continue
            if ar < 1.10 or ar > 2.80:
                continue
            if cx < 0.12 * w or cx > 0.88 * w:
                continue

        elif cls == 1:
            if conf < 0.45:
                continue
            if y2 < int(0.45 * h):
                continue
            if ar > 0.80:
                continue
            if bh < 24:
                continue
            if area > 0.10 * frame_area:
                continue

        elif cls == 2:
            if conf < 0.40:
                continue
            if area < 70 or area > 0.06 * frame_area:
                continue
            if ar > 1.4:
                continue
            if y1 > int(0.78 * h):
                continue

        elif cls == 3:
            if conf < 0.40:
                continue
            if area < 90 or area > 0.08 * frame_area:
                continue
            if ar < 0.55 or ar > 2.0:
                continue

        out.append([x1, y1, x2, y2, conf, cls])

    if len(out) == 0:
        return np.zeros((0, 6), dtype=np.float32)
    return np.array(out, dtype=np.float32)


def draw_tracks(frame, tracks):
    for t in tracks:
        x1, y1, x2, y2 = map(int, t.bbox)
        cls = int(t.cls)
        label = NAMES[cls] if 0 <= cls < len(NAMES) else str(cls)
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 255), 2)
        cv2.putText(frame, f"ID:{t.track_id} {label} {t.score:.2f}",
                    (x1, max(0, y1 - 6)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
    return frame


def draw_hud(frame, scene, decision, fps):
    h, w = frame.shape[:2]
    cv2.rectangle(frame, (10, 10), (520, 150), (0, 0, 0), -1)
    cv2.putText(frame, "Hybrid VLA Decision Layer Demo", (15, 32),
                cv2.FONT_HERSHEY_SIMPLEX, 0.60, (0, 255, 0), 1)
    cv2.putText(frame, f"Speed: {scene.speed_kmh:.1f} km/h", (15, 56),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
    cv2.putText(frame, f"CTE: {scene.cte_m:.2f} m   Curv: {scene.curvature:.3f}", (15, 80),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 1)
    cv2.putText(frame, f"Traffic Light: {scene.traffic_light_state}", (15, 104),
                cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1)
    cv2.putText(frame, f"Action: {decision.get('action','')}  Target: {decision.get('target_speed_kmh',0):.1f} km/h",
                (15, 128), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1)

    cv2.rectangle(frame, (w - 120, 10), (w - 10, 45), (0, 0, 0), -1)
    cv2.putText(frame, f"{fps:.0f} FPS", (w - 110, 35),
                cv2.FONT_HERSHEY_SIMPLEX, 0.60, (0, 255, 0), 1)
    return frame


def main():
    global camera_image

    IMG_W, IMG_H = 640, 480

    print("Loading YOLO weights:", weights_path)
    model = torch.hub.load(yolo_path, 'custom', path=weights_path, source='local', force_reload=True)
    model.conf = 0.25
    model.iou = 0.45
    model.max_det = 60

    tracker = BYTETracker(track_thresh=0.45, low_thresh=0.15, match_thresh=0.30, max_time_lost=25)

    print("Connecting CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(20.0)

    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2.0)
    world_map = world.get_map()

    bp_lib = world.get_blueprint_library()
    spawns = world_map.get_spawn_points()
    if not spawns:
        raise RuntimeError("No spawn points in Town02.")

    ego_bp = bp_lib.filter('vehicle.tesla.model3')[0]
    ego = world.spawn_actor(ego_bp, spawns[0])
    ego.set_autopilot(False)

    cam_bp = bp_lib.find('sensor.camera.rgb')
    cam_bp.set_attribute('image_size_x', str(IMG_W))
    cam_bp.set_attribute('image_size_y', str(IMG_H))
    cam_bp.set_attribute('fov', '90')
    cam_tf = carla.Transform(carla.Location(x=2.0, z=1.4))
    cam = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    cam.listen(lambda img: process_image(img))

    lane = LaneKeeper(ego, world_map)
    smoother = StableSteering()

    vla = VLAReasoner(mode="heuristic")
    guard = SafetyGuard()
    speed_ctrl = SpeedController()

    logger = DecisionLogger(out_csv=r"runs\vla\decision_log.csv")

    fps_hist = deque(maxlen=30)
    last_t = time.time()
    frame_id = 0

    print("Waiting for camera...")
    for _ in range(90):
        world.tick()
        time.sleep(0.05)
        if camera_image is not None:
            break

    cv2.namedWindow("CARLA VLA Demo", cv2.WINDOW_NORMAL)
    detect_interval = 2
    det_arr = np.zeros((0, 6), dtype=np.float32)

    try:
        while True:
            world.tick()
            frame_id += 1

            now = time.time()
            dt = now - last_t
            last_t = now
            if dt > 0:
                fps_hist.append(1.0 / dt)
            fps = float(np.mean(fps_hist)) if len(fps_hist) else 0.0

            if camera_image is None:
                continue
            frame = camera_image.copy()

            # Lane keep
            raw_steer, cte, ok = lane.get_steering()
            steer = smoother.smooth(raw_steer if ok else 0.0)
            waypoints = lane.get_waypoints()
            curv = lane.curvature(waypoints)

            # Traffic light (CARLA ground truth)
            tl_state = get_traffic_light_state(ego)

            # Detection
            if frame_id % detect_interval == 0:
                res = model(frame, size=640)
                det_arr = yolo_to_det_array(res, IMG_W, IMG_H)

            # Tracking
            tracks = tracker.update(det_arr)

            # Build objects ahead list (corridor logic in image space)
            cx = IMG_W // 2
            corridor_left = cx - 140
            corridor_right = cx + 140

            objects_ahead = []
            emergency_flag = False

            for t in tracks:
                x1, y1, x2, y2 = map(int, t.bbox)
                cls = int(t.cls)
                label = NAMES[cls] if 0 <= cls < len(NAMES) else str(cls)
                center_x = (x1 + x2) // 2
                bottom_y = y2

                in_corridor = (corridor_left < center_x < corridor_right)

                # Simple emergency proxy if something is extremely close in corridor
                if in_corridor and label in ["vehicle", "pedestrian"] and bottom_y > 410 and getattr(t, "hits", 1) >= 2:
                    emergency_flag = True

                objects_ahead.append(TrackedObject(
                    track_id=int(t.track_id),
                    cls=cls,
                    label=label,
                    score=float(t.score),
                    bbox=[x1, y1, x2, y2],
                    hits=int(getattr(t, "hits", 1)),
                    age=int(getattr(t, "age", 0)),
                    in_corridor=bool(in_corridor),
                    bottom_y=int(bottom_y),
                    center_x=int(center_x)
                ))

            scene = SceneState(
                frame_id=frame_id,
                speed_kmh=lane.speed_kmh(),
                cte_m=float(cte),
                steer=float(steer),
                curvature=float(curv),
                traffic_light_state=tl_state,
                objects_ahead=objects_ahead
            )

            # VLA decision + safety override
            decision = vla.decide(scene)
            decision = guard.override(scene, decision, emergency_flag=emergency_flag)

            target_speed = float(decision.get("target_speed_kmh", 0.0))
            throttle, brake = speed_ctrl.compute(scene.speed_kmh, target_speed)

            # Apply control
            control = carla.VehicleControl()
            control.throttle = float(np.clip(throttle, 0.0, 1.0))
            control.brake = float(np.clip(brake, 0.0, 1.0))
            control.steer = float(steer)
            ego.apply_control(control)

            # Log for dissertation
            logger.write(frame_id, scene, decision)

            # Visuals
            frame = draw_lane_lines(frame, ego, waypoints, fov_deg=90.0)
            frame = draw_tracks(frame, tracks)
            frame = draw_hud(frame, scene, decision, fps)
            cv2.imshow("CARLA VLA Demo", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

    finally:
        print("Cleaning up...")
        try:
            logger.close()
        except:
            pass
        try:
            cam.stop()
            cam.destroy()
        except:
            pass
        try:
            ego.destroy()
        except:
            pass
        cv2.destroyAllWindows()
        print("Done.")


if __name__ == "__main__":
    main()