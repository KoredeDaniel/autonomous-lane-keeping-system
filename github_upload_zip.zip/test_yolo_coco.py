import sys
import time
import random
import numpy as np
import cv2
import torch

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

# COCO class IDs we care about
COCO_VEHICLE_CLASSES = [2, 3, 5, 7]  # car, motorcycle, bus, truck
COCO_PERSON_CLASS = 0
COCO_TRAFFIC_LIGHT = 9
COCO_STOP_SIGN = 11

def filter_detections(results, frame_width, frame_height):
    """Filter COCO detections"""
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        # Map COCO classes to our labels
        if class_id in COCO_VEHICLE_CLASSES:
            label = 'vehicle'
        elif class_id == COCO_PERSON_CLASS:
            label = 'pedestrian'
        elif class_id == COCO_TRAFFIC_LIGHT:
            label = 'traffic_light'
        elif class_id == COCO_STOP_SIGN:
            label = 'traffic_sign'
        else:
            continue  # Skip other classes
        
        box_width = x2 - x1
        box_height = y2 - y1
        box_area = box_width * box_height
        frame_area = frame_width * frame_height
        aspect_ratio = box_width / box_height if box_height > 0 else 0
        
        # === FILTERING ===
        
        # 1. Confidence threshold
        if conf < 0.5:
            continue
        
        # 2. Size constraints
        if box_width < 25 or box_height < 25:
            continue
        if box_area > frame_area * 0.4:
            continue
        
        # 3. Position filter - ignore top 20% (sky/buildings)
        if label == 'vehicle' and y1 < frame_height * 0.2:
            continue
        
        # 4. Aspect ratio for vehicles
        if label == 'vehicle':
            if aspect_ratio < 0.4 or aspect_ratio > 3.5:
                continue
        
        # 5. Pedestrian filters
        if label == 'pedestrian':
            if aspect_ratio > 0.9:  # Pedestrians are taller than wide
                continue
            if box_height < 40:
                continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Loading YOLOv5s (COCO pretrained)...")
    model = torch.hub.load(yolo_path, 'yolov5s', source='local', pretrained=True)
    model.conf = 0.4
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPC vehicles
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(15, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    # Spawn pedestrians
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(8):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    print("")
    print("========================================")
    print("YOLO COCO Detection Test")
    print("========================================")
    print("Using pretrained YOLOv5s (COCO)")
    print("Q - Quit | W/S - Speed")
    print("========================================")
    
    cv2.namedWindow('YOLO COCO Test', cv2.WINDOW_NORMAL)
    
    throttle = 0.3
    
    try:
        while True:
            world.tick()
            
            control = carla.VehicleControl()
            control.throttle = throttle
            vehicle.apply_control(control)
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # Run YOLO
                results = model(frame)
                
                raw_dets = results.pandas().xyxy[0]
                raw_count = len(raw_dets)
                
                filtered_dets = filter_detections(results, w, h)
                
                colors = {
                    'vehicle': (0, 255, 0),
                    'pedestrian': (0, 165, 255),
                    'traffic_light': (0, 255, 255),
                    'traffic_sign': (255, 0, 255)
                }
                
                for det in filtered_dets:
                    x1, y1, x2, y2 = det['bbox']
                    label = det['label']
                    conf = det['conf']
                    color = colors.get(label, (255, 255, 255))
                    
                    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                    text = label + " " + str(round(conf, 2))
                    cv2.putText(frame, text, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
                
                # HUD
                cv2.rectangle(frame, (5, 5), (280, 90), (0, 0, 0), -1)
                cv2.putText(frame, "YOLO COCO Detection", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
                cv2.putText(frame, "Raw: " + str(raw_count) + " | Filtered: " + str(len(filtered_dets)), (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (10, 75), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                cv2.imshow('YOLO COCO Test', frame)
            
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.6, throttle + 0.05)
            elif key == ord('s'):
                throttle = max(0.1, throttle - 0.05)
                
    finally:
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()