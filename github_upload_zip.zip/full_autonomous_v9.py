import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

COCO_CLASSES = {
    0: 'person',
    2: 'car',
    3: 'motorcycle',
    5: 'bus',
    7: 'truck',
    9: 'traffic_light',
    11: 'stop_sign'
}

# ============================================
# STABLE STEERING WITH DAMPING (NO FIDGET)
# ============================================

class StableSteering:
    """
    PD-like steering controller to prevent oscillation/fidgeting.
    Uses derivative term to dampen sudden changes.
    """
    def __init__(self):
        self.prev_steer = 0.0
        self.prev_error = 0.0
        self.integral = 0.0
        
        # Tuned gains
        self.kp = 0.3          # Proportional - how fast to respond
        self.kd = 0.15         # Derivative - damping to prevent oscillation
        
    def update(self, target_steer):
        # Dead zone - ignore tiny steering
        if abs(target_steer) < 0.01:
            target_steer = 0.0
        
        # Error between target and current
        error = target_steer - self.prev_steer
        
        # Derivative (change in error) - this dampens oscillation
        derivative = error - self.prev_error
        
        # PD control
        adjustment = self.kp * error + self.kd * (-derivative)
        
        # Apply adjustment
        new_steer = self.prev_steer + adjustment
        
        # Rate limiting for smooth transitions
        max_change = 0.03
        diff = new_steer - self.prev_steer
        if abs(diff) > max_change:
            new_steer = self.prev_steer + max_change * np.sign(diff)
        
        # Clamp
        new_steer = max(-1.0, min(1.0, new_steer))
        
        # Store for next iteration
        self.prev_error = error
        self.prev_steer = new_steer
        
        return new_steer

# ============================================
# OPTIMIZED LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.prev_curvature = 0.0
        self.waypoint_cache = []
        self.cache_frame = 0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_waypoints(self, frame_count, count=15, spacing=2.0):
        # Cache waypoints - only update every 3 frames
        if frame_count - self.cache_frame < 3 and len(self.waypoint_cache) > 0:
            return self.waypoint_cache
        
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return self.waypoint_cache if self.waypoint_cache else []
        
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        
        self.waypoint_cache = waypoints
        self.cache_frame = frame_count
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return self.prev_curvature
        
        p1 = waypoints[0].transform.location
        mid = min(6, len(waypoints) // 2)
        end = min(12, len(waypoints) - 1)
        p2 = waypoints[mid].transform.location
        p3 = waypoints[end].transform.location
        
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        
        if area_sq <= 0 or a * b * c == 0:
            curvature = 0.0
        else:
            curvature = 4 * math.sqrt(area_sq) / (a * b * c)
        
        # Heavy smoothing on curvature
        self.prev_curvature = 0.85 * self.prev_curvature + 0.15 * curvature
        return self.prev_curvature
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        return dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Balanced lookahead
        speed = self.get_speed()
        lookahead = max(4.0, min(8.0, 4.5 + speed * 0.25))
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure Pursuit
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = steering / math.radians(65)
        steering = max(-1.0, min(1.0, steering))
        
        cte = self.get_cross_track_error()
        return steering, cte, True

# ============================================
# FAST TRAFFIC CONTROLLER
# ============================================

class TrafficController:
    def __init__(self, vehicle, world):
        self.vehicle = vehicle
        self.world = world
        self.stop_sign_wait = 0
        self.last_stop_sign_id = None
        self.stop_signs_cache = None
        self.cache_frame = 0
        
    def get_traffic_light_state(self):
        if self.vehicle.is_at_traffic_light():
            traffic_light = self.vehicle.get_traffic_light()
            if traffic_light is not None:
                state = traffic_light.get_state()
                if state == carla.TrafficLightState.Red:
                    return 'RED'
                elif state == carla.TrafficLightState.Yellow:
                    return 'YELLOW'
                elif state == carla.TrafficLightState.Green:
                    return 'GREEN'
        return 'NONE'
    
    def check_stop_signs(self, frame_count):
        # Cache stop signs - only fetch every 30 frames
        if frame_count - self.cache_frame > 30 or self.stop_signs_cache is None:
            actors = self.world.get_actors()
            self.stop_signs_cache = list(actors.filter('traffic.stop'))
            self.cache_frame = frame_count
        
        location = self.vehicle.get_location()
        
        for stop_sign in self.stop_signs_cache:
            sign_loc = stop_sign.get_location()
            distance = location.distance(sign_loc)
            
            if distance < 10 and stop_sign.id != self.last_stop_sign_id:
                vehicle_forward = self.vehicle.get_transform().get_forward_vector()
                to_sign = carla.Vector3D(
                    sign_loc.x - location.x,
                    sign_loc.y - location.y,
                    0
                )
                dot = vehicle_forward.x * to_sign.x + vehicle_forward.y * to_sign.y
                
                if dot > 0 and distance < 5:
                    return stop_sign.id, distance
        
        return None, float('inf')
    
    def get_action(self, frame_count):
        light_state = self.get_traffic_light_state()
        
        if light_state == 'RED':
            return 'STOP_LIGHT', 'RED'
        if light_state == 'YELLOW':
            return 'SLOW_LIGHT', 'YELLOW'
        
        stop_sign_id, distance = self.check_stop_signs(frame_count)
        
        if stop_sign_id is not None:
            if distance < 4:
                if self.stop_sign_wait < 25:
                    self.stop_sign_wait += 1
                    self.last_stop_sign_id = stop_sign_id
                    return 'STOP_SIGN', 'STOP'
                else:
                    self.stop_sign_wait = 0
                    return 'CLEAR', 'GO'
            else:
                return 'SLOW_SIGN', 'SLOW'
        else:
            if self.stop_sign_wait > 0:
                self.stop_sign_wait = 0
        
        if light_state == 'GREEN':
            return 'CLEAR', 'GREEN'
        
        return 'CLEAR', ''

# ============================================
# FAST TRACKER
# ============================================

class Track:
    __slots__ = ['id', 'bbox', 'label', 'conf', 'missed', 'age']
    
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0

class FastTracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
            
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < 4]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        # Simple matching
        matched = set()
        for det in detections:
            best_i = -1
            best_iou = 0.2
            dx1, dy1, dx2, dy2 = det['bbox']
            
            for i, track in enumerate(self.tracks):
                if i in matched:
                    continue
                tx1, ty1, tx2, ty2 = track.bbox
                
                # Fast IOU
                ix1, iy1 = max(dx1, tx1), max(dy1, ty1)
                ix2, iy2 = min(dx2, tx2), min(dy2, ty2)
                inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
                area1 = (dx2 - dx1) * (dy2 - dy1)
                area2 = (tx2 - tx1) * (ty2 - ty1)
                iou = inter / (area1 + area2 - inter + 1e-6)
                
                if iou > best_iou:
                    best_iou = iou
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched.add(best_i)
            else:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        for i, t in enumerate(self.tracks):
            if i not in matched:
                t.missed += 1
        
        self.tracks = [t for t in self.tracks if t.missed < 4]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE
# ============================================

class CollisionAvoidance:
    def __init__(self, w, h):
        center = w // 2
        self.danger_left = center - 140
        self.danger_right = center + 140
        self.emergency_y = 400
        self.brake_y = 340
        self.slow_y = 280
        
    def check(self, tracks):
        closest_y = 0
        danger_track = None
        
        for track in tracks:
            if track.label not in ['car', 'motorcycle', 'bus', 'truck', 'person']:
                continue
            if track.age < 2:
                continue
            
            x1, y1, x2, y2 = track.bbox
            cx = (x1 + x2) // 2
            
            if self.danger_left < cx < self.danger_right:
                if y2 > closest_y:
                    closest_y = y2
                    danger_track = track
        
        if closest_y > self.emergency_y:
            return 'EMERGENCY', 0.0, 1.0, danger_track
        elif closest_y > self.brake_y:
            return 'BRAKE', 0.1, 0.5, danger_track
        elif closest_y > self.slow_y:
            return 'SLOW', 0.5, 0.0, danger_track
        return 'CLEAR', 1.0, 0.0, None

# ============================================
# FAST DETECTION FILTER
# ============================================

def filter_detections_fast(results, w, h):
    dets = results.pandas().xyxy[0]
    filtered = []
    frame_area = w * h
    
    for _, det in dets.iterrows():
        class_id = int(det['class'])
        if class_id not in COCO_CLASSES:
            continue
        
        conf = det['confidence']
        label = COCO_CLASSES[class_id]
        
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        box_w, box_h = x2 - x1, y2 - y1
        box_area = box_w * box_h
        
        # Quick reject
        if box_w < 25 or box_h < 25:
            continue
        if box_area > frame_area * 0.35:
            continue
        
        # Class-specific
        if label == 'car':
            if conf < 0.6 or y1 < h * 0.35:
                continue
            ar = box_w / box_h
            if ar < 0.8 or ar > 2.5 or box_h > h * 0.45:
                continue
        elif label == 'person':
            if conf < 0.5 or y1 < h * 0.30:
                continue
            if box_w / box_h > 0.75 or box_h < 50:
                continue
        elif label in ['motorcycle', 'bus', 'truck']:
            if conf < 0.55 or y1 < h * 0.30:
                continue
        elif label in ['traffic_light', 'stop_sign']:
            if conf < 0.4:
                continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

# ============================================
# MINIMAL VISUALIZATION (FAST)
# ============================================

def draw_lane_fast(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    center_pts = []
    
    # Only draw center line (faster)
    for wp in waypoints[::2]:  # Skip every other waypoint
        loc = wp.transform.location
        dx, dy, dz = loc.x - vx, loc.y - vy, loc.z - vz
        lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
        ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
        lz = dz - 1.4
        
        if lx > 0.5:
            u = int(w/2 - f * ly / lx)
            v = int(h/2 - f * lz / lx)
            if 0 <= u < w and 0 <= v < h:
                center_pts.append((u, v))
    
    # Draw simple path
    for i in range(1, len(center_pts)):
        cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)
    
    return frame

def draw_tracks_fast(frame, tracks, danger_track):
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
        elif track.label == 'person':
            color = (0, 0, 255)
        else:
            color = (0, 255, 0)
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    
    return frame

def draw_hud_minimal(frame, speed, steer, action, traffic_status, fps):
    h, w = frame.shape[:2]
    
    # Minimal HUD
    cv2.rectangle(frame, (5, 5), (150, 65), (0, 0, 0), -1)
    cv2.putText(frame, str(round(speed, 0)) + " km/h", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 2)), (10, 45), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # FPS
    fps_color = (0, 255, 0) if fps > 25 else (0, 165, 255)
    cv2.putText(frame, str(round(fps, 0)) + " FPS", (10, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.4, fps_color, 1)
    
    # Status indicator
    if traffic_status in ['STOP_LIGHT', 'STOP_SIGN'] or action == 'EMERGENCY':
        cv2.circle(frame, (w - 30, 30), 20, (0, 0, 255), -1)
    elif traffic_status in ['SLOW_LIGHT', 'SLOW_SIGN'] or action in ['BRAKE', 'SLOW']:
        cv2.circle(frame, (w - 30, 30), 20, (0, 200, 255), -1)
    else:
        cv2.circle(frame, (w - 30, 30), 20, (0, 255, 0), -1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN - OPTIMIZED
# ============================================

def main():
    global camera_image
    
    print("Loading YOLOv5n...")
    model = torch.hub.load(yolo_path, 'yolov5n', source='local', pretrained=True)
    model.conf = 0.4
    model.iou = 0.5
    model.classes = [0, 2, 3, 5, 7, 9, 11]
    model.max_det = 20  # Limit detections
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Smaller camera for speed
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Fewer NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(8, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(3):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_controller = StableSteering()
    tracker = FastTracker()
    collision_avoidance = CollisionAvoidance(640, 480)
    traffic_controller = TrafficController(ego_vehicle, world)
    
    base_throttle = 0.30
    detect_interval = 4  # Less frequent YOLO
    frame_count = 0
    current_tracks = []
    
    fps_history = deque(maxlen=20)
    last_time = time.time()
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    print("")
    print("========================================")
    print("AUTONOMOUS v9 - OPTIMIZED")
    print("========================================")
    print("+ Stable PD steering (no fidget)")
    print("+ Optimized for 30+ FPS")
    print("+ Minimal visualization")
    print("========================================")
    print("Q - Quit | W/S - Speed")
    print("========================================")
    
    cv2.namedWindow('Autonomous v9', cv2.WINDOW_NORMAL)
    
    try:
        while True:
            world.tick()
            frame_count += 1
            
            # FPS
            current_time = time.time()
            dt = current_time - last_time
            if dt > 0:
                fps_history.append(1.0 / dt)
            last_time = current_time
            fps = np.mean(fps_history)
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # YOLO - less frequent
                if frame_count % detect_interval == 0:
                    results = model(frame, size=384)  # Smaller inference
                    detections = filter_detections_fast(results, w, h)
                    current_tracks = tracker.update(detections)
                
                # Lane keeping
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_controller.update(raw_steer) if valid else steering_controller.update(0.0)
                waypoints = lane_keeper.get_waypoints(frame_count)
                curvature = lane_keeper.calculate_curvature(waypoints)
                
                # Traffic - less frequent check
                if frame_count % 2 == 0:
                    traffic_status, traffic_msg = traffic_controller.get_action(frame_count)
                else:
                    traffic_status, traffic_msg = 'CLEAR', ''
                
                # Collision
                collision_action, throttle_mult, brake, danger_track = collision_avoidance.check(current_tracks)
                
                # Control
                final_throttle = base_throttle
                final_brake = 0.0
                
                if traffic_status == 'STOP_LIGHT':
                    final_throttle = 0.0
                    final_brake = 0.8
                elif traffic_status == 'STOP_SIGN':
                    final_throttle = 0.0
                    final_brake = 0.6
                elif traffic_status in ['SLOW_LIGHT', 'SLOW_SIGN']:
                    final_throttle = base_throttle * 0.4
                else:
                    final_throttle = base_throttle * throttle_mult
                    final_brake = brake
                
                # Curve
                if curvature > 0.1:
                    final_throttle *= 0.6
                elif curvature > 0.06:
                    final_throttle *= 0.8
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = final_brake
                ego_vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                # Minimal viz
                frame = draw_lane_fast(frame, ego_vehicle, waypoints)
                frame = draw_tracks_fast(frame, current_tracks, danger_track)
                frame = draw_hud_minimal(frame, speed, steer, collision_action, traffic_status, fps)
                
                cv2.imshow('Autonomous v9', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
                
    finally:
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()