import os
import shutil

labels_dir = r"Z:\Users\egbebiakorededaniel\Desktop\carla_data\labels"
subfolder = r"Z:\Users\egbebiakorededaniel\Desktop\carla_data\labels\labels_my-project-name_2026-02-04-09-18-07"

print("Moving label files...")

count = 0
for f in os.listdir(subfolder):
    if f.endswith('.txt'):
        src = os.path.join(subfolder, f)
        dst = os.path.join(labels_dir, f)
        shutil.copy(src, dst)
        count += 1
        print("  Copied: " + f)

print("")
print("Copied " + str(count) + " label files")