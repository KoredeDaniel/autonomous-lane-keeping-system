import sys
import time
import numpy as np
import cv2
import math

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class SmoothSteering:
    def __init__(self):
        self.prev_steer = 0.0
        self.steer_history = []
        self.max_history = 5
    
    def smooth(self, steer):
        # Add to history
        self.steer_history.append(steer)
        if len(self.steer_history) > self.max_history:
            self.steer_history.pop(0)
        
        # Moving average
        avg_steer = sum(self.steer_history) / len(self.steer_history)
        
        # Rate limiting - max change per frame
        max_change = 0.05
        diff = avg_steer - self.prev_steer
        if abs(diff) > max_change:
            avg_steer = self.prev_steer + max_change * (1 if diff > 0 else -1)
        
        self.prev_steer = avg_steer
        return avg_steer

def get_steering(vehicle, world_map, lookahead=6.0):
    """Simple pure pursuit steering"""
    transform = vehicle.get_transform()
    location = transform.location
    yaw = math.radians(transform.rotation.yaw)
    
    # Get waypoint ahead
    current_wp = world_map.get_waypoint(location, project_to_road=True)
    if current_wp is None:
        return 0.0, 0.0, False
    
    # Get target waypoint
    next_wps = current_wp.next(lookahead)
    if len(next_wps) == 0:
        return 0.0, 0.0, False
    
    target_wp = next_wps[0]
    target_loc = target_wp.transform.location
    
    # Vector to target
    dx = target_loc.x - location.x
    dy = target_loc.y - location.y
    
    # Transform to vehicle coordinates
    local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
    local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
    
    # Pure pursuit steering
    distance = math.sqrt(local_x**2 + local_y**2)
    if distance < 0.1:
        return 0.0, 0.0, True
    
    # Steering angle (pure pursuit formula)
    steering = math.atan2(2.0 * 2.5 * local_y, distance * distance)
    
    # Normalize to [-1, 1]
    steering = steering / math.radians(70)  # Assuming 70 degree max steering
    steering = max(-1.0, min(1.0, steering))
    
    # Calculate cross-track error for display
    wp_yaw = math.radians(current_wp.transform.rotation.yaw)
    wp_loc = current_wp.transform.location
    cte = (location.x - wp_loc.x) * math.sin(wp_yaw) - (location.y - wp_loc.y) * math.cos(wp_yaw)
    
    return steering, cte, True

def get_waypoints(vehicle, world_map, distance=20.0, spacing=1.0):
    location = vehicle.get_location()
    current_wp = world_map.get_waypoint(location, project_to_road=True)
    
    if current_wp is None:
        return []
    
    waypoints = [current_wp]
    wp = current_wp
    traveled = 0
    
    while traveled < distance:
        next_wps = wp.next(spacing)
        if len(next_wps) == 0:
            break
        wp = next_wps[0]
        waypoints.append(wp)
        traveled += spacing
    
    return waypoints

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))  # FOV 90
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        points = [
            (loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
            (loc.x, loc.y, center_pts)
        ]
        
        for px, py, pts in points:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    # Fill lane
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 150, 0))
        frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
    
    # Draw lines
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 3)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 3)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 200, 200), 2)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    world_map = world.get_map()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Steering smoother
    smoother = SmoothSteering()
    
    # Fixed low throttle
    throttle = 0.3
    lookahead = 6.0
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("SMOOTH LANE KEEPING")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("  A/D - Adjust lookahead")
    print("========================================")
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Get raw steering
                raw_steer, cte, valid = get_steering(vehicle, world_map, lookahead)
                
                # Smooth it
                steer = smoother.smooth(raw_steer) if valid else 0.0
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = throttle
                control.steer = float(steer)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Get speed
                vel = vehicle.get_velocity()
                speed = 3.6 * math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
                
                # Draw lane
                waypoints = get_waypoints(vehicle, world_map)
                frame = draw_lane(frame, vehicle, waypoints)
                
                # HUD
                color = (0, 255, 0) if valid else (0, 165, 255)
                cv2.putText(frame, "LANE KEEPING", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
                cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                cv2.putText(frame, "CTE: " + str(round(cte, 2)) + "m", (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                cv2.putText(frame, "Lookahead: " + str(round(lookahead, 1)) + "m", (10, 135), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                
                # Steering bar
                bar_x = 400
                bar_y = 570
                cv2.rectangle(frame, (bar_x - 100, bar_y - 5), (bar_x + 100, bar_y + 5), (50,50,50), -1)
                cv2.line(frame, (bar_x, bar_y - 10), (bar_x, bar_y + 10), (255,255,255), 2)
                steer_x = bar_x + int(steer * 100)
                cv2.circle(frame, (steer_x, bar_y), 10, (0, 255, 255), -1)
                
                cv2.imshow('Lane Keeping', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.6, throttle + 0.05)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('s'):
                throttle = max(0.15, throttle - 0.05)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('d'):
                lookahead = min(12.0, lookahead + 1.0)
                print("Lookahead: " + str(lookahead) + "m")
            elif key == ord('a'):
                lookahead = max(3.0, lookahead - 1.0)
                print("Lookahead: " + str(lookahead) + "m")
                
    finally:
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()