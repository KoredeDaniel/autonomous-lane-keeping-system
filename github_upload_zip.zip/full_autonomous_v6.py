import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

COCO_VEHICLE_CLASSES = [2, 3, 5, 7]  # car, motorcycle, bus, truck
COCO_PERSON_CLASS = 0

# ============================================
# IMPROVED STEERING SMOOTHER
# ============================================

class SmoothSteering:
    def __init__(self):
        self.history = deque(maxlen=15)  # Longer history
        self.prev_steer = 0.0
        self.smoothing_factor = 0.08  # Slower response
        self.max_rate = 0.015  # Smaller max change per frame
        self.dead_zone = 0.01  # Ignore tiny changes
        
    def smooth(self, raw_steer):
        # Dead zone - ignore very small steering
        if abs(raw_steer) < self.dead_zone:
            raw_steer = 0.0
        
        self.history.append(raw_steer)
        
        # Weighted moving average (recent values matter more)
        weights = np.linspace(0.3, 1.0, len(self.history))
        weighted_avg = np.average(list(self.history), weights=weights)
        
        # Exponential smoothing
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        
        # Rate limiting
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        
        # Final dead zone
        if abs(smoothed) < 0.005:
            smoothed = 0.0
        
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER (IMPROVED)
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 6.0  # Increased for smoother tracking
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_waypoints(self, count=15, spacing=2.0):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        return dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Adaptive lookahead based on speed
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.4
        lookahead = max(5.0, min(12.0, lookahead))
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure Pursuit with gentler gain
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = steering / math.radians(80)  # Gentler steering (was 70)
        steering = max(-1.0, min(1.0, steering))
        
        cte = self.get_cross_track_error()
        return steering, cte, True

# ============================================
# TRAFFIC LIGHT & SIGN CONTROLLER
# ============================================

class TrafficController:
    def __init__(self, vehicle, world):
        self.vehicle = vehicle
        self.world = world
        self.stopped_for_light = False
        self.stop_sign_wait = 0
        self.last_stop_sign_id = None
        
    def get_traffic_light_state(self):
        """Check if vehicle is at a red/yellow traffic light"""
        if self.vehicle.is_at_traffic_light():
            traffic_light = self.vehicle.get_traffic_light()
            if traffic_light is not None:
                state = traffic_light.get_state()
                if state == carla.TrafficLightState.Red:
                    return 'RED'
                elif state == carla.TrafficLightState.Yellow:
                    return 'YELLOW'
                elif state == carla.TrafficLightState.Green:
                    return 'GREEN'
        return 'NONE'
    
    def check_stop_signs(self):
        """Check for nearby stop signs"""
        location = self.vehicle.get_location()
        
        # Get all stop signs
        actors = self.world.get_actors()
        stop_signs = actors.filter('traffic.stop')
        
        for stop_sign in stop_signs:
            sign_loc = stop_sign.get_location()
            distance = location.distance(sign_loc)
            
            # If within 15 meters and haven't stopped for this sign yet
            if distance < 15 and stop_sign.id != self.last_stop_sign_id:
                # Check if sign is ahead of us
                vehicle_forward = self.vehicle.get_transform().get_forward_vector()
                to_sign = carla.Vector3D(
                    sign_loc.x - location.x,
                    sign_loc.y - location.y,
                    0
                )
                
                # Dot product to check if sign is in front
                dot = vehicle_forward.x * to_sign.x + vehicle_forward.y * to_sign.y
                
                if dot > 0 and distance < 8:  # Sign is ahead and close
                    return stop_sign.id, distance
        
        return None, float('inf')
    
    def get_action(self):
        """Determine what action to take based on traffic rules"""
        
        # Check traffic light
        light_state = self.get_traffic_light_state()
        
        if light_state == 'RED':
            self.stopped_for_light = True
            return 'STOP_LIGHT', 'Red light - STOP'
        
        if light_state == 'YELLOW':
            return 'SLOW_LIGHT', 'Yellow light - Slow down'
        
        if light_state == 'GREEN':
            self.stopped_for_light = False
        
        # Check stop signs
        stop_sign_id, distance = self.check_stop_signs()
        
        if stop_sign_id is not None:
            if distance < 5:  # Very close to stop sign
                if self.stop_sign_wait < 60:  # Wait for ~2 seconds at 30fps
                    self.stop_sign_wait += 1
                    self.last_stop_sign_id = stop_sign_id
                    return 'STOP_SIGN', 'Stop sign - waiting (' + str(int(self.stop_sign_wait / 30)) + 's)'
                else:
                    # Done waiting, can proceed
                    self.stop_sign_wait = 0
                    return 'CLEAR', 'Stop sign - proceeding'
            else:
                # Approaching stop sign
                return 'SLOW_SIGN', 'Approaching stop sign'
        else:
            # Reset if no stop sign nearby
            if self.stop_sign_wait > 0 and stop_sign_id is None:
                self.stop_sign_wait = 0
        
        return 'CLEAR', 'Road clear'

# ============================================
# TRACKER
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
            
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < 5]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.2
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i in range(len(self.tracks)):
            if i not in matched_tracks:
                self.tracks[i].missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < 5]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE
# ============================================

class CollisionAvoidance:
    def __init__(self, frame_width, frame_height):
        self.frame_width = frame_width
        self.frame_height = frame_height
        
        center = frame_width // 2
        self.danger_left = center - 140
        self.danger_right = center + 140
        
        self.emergency_y = 400
        self.brake_y = 340
        self.slow_y = 280
        
    def check(self, tracks):
        closest_y = 0
        danger_track = None
        
        for track in tracks:
            if track.label not in ['vehicle', 'pedestrian']:
                continue
            
            # Only consider tracks that have been seen for multiple frames
            if track.age < 2:
                continue
            
            x1, y1, x2, y2 = track.bbox
            center_x = (x1 + x2) // 2
            bottom_y = y2
            
            if self.danger_left < center_x < self.danger_right:
                if bottom_y > closest_y:
                    closest_y = bottom_y
                    danger_track = track
        
        if closest_y > self.emergency_y:
            return 'EMERGENCY', 0.0, 1.0, danger_track
        elif closest_y > self.brake_y:
            return 'BRAKE', 0.1, 0.5, danger_track
        elif closest_y > self.slow_y:
            return 'SLOW', 0.5, 0.0, danger_track
        else:
            return 'CLEAR', 1.0, 0.0, None

# ============================================
# STRICT DETECTION FILTER (NO MORE HOUSES!)
# ============================================

def filter_detections(results, w, h):
    """Very strict filtering to avoid false positives like houses"""
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        # Only detect vehicles and pedestrians
        if class_id in COCO_VEHICLE_CLASSES:
            label = 'vehicle'
        elif class_id == COCO_PERSON_CLASS:
            label = 'pedestrian'
        else:
            continue
        
        box_w = x2 - x1
        box_h = y2 - y1
        box_area = box_w * box_h
        frame_area = w * h
        aspect_ratio = box_w / box_h if box_h > 0 else 0
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        
        # === STRICT FILTERING ===
        
        # 1. High confidence only
        if conf < 0.55:  # Increased from 0.5
            continue
        
        # 2. Size constraints
        if box_w < 35 or box_h < 35:  # Minimum size
            continue
        if box_area > frame_area * 0.35:  # Max 35% of frame
            continue
        if box_area < 1500:  # Minimum area
            continue
        
        # 3. Position constraints - ignore top 25% (sky, buildings)
        if y1 < h * 0.25:
            continue
        
        # 4. VEHICLE specific filters
        if label == 'vehicle':
            # Vehicles should be wider than tall (aspect ratio 0.6 to 3.0)
            if aspect_ratio < 0.6 or aspect_ratio > 3.0:
                continue
            
            # Vehicles shouldn't be at the very top
            if y1 < h * 0.30:
                continue
            
            # Vehicles shouldn't be too tall (like buildings)
            if box_h > h * 0.6:
                continue
            
            # Vehicles should be roughly centered or on the road (not at edges)
            if center_x < w * 0.1 or center_x > w * 0.9:
                continue
            
            # If it's very large and at the top, likely a building
            if box_area > frame_area * 0.15 and y1 < h * 0.35:
                continue
        
        # 5. PEDESTRIAN specific filters
        if label == 'pedestrian':
            # Pedestrians should be taller than wide
            if aspect_ratio > 0.8:
                continue
            
            # Minimum height for pedestrians
            if box_h < 60:
                continue
            
            # Pedestrians shouldn't be huge
            if box_area > frame_area * 0.2:
                continue
        
        # 6. General sanity checks
        # Reject if box is almost square and large (likely building/object)
        if 0.85 < aspect_ratio < 1.15 and box_area > frame_area * 0.1:
            continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
                            (loc.x, loc.y, center_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 80, 0))
        frame = cv2.addWeighted(frame, 0.8, overlay, 0.2, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 2)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 200, 200), 2)
    
    return frame

def draw_tracks(frame, tracks, danger_track):
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = (0, 255, 0) if track.label == 'vehicle' else (0, 165, 255)
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        label = track.label[:3] + " " + str(round(track.conf, 2))
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def draw_hud(frame, speed, steer, cte, collision_action, traffic_status, traffic_msg, 
             track_count, throttle, fps, frame_count):
    h, w = frame.shape[:2]
    
    # Left panel - Vehicle State
    cv2.rectangle(frame, (5, 5), (190, 100), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (190, 100), (80, 80, 80), 1)
    
    cv2.putText(frame, "AUTONOMOUS v6", (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 53), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (10, 68), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (10, 83), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    cv2.putText(frame, "Objects: " + str(track_count), (10, 98), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255, 255, 255), 1)
    
    # Traffic status panel
    cv2.rectangle(frame, (5, 105), (190, 150), (0, 0, 0), -1)
    
    if traffic_status in ['STOP_LIGHT', 'STOP_SIGN']:
        cv2.rectangle(frame, (5, 105), (190, 150), (0, 0, 200), 2)
        cv2.putText(frame, "TRAFFIC: STOP", (10, 122), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
    elif traffic_status in ['SLOW_LIGHT', 'SLOW_SIGN']:
        cv2.rectangle(frame, (5, 105), (190, 150), (0, 200, 200), 2)
        cv2.putText(frame, "TRAFFIC: SLOW", (10, 122), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)
    else:
        cv2.rectangle(frame, (5, 105), (190, 150), (0, 150, 0), 2)
        cv2.putText(frame, "TRAFFIC: CLEAR", (10, 122), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    
    # Traffic message (truncate if needed)
    msg = traffic_msg[:28] if len(traffic_msg) > 28 else traffic_msg
    cv2.putText(frame, msg, (10, 140), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (200, 200, 200), 1)
    
    # Collision status
    if collision_action == 'EMERGENCY':
        cv2.rectangle(frame, (5, 155), (190, 180), (0, 0, 180), -1)
        cv2.putText(frame, "!! COLLISION BRAKE !!", (10, 172), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 2)
    elif collision_action == 'BRAKE':
        cv2.rectangle(frame, (5, 155), (190, 180), (0, 80, 180), -1)
        cv2.putText(frame, "BRAKING - OBSTACLE", (10, 172), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    elif collision_action == 'SLOW':
        cv2.rectangle(frame, (5, 155), (190, 180), (0, 140, 180), -1)
        cv2.putText(frame, "SLOWING - OBSTACLE", (10, 172), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # FPS (top right)
    cv2.rectangle(frame, (w - 90, 5), (w - 5, 45), (0, 0, 0), -1)
    fps_color = (0, 255, 0) if fps > 15 else ((0, 165, 255) if fps > 10 else (0, 0, 255))
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (w - 85, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45, fps_color, 1)
    cv2.putText(frame, "F: " + str(frame_count), (w - 85, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    print("Loading YOLOv5n...")
    model = torch.hub.load(yolo_path, 'yolov5n', source='local', pretrained=True)
    model.conf = 0.5
    model.iou = 0.45
    model.classes = [0, 2, 3, 5, 7]  # Only person, car, motorcycle, bus, truck
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Ego vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(10, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(5):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = SmoothSteering()
    tracker = Tracker()
    collision_avoidance = CollisionAvoidance(640, 480)
    traffic_controller = TrafficController(ego_vehicle, world)
    
    base_throttle = 0.30
    detect_interval = 3
    frame_count = 0
    current_tracks = []
    
    fps_history = deque(maxlen=30)
    last_time = time.time()
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    print("")
    print("========================================")
    print("AUTONOMOUS DRIVING v6")
    print("========================================")
    print("+ Smooth lane keeping")
    print("+ Traffic light obedience")
    print("+ Stop sign obedience")
    print("+ Strict vehicle detection")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Stats")
    print("========================================")
    
    cv2.namedWindow('Autonomous v6', cv2.WINDOW_NORMAL)
    
    brake_events = 0
    start_time = time.time()
    cte_history = deque(maxlen=100)
    
    try:
        while True:
            world.tick()
            frame_count += 1
            
            current_time = time.time()
            dt = current_time - last_time
            if dt > 0:
                fps_history.append(1.0 / dt)
            last_time = current_time
            fps = np.mean(fps_history) if len(fps_history) > 0 else 0
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # === YOLO Detection ===
                if frame_count % detect_interval == 0:
                    results = model(frame, size=480)
                    detections = filter_detections(results, w, h)
                    current_tracks = tracker.update(detections)
                
                # === Lane Keeping ===
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                cte_history.append(abs(cte))
                
                # === Traffic Rules ===
                traffic_status, traffic_msg = traffic_controller.get_action()
                
                # === Collision Avoidance ===
                collision_action, throttle_mult, brake, danger_track = collision_avoidance.check(current_tracks)
                
                if collision_action in ['BRAKE', 'EMERGENCY']:
                    brake_events += 1
                
                # === Determine Final Control ===
                final_throttle = base_throttle
                final_brake = 0.0
                
                # Priority 1: Traffic lights/signs
                if traffic_status == 'STOP_LIGHT':
                    final_throttle = 0.0
                    final_brake = 0.8
                elif traffic_status == 'STOP_SIGN':
                    final_throttle = 0.0
                    final_brake = 0.6
                elif traffic_status == 'SLOW_LIGHT':
                    final_throttle = base_throttle * 0.3
                elif traffic_status == 'SLOW_SIGN':
                    final_throttle = base_throttle * 0.4
                else:
                    # Priority 2: Collision avoidance
                    final_throttle = base_throttle * throttle_mult
                    final_brake = brake
                
                # Slow for curves
                if curvature > 0.08:
                    final_throttle *= 0.7
                elif curvature > 0.05:
                    final_throttle *= 0.85
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = final_brake
                ego_vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                # === Visualization ===
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks, danger_track)
                frame = draw_hud(frame, speed, steer, cte, collision_action, traffic_status, 
                                traffic_msg, len(current_tracks), final_throttle, fps, frame_count)
                
                cv2.imshow('Autonomous v6', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('p'):
                runtime = time.time() - start_time
                avg_cte = np.mean(cte_history) if len(cte_history) > 0 else 0
                print("")
                print("=== STATS ===")
                print("Runtime: " + str(round(runtime, 1)) + " s")
                print("Frames: " + str(frame_count))
                print("Avg FPS: " + str(round(fps, 1)))
                print("Avg CTE: " + str(round(avg_cte, 3)) + " m")
                print("Brake Events: " + str(brake_events))
                print("=============")
                
    finally:
        runtime = time.time() - start_time
        avg_cte = np.mean(cte_history) if len(cte_history) > 0 else 0
        
        print("")
        print("=== FINAL STATS ===")
        print("Runtime: " + str(round(runtime, 1)) + " s")
        print("Frames: " + str(frame_count))
        print("Avg FPS: " + str(round(fps, 1)))
        print("Avg CTE: " + str(round(avg_cte, 3)) + " m")
        print("Brake Events: " + str(brake_events))
        print("===================")
        
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()