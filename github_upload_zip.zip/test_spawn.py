import sys
import os
import time

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

print("Connecting to CARLA...")
client = carla.Client('localhost', 2000)
client.set_timeout(10.0)
world = client.get_world()
print("Connected!")

blueprint_library = world.get_blueprint_library()
spawn_points = world.get_map().get_spawn_points()

print("Spawning 10 vehicles near each other...")
vehicles = []
for i in range(10):
    bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    try:
        v = world.spawn_actor(bp, spawn_points[i])
        v.set_autopilot(True)
        vehicles.append(v)
        print("  Spawned vehicle " + str(i+1))
    except Exception as e:
        print("  Failed: " + str(e))

print("")
print("Look at your CARLA window now!")
print("Press Enter to clean up and exit...")
input()

for v in vehicles:
    v.destroy()
print("Done!")