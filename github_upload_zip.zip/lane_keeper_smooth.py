import sys
import os
import time
import numpy as np
import cv2
import math

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class StanleyController:
    """
    Stanley Controller - used by Stanford's DARPA winning car
    Combines heading error and cross-track error for smooth lane keeping
    """
    def __init__(self, k=2.5, k_soft=1.0, max_steer=1.0):
        self.k = k  # Cross-track error gain
        self.k_soft = k_soft  # Softening constant to prevent division by zero
        self.max_steer = max_steer
        
        # Steering smoothing
        self.prev_steer = 0.0
        self.steer_filter = 0.15  # Lower = smoother but slower response
        
    def compute(self, heading_error, cross_track_error, velocity):
        """
        Stanley control law:
        steer = heading_error + arctan(k * cross_track_error / (velocity + k_soft))
        """
        # Prevent division by zero
        velocity = max(velocity, 0.1)
        
        # Cross-track term
        cross_track_term = math.atan2(self.k * cross_track_error, velocity + self.k_soft)
        
        # Total steering
        steer = heading_error + cross_track_term
        
        # Clamp
        steer = max(-self.max_steer, min(self.max_steer, steer))
        
        # Smooth steering (low-pass filter)
        steer = self.prev_steer + self.steer_filter * (steer - self.prev_steer)
        self.prev_steer = steer
        
        return steer
    
    def reset(self):
        self.prev_steer = 0.0

class SpeedController:
    """PID controller for maintaining target speed"""
    def __init__(self, kp=0.5, ki=0.05, kd=0.1):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral = 0.0
        self.prev_error = 0.0
    
    def compute(self, target_speed, current_speed, dt):
        error = target_speed - current_speed
        
        self.integral += error * dt
        self.integral = max(-10, min(10, self.integral))
        
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        self.prev_error = error
        
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        
        throttle = max(0, min(1, output)) if output > 0 else 0
        brake = max(0, min(1, -output)) if output < 0 else 0
        
        return throttle, brake

class WaypointLaneKeeper:
    def __init__(self, vehicle, world):
        self.vehicle = vehicle
        self.world = world
        self.map = world.get_map()
        
    def get_vehicle_state(self):
        transform = self.vehicle.get_transform()
        velocity = self.vehicle.get_velocity()
        
        x = transform.location.x
        y = transform.location.y
        yaw = math.radians(transform.rotation.yaw)
        speed = math.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
        
        return x, y, yaw, speed
    
    def get_waypoint_info(self, lookahead=2.0):
        """Get waypoint ahead and calculate errors"""
        x, y, yaw, speed = self.get_vehicle_state()
        
        # Get current waypoint
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        
        if current_wp is None:
            return 0, 0, False
        
        # Get waypoint ahead based on speed (adaptive lookahead)
        adaptive_lookahead = max(2.0, min(10.0, lookahead + speed * 0.5))
        next_wps = current_wp.next(adaptive_lookahead)
        
        if len(next_wps) == 0:
            return 0, 0, False
        
        target_wp = next_wps[0]
        
        # Target position and heading
        target_x = target_wp.transform.location.x
        target_y = target_wp.transform.location.y
        target_yaw = math.radians(target_wp.transform.rotation.yaw)
        
        # === HEADING ERROR ===
        # Difference between vehicle heading and lane heading
        heading_error = target_yaw - yaw
        
        # Normalize to [-pi, pi]
        while heading_error > math.pi:
            heading_error -= 2 * math.pi
        while heading_error < -math.pi:
            heading_error += 2 * math.pi
        
        # === CROSS-TRACK ERROR ===
        # Vector from current waypoint to vehicle
        wp_x = current_wp.transform.location.x
        wp_y = current_wp.transform.location.y
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        
        dx = x - wp_x
        dy = y - wp_y
        
        # Cross-track error (positive = right of center, negative = left)
        cross_track_error = dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
        
        return heading_error, cross_track_error, True
    
    def get_next_waypoints(self, distance=25.0, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        
        if current_wp is None:
            return []
        
        waypoints = [current_wp]
        next_wp = current_wp
        traveled = 0
        
        while traveled < distance:
            next_wps = next_wp.next(spacing)
            if len(next_wps) == 0:
                break
            next_wp = next_wps[0]
            waypoints.append(next_wp)
            traveled += spacing
        
        return waypoints
    
    def draw_lane(self, frame, waypoints):
        if len(waypoints) < 2:
            return frame
        
        img_h, img_w = frame.shape[:2]
        fov = 90
        f = img_w / (2 * math.tan(math.radians(fov / 2)))
        
        vehicle_transform = self.vehicle.get_transform()
        veh_x = vehicle_transform.location.x
        veh_y = vehicle_transform.location.y
        veh_z = vehicle_transform.location.z
        veh_yaw = math.radians(-vehicle_transform.rotation.yaw)
        
        cam_x, cam_z = 2.0, 1.4
        
        left_pts = []
        right_pts = []
        center_pts = []
        
        for wp in waypoints:
            wp_loc = wp.transform.location
            wp_yaw = math.radians(wp.transform.rotation.yaw)
            half_width = wp.lane_width / 2 * 0.95  # Slightly inside actual boundary
            
            # Lane boundaries in world coordinates
            left_x = wp_loc.x - half_width * math.sin(wp_yaw)
            left_y = wp_loc.y + half_width * math.cos(wp_yaw)
            right_x = wp_loc.x + half_width * math.sin(wp_yaw)
            right_y = wp_loc.y - half_width * math.cos(wp_yaw)
            center_x = wp_loc.x
            center_y = wp_loc.y
            
            for wx, wy, pts_list in [(left_x, left_y, left_pts), 
                                      (right_x, right_y, right_pts),
                                      (center_x, center_y, center_pts)]:
                # Transform to vehicle frame
                dx = wx - veh_x
                dy = wy - veh_y
                dz = wp_loc.z - veh_z
                
                local_x = dx * math.cos(veh_yaw) - dy * math.sin(veh_yaw) - cam_x
                local_y = dx * math.sin(veh_yaw) + dy * math.cos(veh_yaw)
                local_z = dz - cam_z
                
                if local_x < 1.0:
                    continue
                
                # Project to image
                u = int(img_w / 2 - f * local_y / local_x)
                v = int(img_h / 2 - f * local_z / local_x)
                
                if 0 <= u < img_w and 0 <= v < img_h:
                    pts_list.append((u, v))
        
        # Draw filled lane area
        if len(left_pts) > 2 and len(right_pts) > 2:
            all_pts = left_pts + right_pts[::-1]
            overlay = frame.copy()
            cv2.fillPoly(overlay, [np.array(all_pts, np.int32)], (0, 180, 0))
            frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
        
        # Draw lane boundaries
        for i in range(1, len(left_pts)):
            cv2.line(frame, left_pts[i-1], left_pts[i], (255, 100, 100), 3)
        for i in range(1, len(right_pts)):
            cv2.line(frame, right_pts[i-1], right_pts[i], (100, 100, 255), 3)
        
        # Draw center line (dashed)
        for i in range(1, len(center_pts), 2):
            if i < len(center_pts):
                cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)
        
        return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def draw_steering_wheel(frame, steering, x, y, radius=50):
    """Draw a steering wheel indicator"""
    # Outer circle
    cv2.circle(frame, (x, y), radius, (200, 200, 200), 2)
    
    # Steering position
    angle = -steering * math.pi / 2  # Max 90 degrees rotation
    end_x = int(x + radius * 0.8 * math.sin(angle))
    end_y = int(y - radius * 0.8 * math.cos(angle))
    
    # Draw steering indicator
    cv2.line(frame, (x, y), (end_x, end_y), (0, 255, 255), 4)
    cv2.circle(frame, (x, y), 8, (0, 255, 255), -1)
    
    # Draw center mark
    cv2.line(frame, (x, y - radius + 5), (x, y - radius + 15), (255, 255, 255), 2)

def draw_speedometer(frame, speed, target_speed, x, y):
    """Draw speed bar"""
    bar_width = 120
    bar_height = 15
    
    # Background
    cv2.rectangle(frame, (x, y), (x + bar_width, y + bar_height), (50, 50, 50), -1)
    
    # Current speed bar
    speed_ratio = min(speed / 50, 1.0)  # Assume max 50 km/h
    cv2.rectangle(frame, (x, y), (x + int(bar_width * speed_ratio), y + bar_height), (0, 200, 0), -1)
    
    # Target speed marker
    target_ratio = min(target_speed / 50, 1.0)
    target_x = x + int(bar_width * target_ratio)
    cv2.line(frame, (target_x, y - 3), (target_x, y + bar_height + 3), (0, 255, 255), 2)
    
    # Border
    cv2.rectangle(frame, (x, y), (x + bar_width, y + bar_height), (200, 200, 200), 1)

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    # Set synchronous mode for smoother simulation
    settings = world.get_settings()
    original_settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = 0.05  # 20 FPS
    world.apply_settings(settings)
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Controllers
    stanley = StanleyController(k=2.5, k_soft=1.0, max_steer=0.8)
    speed_ctrl = SpeedController(kp=0.8, ki=0.1, kd=0.05)
    
    # Lane keeper
    lane_keeper = WaypointLaneKeeper(vehicle, world)
    
    # Target speed (km/h)
    target_speed = 30.0
    lookahead = 3.0
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.05)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("SMOOTH LANE KEEPING (Stanley Controller)")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Increase/Decrease target speed")
    print("  A/D - Adjust Stanley gain (responsiveness)")
    print("========================================")
    print("")
    
    dt = 0.05
    
    try:
        while True:
            world.tick()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Get vehicle state
                _, _, _, current_speed = lane_keeper.get_vehicle_state()
                current_speed_kmh = current_speed * 3.6
                
                # Get waypoint errors
                heading_error, cross_track_error, valid = lane_keeper.get_waypoint_info(lookahead)
                
                # Calculate steering with Stanley controller
                if valid:
                    steering = stanley.compute(heading_error, cross_track_error, current_speed)
                else:
                    steering = 0.0
                    stanley.reset()
                
                # Calculate throttle/brake with speed controller
                throttle, brake = speed_ctrl.compute(target_speed / 3.6, current_speed, dt)
                
                # Apply control
                control = carla.VehicleControl()
                control.steer = float(steering)
                control.throttle = float(throttle)
                control.brake = float(brake)
                vehicle.apply_control(control)
                
                # Get waypoints for visualization
                waypoints = lane_keeper.get_next_waypoints(distance=25.0, spacing=1.5)
                
                # Draw lane visualization
                frame = lane_keeper.draw_lane(frame, waypoints)
                
                # Draw HUD
                # Title
                cv2.putText(frame, "LANE KEEPING SYSTEM", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                
                # Status
                status = "ACTIVE" if valid else "SEARCHING"
                status_color = (0, 255, 0) if valid else (0, 165, 255)
                cv2.putText(frame, status, (650, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, status_color, 2)
                
                # Info panel background
                cv2.rectangle(frame, (5, 45), (200, 175), (0, 0, 0), -1)
                cv2.rectangle(frame, (5, 45), (200, 175), (100, 100, 100), 1)
                
                # Info text
                cv2.putText(frame, "Speed: " + str(round(current_speed_kmh, 1)) + " km/h", 
                           (15, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Target: " + str(round(target_speed, 1)) + " km/h", 
                           (15, 95), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Steer: " + str(round(steering, 3)), 
                           (15, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "CTE: " + str(round(cross_track_error, 2)) + " m", 
                           (15, 145), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(frame, "Gain: " + str(round(stanley.k, 1)), 
                           (15, 170), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                # Draw steering wheel indicator
                draw_steering_wheel(frame, steering, 730, 520, radius=45)
                
                # Draw speed bar
                draw_speedometer(frame, current_speed_kmh, target_speed, 600, 570)
                
                cv2.imshow('Lane Keeping', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                target_speed = min(60, target_speed + 5)
                print("Target speed: " + str(round(target_speed, 1)) + " km/h")
            elif key == ord('s'):
                target_speed = max(10, target_speed - 5)
                print("Target speed: " + str(round(target_speed, 1)) + " km/h")
            elif key == ord('d'):
                stanley.k = min(5.0, stanley.k + 0.5)
                print("Stanley gain: " + str(round(stanley.k, 1)))
            elif key == ord('a'):
                stanley.k = max(0.5, stanley.k - 0.5)
                print("Stanley gain: " + str(round(stanley.k, 1)))
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        # Restore settings
        world.apply_settings(original_settings)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()