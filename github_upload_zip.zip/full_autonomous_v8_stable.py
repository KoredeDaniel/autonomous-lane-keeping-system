import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

COCO_CLASSES = {
    0: 'person',
    2: 'car',
    3: 'motorcycle',
    5: 'bus',
    7: 'truck',
    9: 'traffic_light',
    11: 'stop_sign'
}

# ============================================
# STABLE STEERING (PD CONTROLLER - NO FIDGET)
# ============================================

class StableSteering:
    """
    PD controller for smooth steering without oscillation.
    The derivative term dampens sudden changes.
    """
    def __init__(self):
        self.prev_steer = 0.0
        self.prev_raw = 0.0
        
    def smooth(self, raw_steer):
        # Dead zone
        if abs(raw_steer) < 0.008:
            raw_steer = 0.0
        
        # Calculate error and derivative
        error = raw_steer - self.prev_steer
        raw_change = raw_steer - self.prev_raw
        
        # PD gains
        kp = 0.20  # Proportional - response speed
        kd = 0.10  # Derivative - damping
        
        # PD output (derivative term dampens oscillation)
        adjustment = kp * error - kd * raw_change
        
        # Apply adjustment
        new_steer = self.prev_steer + adjustment
        
        # Rate limiting
        max_rate = 0.04
        diff = new_steer - self.prev_steer
        if abs(diff) > max_rate:
            new_steer = self.prev_steer + max_rate * np.sign(diff)
        
        # Clamp
        new_steer = max(-1.0, min(1.0, new_steer))
        
        # Store
        self.prev_raw = raw_steer
        self.prev_steer = new_steer
        
        return new_steer

# ============================================
# LANE KEEPER (OPTIMIZED)
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.prev_curvature = 0.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_waypoints(self, count=20, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return self.prev_curvature
        
        p1 = waypoints[0].transform.location
        mid_idx = min(5, len(waypoints) // 2)
        end_idx = min(10, len(waypoints) - 1)
        p2 = waypoints[mid_idx].transform.location
        p3 = waypoints[end_idx].transform.location
        
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return self.prev_curvature
        
        curvature = 4 * math.sqrt(area_sq) / (a * b * c)
        
        # Smooth curvature
        self.prev_curvature = 0.7 * self.prev_curvature + 0.3 * curvature
        return self.prev_curvature
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        return dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        # Balanced lookahead
        speed = self.get_speed()
        lookahead = max(4.0, min(7.0, 4.0 + speed * 0.25))
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 1.5))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 1.5
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure Pursuit
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = steering / math.radians(60)
        steering = max(-1.0, min(1.0, steering))
        
        cte = self.get_cross_track_error()
        return steering, cte, True

# ============================================
# TRAFFIC CONTROLLER (UNCHANGED FROM V8)
# ============================================

class TrafficController:
    def __init__(self, vehicle, world):
        self.vehicle = vehicle
        self.world = world
        self.stop_sign_wait = 0
        self.last_stop_sign_id = None
        self.frames_since_green = 0
        
    def get_traffic_light_state(self):
        """Fast traffic light check"""
        if self.vehicle.is_at_traffic_light():
            traffic_light = self.vehicle.get_traffic_light()
            if traffic_light is not None:
                state = traffic_light.get_state()
                if state == carla.TrafficLightState.Red:
                    self.frames_since_green = 0
                    return 'RED'
                elif state == carla.TrafficLightState.Yellow:
                    return 'YELLOW'
                elif state == carla.TrafficLightState.Green:
                    self.frames_since_green += 1
                    return 'GREEN'
        return 'NONE'
    
    def check_stop_signs(self):
        """Fast stop sign check"""
        location = self.vehicle.get_location()
        actors = self.world.get_actors()
        stop_signs = actors.filter('traffic.stop')
        
        for stop_sign in stop_signs:
            sign_loc = stop_sign.get_location()
            distance = location.distance(sign_loc)
            
            if distance < 10 and stop_sign.id != self.last_stop_sign_id:
                vehicle_forward = self.vehicle.get_transform().get_forward_vector()
                to_sign = carla.Vector3D(
                    sign_loc.x - location.x,
                    sign_loc.y - location.y,
                    0
                )
                dot = vehicle_forward.x * to_sign.x + vehicle_forward.y * to_sign.y
                
                if dot > 0 and distance < 5:
                    return stop_sign.id, distance
        
        return None, float('inf')
    
    def get_action(self):
        """FAST decision making"""
        
        light_state = self.get_traffic_light_state()
        
        if light_state == 'RED':
            return 'STOP_LIGHT', 'RED - STOP'
        
        if light_state == 'YELLOW':
            return 'SLOW_LIGHT', 'YELLOW - SLOW'
        
        stop_sign_id, distance = self.check_stop_signs()
        
        if stop_sign_id is not None:
            if distance < 4:
                if self.stop_sign_wait < 30:
                    self.stop_sign_wait += 1
                    self.last_stop_sign_id = stop_sign_id
                    remaining = max(0, 1.0 - self.stop_sign_wait / 30)
                    return 'STOP_SIGN', 'STOP - ' + str(round(remaining, 1)) + 's'
                else:
                    self.stop_sign_wait = 0
                    return 'CLEAR', 'GO'
            else:
                return 'SLOW_SIGN', 'STOP AHEAD'
        else:
            if self.stop_sign_wait > 0:
                self.stop_sign_wait = 0
        
        if light_state == 'GREEN':
            return 'CLEAR', 'GREEN - GO'
        
        return 'CLEAR', 'CLEAR'

# ============================================
# TRACKER (OPTIMIZED)
# ============================================

class Track:
    __slots__ = ['id', 'bbox', 'label', 'conf', 'missed', 'age']
    
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
            
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < 4]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.2
            best_i = -1
            dx1, dy1, dx2, dy2 = det['bbox']
            
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                tx1, ty1, tx2, ty2 = track.bbox
                
                # Fast IOU
                ix1 = max(dx1, tx1)
                iy1 = max(dy1, ty1)
                ix2 = min(dx2, tx2)
                iy2 = min(dy2, ty2)
                inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
                area1 = (dx2 - dx1) * (dy2 - dy1)
                area2 = (tx2 - tx1) * (ty2 - ty1)
                iou = inter / (area1 + area2 - inter + 1e-6)
                
                if iou > best_iou:
                    best_iou = iou
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i in range(len(self.tracks)):
            if i not in matched_tracks:
                self.tracks[i].missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < 4]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE (UNCHANGED)
# ============================================

class CollisionAvoidance:
    def __init__(self, frame_width, frame_height):
        self.frame_width = frame_width
        self.frame_height = frame_height
        
        center = frame_width // 2
        self.danger_left = center - 140
        self.danger_right = center + 140
        
        self.emergency_y = 400
        self.brake_y = 340
        self.slow_y = 280
        
    def check(self, tracks):
        closest_y = 0
        danger_track = None
        
        for track in tracks:
            if track.label not in ['car', 'motorcycle', 'bus', 'truck', 'person']:
                continue
            
            if track.age < 2:
                continue
            
            x1, y1, x2, y2 = track.bbox
            center_x = (x1 + x2) // 2
            bottom_y = y2
            
            if self.danger_left < center_x < self.danger_right:
                if bottom_y > closest_y:
                    closest_y = bottom_y
                    danger_track = track
        
        if closest_y > self.emergency_y:
            return 'EMERGENCY', 0.0, 1.0, danger_track
        elif closest_y > self.brake_y:
            return 'BRAKE', 0.1, 0.5, danger_track
        elif closest_y > self.slow_y:
            return 'SLOW', 0.5, 0.0, danger_track
        else:
            return 'CLEAR', 1.0, 0.0, None

# ============================================
# DETECTION FILTER (UNCHANGED)
# ============================================

def filter_detections(results, w, h):
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        if class_id not in COCO_CLASSES:
            continue
        
        label = COCO_CLASSES[class_id]
        
        box_w = x2 - x1
        box_h = y2 - y1
        box_area = box_w * box_h
        frame_area = w * h
        aspect_ratio = box_w / box_h if box_h > 0 else 0
        center_x = (x1 + x2) / 2
        
        # ========== CAR ==========
        if label == 'car':
            if conf < 0.6:
                continue
            if y1 < h * 0.35:
                continue
            if aspect_ratio < 0.8 or aspect_ratio > 2.5:
                continue
            if box_w < 40 or box_h < 30:
                continue
            if box_area > frame_area * 0.25:
                continue
            if center_x < w * 0.08 or center_x > w * 0.92:
                continue
            if box_h > h * 0.45:
                continue
        
        # ========== MOTORCYCLE ==========
        elif label == 'motorcycle':
            if conf < 0.55:
                continue
            if y1 < h * 0.35:
                continue
            if aspect_ratio > 2.0:
                continue
            if box_w < 25 or box_h < 35:
                continue
            if box_area > frame_area * 0.15:
                continue
        
        # ========== BUS/TRUCK ==========
        elif label in ['bus', 'truck']:
            if conf < 0.55:
                continue
            if y1 < h * 0.30:
                continue
            if box_area < 3000:
                continue
            if box_area > frame_area * 0.4:
                continue
            if aspect_ratio < 0.5 or aspect_ratio > 3.0:
                continue
        
        # ========== PERSON ==========
        elif label == 'person':
            if conf < 0.5:
                continue
            if aspect_ratio > 0.75:
                continue
            if y1 < h * 0.30:
                continue
            if box_h < 50:
                continue
            if box_area > frame_area * 0.2:
                continue
        
        # ========== TRAFFIC LIGHT ==========
        elif label == 'traffic_light':
            if conf < 0.4:
                continue
            if y2 > h * 0.7:
                continue
            if aspect_ratio > 1.2:
                continue
            if box_area < 200 or box_area > frame_area * 0.1:
                continue
        
        # ========== STOP SIGN ==========
        elif label == 'stop_sign':
            if conf < 0.4:
                continue
            if aspect_ratio < 0.6 or aspect_ratio > 1.6:
                continue
            if box_area < 300 or box_area > frame_area * 0.15:
                continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

# ============================================
# VISUALIZATION (OPTIMIZED BUT COMPLETE)
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    center_pts = []
    left_pts = []
    right_pts = []
    
    for i, wp in enumerate(waypoints):
        if i % 2 != 0 and i < len(waypoints) - 1:  # Skip some for speed
            continue
            
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        dx, dy, dz = loc.x - vx, loc.y - vy, loc.z - vz
        lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
        ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
        lz = dz - 1.4
        
        if lx > 0.5:
            u = int(w/2 - f * ly / lx)
            v = int(h/2 - f * lz / lx)
            if 0 <= u < w and 0 <= v < h:
                center_pts.append((u, v))
                
                # Left/right offsets
                ly_left = ly + hw * math.cos(vyaw - math.radians(wp.transform.rotation.yaw))
                ly_right = ly - hw * math.cos(vyaw - math.radians(wp.transform.rotation.yaw))
                
                u_left = int(w/2 - f * (ly + hw) / lx)
                u_right = int(w/2 - f * (ly - hw) / lx)
                
                if 0 <= u_left < w:
                    left_pts.append((u_left, v))
                if 0 <= u_right < w:
                    right_pts.append((u_right, v))
    
    # Draw lane lines
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 100, 100), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (100, 100, 255), 2)
    for i in range(1, len(center_pts)):
        cv2.line(frame, center_pts[i-1], center_pts[i], (0, 255, 255), 2)
    
    return frame

def draw_tracks(frame, tracks, danger_track):
    colors = {
        'car': (0, 255, 0),
        'motorcycle': (255, 165, 0),
        'bus': (255, 0, 255),
        'truck': (0, 255, 255),
        'person': (0, 0, 255),
        'traffic_light': (255, 255, 0),
        'stop_sign': (128, 0, 255)
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = colors.get(track.label, (255, 255, 255))
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        cv2.putText(frame, track.label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def draw_hud(frame, speed, steer, cte, collision_action, traffic_status, traffic_msg, 
             track_count, throttle, fps, curvature):
    h, w = frame.shape[:2]
    
    # Left panel
    cv2.rectangle(frame, (5, 5), (180, 95), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (180, 95), (80, 80, 80), 1)
    
    cv2.putText(frame, "AUTONOMOUS v8s", (10, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 34), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (10, 62), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    cv2.putText(frame, "Curve: " + str(round(curvature, 3)), (10, 76), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    cv2.putText(frame, "Objects: " + str(track_count), (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 255, 255), 1)
    
    # Traffic panel
    cv2.rectangle(frame, (5, 100), (180, 135), (0, 0, 0), -1)
    
    if traffic_status in ['STOP_LIGHT', 'STOP_SIGN']:
        cv2.rectangle(frame, (5, 100), (180, 135), (0, 0, 200), 2)
        cv2.putText(frame, "STOP", (10, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
    elif traffic_status in ['SLOW_LIGHT', 'SLOW_SIGN']:
        cv2.rectangle(frame, (5, 100), (180, 135), (0, 200, 200), 2)
        cv2.putText(frame, "SLOW", (10, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
    else:
        cv2.rectangle(frame, (5, 100), (180, 135), (0, 150, 0), 2)
        cv2.putText(frame, "GO", (10, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    
    cv2.putText(frame, traffic_msg, (50, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1)
    
    # Collision
    if collision_action == 'EMERGENCY':
        cv2.rectangle(frame, (5, 140), (180, 160), (0, 0, 180), -1)
        cv2.putText(frame, "!! EMERGENCY !!", (10, 155), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 2)
    elif collision_action == 'BRAKE':
        cv2.rectangle(frame, (5, 140), (180, 160), (0, 80, 180), -1)
        cv2.putText(frame, "BRAKING", (10, 155), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    elif collision_action == 'SLOW':
        cv2.rectangle(frame, (5, 140), (180, 160), (0, 140, 180), -1)
        cv2.putText(frame, "SLOWING", (10, 155), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # FPS
    cv2.rectangle(frame, (w - 80, 5), (w - 5, 35), (0, 0, 0), -1)
    fps_color = (0, 255, 0) if fps > 25 else ((0, 165, 255) if fps > 15 else (0, 0, 255))
    cv2.putText(frame, str(round(fps, 0)) + " FPS", (w - 75, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.45, fps_color, 1)
    
    # Steering indicator
    bar_x = w // 2
    bar_y = h - 25
    bar_w = 120
    cv2.line(frame, (bar_x - bar_w, bar_y), (bar_x + bar_w, bar_y), (80, 80, 80), 2)
    cv2.circle(frame, (bar_x, bar_y), 4, (255, 255, 255), -1)
    steer_px = int(bar_x - steer * bar_w)
    steer_px = max(bar_x - bar_w, min(bar_x + bar_w, steer_px))
    cv2.circle(frame, (steer_px, bar_y), 7, (0, 255, 255), -1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    print("Loading YOLOv5n...")
    model = torch.hub.load(yolo_path, 'yolov5n', source='local', pretrained=True)
    model.conf = 0.4
    model.iou = 0.45
    model.classes = [0, 2, 3, 5, 7, 9, 11]
    model.max_det = 30  # Limit max detections for speed
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(8, len(spawn_points))):  # Fewer NPCs for FPS
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(4):  # Fewer pedestrians
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = StableSteering()
    tracker = Tracker()
    collision_avoidance = CollisionAvoidance(640, 480)
    traffic_controller = TrafficController(ego_vehicle, world)
    
    base_throttle = 0.30
    detect_interval = 3  # YOLO every 3 frames
    frame_count = 0
    current_tracks = []
    
    fps_history = deque(maxlen=30)
    last_time = time.time()
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    print("")
    print("========================================")
    print("AUTONOMOUS v8 STABLE")
    print("========================================")
    print("+ PD steering controller (no fidget)")
    print("+ Traffic light/sign obedience")
    print("+ Optimized for better FPS")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Stats")
    print("========================================")
    
    cv2.namedWindow('Autonomous v8s', cv2.WINDOW_NORMAL)
    
    brake_events = 0
    start_time = time.time()
    cte_history = deque(maxlen=100)
    
    try:
        while True:
            world.tick()
            frame_count += 1
            
            current_time = time.time()
            dt = current_time - last_time
            if dt > 0:
                fps_history.append(1.0 / dt)
            last_time = current_time
            fps = np.mean(fps_history) if len(fps_history) > 0 else 0
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # YOLO every 3 frames
                if frame_count % detect_interval == 0:
                    results = model(frame, size=416)  # Slightly smaller for speed
                    detections = filter_detections(results, w, h)
                    current_tracks = tracker.update(detections)
                
                # Lane keeping
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else steering_smoother.smooth(0.0)
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                cte_history.append(abs(cte))
                
                # Traffic (EVERY frame for responsiveness)
                traffic_status, traffic_msg = traffic_controller.get_action()
                
                # Collision
                collision_action, throttle_mult, brake, danger_track = collision_avoidance.check(current_tracks)
                
                if collision_action in ['BRAKE', 'EMERGENCY']:
                    brake_events += 1
                
                # Control - traffic has priority
                final_throttle = base_throttle
                final_brake = 0.0
                
                if traffic_status == 'STOP_LIGHT':
                    final_throttle = 0.0
                    final_brake = 0.8
                elif traffic_status == 'STOP_SIGN':
                    final_throttle = 0.0
                    final_brake = 0.6
                elif traffic_status == 'SLOW_LIGHT':
                    final_throttle = base_throttle * 0.4
                elif traffic_status == 'SLOW_SIGN':
                    final_throttle = base_throttle * 0.5
                else:
                    final_throttle = base_throttle * throttle_mult
                    final_brake = brake
                
                # Curve handling
                if curvature > 0.1:
                    final_throttle *= 0.6
                elif curvature > 0.06:
                    final_throttle *= 0.8
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = final_brake
                ego_vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                # Viz
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks, danger_track)
                frame = draw_hud(frame, speed, steer, cte, collision_action, traffic_status, 
                                traffic_msg, len(current_tracks), final_throttle, fps, curvature)
                
                cv2.imshow('Autonomous v8s', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('p'):
                runtime = time.time() - start_time
                avg_cte = np.mean(cte_history) if len(cte_history) > 0 else 0
                print("")
                print("=== STATS ===")
                print("Runtime: " + str(round(runtime, 1)) + " s")
                print("Avg FPS: " + str(round(fps, 1)))
                print("Avg CTE: " + str(round(avg_cte, 3)) + " m")
                print("Brakes: " + str(brake_events))
                print("=============")
                
    finally:
        print("")
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()