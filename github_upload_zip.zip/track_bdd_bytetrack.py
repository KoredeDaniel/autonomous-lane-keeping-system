# -*- coding: utf-8 -*-
import os
import cv2
import numpy as np
import torch

# ----------------------------
# Minimal ByteTrack (local)
# ----------------------------
try:
    from bytetrack.byte_tracker import BYTETracker
except Exception as e:
    raise RuntimeError(
        "ByteTrack not found. Create folder yolov5\\bytetrack\\ with byte_tracker.py etc.\n"
        "Error: " + str(e)
    )

# BDD100K class names (your trained dataset)
NAMES = ['vehicle', 'pedestrian', 'traffic_light', 'traffic_sign']

def ensure_dir(p):
    if not os.path.exists(p):
        os.makedirs(p)

def main():
    yolov5_root = r"C:\Users\CARLACODES\1_code\yolov5"
    weights = os.path.join(yolov5_root, r"runs\train\yolov5n_bdd100k_src\weights\best.pt")
    source = os.path.join(yolov5_root, r"datasets\bdd100k_src\val\images")
    out_dir = os.path.join(yolov5_root, r"runs\track\bdd_bytetrack_demo")
    ensure_dir(out_dir)

    print("[INFO] Loading model:", weights)
    model = torch.hub.load(yolov5_root, 'custom', path=weights, source='local')
    model.conf = 0.25
    model.iou = 0.45
    model.max_det = 200

    tracker = BYTETracker(track_thresh=0.5, match_thresh=0.8, low_thresh=0.1, max_time_lost=30)

    img_files = [f for f in os.listdir(source) if f.lower().endswith(('.jpg', '.png'))]
    img_files.sort()

    if len(img_files) == 0:
        raise FileNotFoundError("No images found in: " + source)

    # Setup video writer based on first image
    first = cv2.imread(os.path.join(source, img_files[0]))
    h, w = first.shape[:2]
    video_path = os.path.join(out_dir, "bdd_bytetrack_demo.mp4")
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    vw = cv2.VideoWriter(video_path, fourcc, 20.0, (w, h))

    print("[INFO] Tracking", len(img_files), "images... output:", out_dir)

    for idx, fn in enumerate(img_files, 1):
        path = os.path.join(source, fn)
        frame = cv2.imread(path)

        # YOLO: dets = [x1,y1,x2,y2,conf,cls]
        res = model(frame, size=640)
        dets = res.xyxy[0].cpu().numpy() if len(res.xyxy) else np.zeros((0, 6), dtype=np.float32)

        if dets.shape[0] > 0:
            tlbr = dets[:, 0:4].astype(np.float32)
            scores = dets[:, 4].astype(np.float32)
            cls_ids = dets[:, 5].astype(np.int32)
        else:
            tlbr = np.zeros((0, 4), dtype=np.float32)
            scores = np.zeros((0,), dtype=np.float32)
            cls_ids = np.zeros((0,), dtype=np.int32)

        tracks = tracker.update(tlbr, scores, cls_ids)

        # Draw tracks
        for t in tracks:
            x, y, bw, bh = t.tlwh
            x1, y1, x2, y2 = int(x), int(y), int(x + bw), int(y + bh)
            tid = int(t.track_id)
            cls = int(t.cls_id) if t.cls_id is not None else -1
            label = NAMES[cls] if 0 <= cls < len(NAMES) else "cls" + str(cls)

            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(frame, f"ID {tid} {label}", (x1, max(0, y1 - 8)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # Save frame + video
        vw.write(frame)
        if idx % 10 == 0:
            print(f"[INFO] {idx}/{len(img_files)}")

        # optional: save a few frames
        if idx <= 20:
            cv2.imwrite(os.path.join(out_dir, f"frame_{idx:04d}.jpg"), frame)

    vw.release()
    print("[DONE] Video:", video_path)

if __name__ == "__main__":
    main()