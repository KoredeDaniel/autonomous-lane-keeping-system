import sys
import time
import random
import numpy as np
import cv2
import math
import torch
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

yolo_path = r"c:\users\CARLACODES\1_code\yolov5"
sys.path.append(yolo_path)

import carla

camera_image = None

COCO_VEHICLE_CLASSES = [2, 3, 5, 7]
COCO_PERSON_CLASS = 0
COCO_TRAFFIC_LIGHT = 9
COCO_STOP_SIGN = 11

# ============================================
# VLA REASONING MODULE (Language Component)
# ============================================

class VLAReasoner:
    """
    Vision-Language-Action Reasoner
    Generates natural language descriptions of the scene
    and provides reasoning for driving decisions.
    """
    
    def __init__(self):
        self.scene_history = deque(maxlen=5)
        self.action_history = deque(maxlen=10)
        self.current_reasoning = ""
        self.current_action_explanation = ""
    
    def analyze_scene(self, tracks, speed, curvature):
        """Generate natural language scene description"""
        
        # Count objects by type
        vehicles = [t for t in tracks if t.label == 'vehicle']
        pedestrians = [t for t in tracks if t.label == 'pedestrian']
        traffic_lights = [t for t in tracks if t.label == 'traffic_light']
        
        # Build scene description
        scene_parts = []
        
        # Describe vehicles
        if len(vehicles) == 0:
            scene_parts.append("No vehicles detected ahead")
        elif len(vehicles) == 1:
            scene_parts.append("1 vehicle detected")
        else:
            scene_parts.append(str(len(vehicles)) + " vehicles detected")
        
        # Describe pedestrians
        if len(pedestrians) > 0:
            scene_parts.append(str(len(pedestrians)) + " pedestrian(s) nearby")
        
        # Describe road
        if curvature > 0.08:
            scene_parts.append("sharp curve ahead")
        elif curvature > 0.05:
            scene_parts.append("gentle curve ahead")
        else:
            scene_parts.append("straight road")
        
        # Speed context
        if speed < 5:
            scene_parts.append("vehicle nearly stopped")
        elif speed < 15:
            scene_parts.append("low speed")
        elif speed < 30:
            scene_parts.append("moderate speed")
        else:
            scene_parts.append("high speed")
        
        scene_description = " | ".join(scene_parts)
        self.scene_history.append(scene_description)
        
        return scene_description
    
    def reason_action(self, action, danger_track, tracks, curvature):
        """Generate reasoning chain for the action decision"""
        
        reasoning_steps = []
        
        # Step 1: Perception summary
        reasoning_steps.append("PERCEIVE: " + str(len(tracks)) + " objects tracked")
        
        # Step 2: Risk assessment
        if danger_track:
            if danger_track.label == 'pedestrian':
                reasoning_steps.append("RISK: Pedestrian in path (HIGH)")
            else:
                reasoning_steps.append("RISK: Vehicle in path (MEDIUM)")
        else:
            reasoning_steps.append("RISK: Path clear (LOW)")
        
        # Step 3: Road analysis
        if curvature > 0.08:
            reasoning_steps.append("ROAD: Sharp curve requires speed reduction")
        elif curvature > 0.05:
            reasoning_steps.append("ROAD: Curve ahead, maintain caution")
        else:
            reasoning_steps.append("ROAD: Straight segment, normal speed OK")
        
        # Step 4: Decision
        if action == 'EMERGENCY':
            reasoning_steps.append("DECIDE: Emergency brake - imminent collision")
        elif action == 'BRAKE':
            reasoning_steps.append("DECIDE: Apply brakes - obstacle too close")
        elif action == 'SLOW':
            reasoning_steps.append("DECIDE: Reduce speed - obstacle approaching")
        else:
            reasoning_steps.append("DECIDE: Continue normal driving")
        
        self.current_reasoning = " -> ".join(reasoning_steps)
        return self.current_reasoning
    
    def explain_action(self, action, steer, throttle, brake, danger_track):
        """Generate human-readable action explanation"""
        
        explanations = []
        
        # Steering explanation
        if abs(steer) < 0.05:
            explanations.append("Steering: straight")
        elif steer > 0:
            explanations.append("Steering: turning right")
        else:
            explanations.append("Steering: turning left")
        
        # Speed control explanation
        if action == 'EMERGENCY':
            explanations.append("Action: EMERGENCY STOP - obstacle imminent")
        elif action == 'BRAKE':
            if danger_track:
                explanations.append("Action: Braking for " + danger_track.label)
            else:
                explanations.append("Action: Braking")
        elif action == 'SLOW':
            explanations.append("Action: Slowing down - caution")
        else:
            explanations.append("Action: Normal driving at throttle " + str(round(throttle, 2)))
        
        self.current_action_explanation = " | ".join(explanations)
        self.action_history.append(self.current_action_explanation)
        
        return self.current_action_explanation
    
    def get_chain_of_thought(self):
        """Return full reasoning chain for logging/display"""
        return {
            'scene': list(self.scene_history),
            'reasoning': self.current_reasoning,
            'action': self.current_action_explanation
        }

# ============================================
# STEERING SMOOTHER
# ============================================

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        self.smoothing_factor = 0.12
        self.max_rate = 0.03
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        self.prev_steer = smoothed
        return smoothed

# ============================================
# LANE KEEPER
# ============================================

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 5.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.3
        return max(3.0, min(10.0, lookahead))
    
    def get_waypoints(self, count=15, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        cte = dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
        return cte
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        lookahead = self.get_adaptive_lookahead()
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        cte = self.get_cross_track_error()
        
        return steering, cte, True

# ============================================
# OBJECT TRACKER
# ============================================

class Track:
    def __init__(self, track_id, bbox, label, conf):
        self.id = track_id
        self.bbox = bbox
        self.label = label
        self.conf = conf
        self.missed = 0
        self.age = 0

class Tracker:
    def __init__(self):
        self.tracks = []
        self.next_id = 1
        self.max_missed = 8
    
    def iou(self, box1, box2):
        x1 = max(box1[0], box2[0])
        y1 = max(box1[1], box2[1])
        x2 = min(box1[2], box2[2])
        y2 = min(box1[3], box2[3])
        inter = max(0, x2 - x1) * max(0, y2 - y1)
        area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
        area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
        union = area1 + area2 - inter
        return inter / union if union > 0 else 0
    
    def update(self, detections):
        for t in self.tracks:
            t.age += 1
        
        if len(detections) == 0:
            for t in self.tracks:
                t.missed += 1
            self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
            return self.tracks
        
        if len(self.tracks) == 0:
            for det in detections:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
            return self.tracks
        
        matched_tracks = set()
        matched_dets = set()
        
        for j, det in enumerate(detections):
            best_iou = 0.25
            best_i = -1
            for i, track in enumerate(self.tracks):
                if i in matched_tracks:
                    continue
                iou_val = self.iou(track.bbox, det['bbox'])
                if iou_val > best_iou:
                    best_iou = iou_val
                    best_i = i
            
            if best_i >= 0:
                self.tracks[best_i].bbox = det['bbox']
                self.tracks[best_i].label = det['label']
                self.tracks[best_i].conf = det['conf']
                self.tracks[best_i].missed = 0
                matched_tracks.add(best_i)
                matched_dets.add(j)
        
        for i, track in enumerate(self.tracks):
            if i not in matched_tracks:
                track.missed += 1
        
        for j, det in enumerate(detections):
            if j not in matched_dets:
                self.tracks.append(Track(self.next_id, det['bbox'], det['label'], det['conf']))
                self.next_id += 1
        
        self.tracks = [t for t in self.tracks if t.missed < self.max_missed]
        return self.tracks

# ============================================
# COLLISION AVOIDANCE
# ============================================

class CollisionAvoidance:
    def __init__(self, frame_width, frame_height):
        self.frame_width = frame_width
        self.frame_height = frame_height
        
        center = frame_width // 2
        self.danger_left = center - 180
        self.danger_right = center + 180
        
        self.emergency_y = 420
        self.brake_y = 360
        self.slow_y = 300
        
    def check(self, tracks):
        closest_y = 0
        danger_track = None
        
        for track in tracks:
            if track.label not in ['vehicle', 'pedestrian']:
                continue
            
            x1, y1, x2, y2 = track.bbox
            center_x = (x1 + x2) // 2
            bottom_y = y2
            
            if self.danger_left < center_x < self.danger_right:
                if bottom_y > closest_y:
                    closest_y = bottom_y
                    danger_track = track
        
        if closest_y > self.emergency_y:
            return 'EMERGENCY', 0.0, 1.0, danger_track
        elif closest_y > self.brake_y:
            return 'BRAKE', 0.0, 0.8, danger_track
        elif closest_y > self.slow_y:
            return 'SLOW', 0.4, 0.0, danger_track
        else:
            return 'CLEAR', 1.0, 0.0, None

# ============================================
# METRICS
# ============================================

class Metrics:
    def __init__(self):
        self.fps_history = deque(maxlen=30)
        self.last_time = time.time()
        self.frame_count = 0
        self.start_time = time.time()
        self.cte_history = deque(maxlen=100)
        self.yolo_latency = deque(maxlen=30)
        self.brake_events = 0
    
    def update_fps(self):
        current_time = time.time()
        dt = current_time - self.last_time
        if dt > 0:
            self.fps_history.append(1.0 / dt)
        self.last_time = current_time
        self.frame_count += 1
    
    def get_fps(self):
        return np.mean(self.fps_history) if len(self.fps_history) > 0 else 0.0
    
    def get_runtime(self):
        return time.time() - self.start_time
    
    def get_avg_cte(self):
        return np.mean(np.abs(list(self.cte_history))) if len(self.cte_history) > 0 else 0.0
    
    def get_avg_yolo_latency(self):
        return np.mean(self.yolo_latency) * 1000 if len(self.yolo_latency) > 0 else 0.0

# ============================================
# DETECTION FILTER
# ============================================

def filter_detections(results, frame_width, frame_height):
    dets = results.pandas().xyxy[0]
    filtered = []
    
    for _, det in dets.iterrows():
        x1, y1 = int(det['xmin']), int(det['ymin'])
        x2, y2 = int(det['xmax']), int(det['ymax'])
        class_id = int(det['class'])
        conf = det['confidence']
        
        if class_id in COCO_VEHICLE_CLASSES:
            label = 'vehicle'
        elif class_id == COCO_PERSON_CLASS:
            label = 'pedestrian'
        elif class_id == COCO_TRAFFIC_LIGHT:
            label = 'traffic_light'
        elif class_id == COCO_STOP_SIGN:
            label = 'traffic_sign'
        else:
            continue
        
        box_width = x2 - x1
        box_height = y2 - y1
        box_area = box_width * box_height
        frame_area = frame_width * frame_height
        aspect_ratio = box_width / box_height if box_height > 0 else 0
        
        if conf < 0.5:
            continue
        if box_width < 25 or box_height < 25:
            continue
        if box_area > frame_area * 0.4:
            continue
        if label == 'vehicle' and y1 < frame_height * 0.2:
            continue
        if label == 'vehicle' and (aspect_ratio < 0.4 or aspect_ratio > 3.5):
            continue
        if label == 'pedestrian' and aspect_ratio > 0.9:
            continue
        
        filtered.append({
            'bbox': [x1, y1, x2, y2],
            'label': label,
            'conf': conf
        })
    
    return filtered

# ============================================
# VISUALIZATION
# ============================================

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
                            (loc.x, loc.y, center_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 100, 0))
        frame = cv2.addWeighted(frame, 0.75, overlay, 0.25, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 2)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 2)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 200, 200), 2)
    
    return frame

def draw_tracks(frame, tracks, danger_track):
    colors = {
        'vehicle': (0, 255, 0),
        'pedestrian': (0, 165, 255),
        'traffic_light': (0, 255, 255),
        'traffic_sign': (255, 0, 255)
    }
    
    for track in tracks:
        x1, y1, x2, y2 = track.bbox
        
        if danger_track and track.id == danger_track.id:
            color = (0, 0, 255)
            thickness = 3
        else:
            color = colors.get(track.label, (255, 255, 255))
            thickness = 2
        
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        label = "ID" + str(track.id) + " " + track.label[:6]
        cv2.putText(frame, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
    
    return frame

def draw_vla_hud(frame, metrics, speed, steer, cte, action, track_count, throttle, 
                 scene_desc, reasoning, action_explanation):
    h, w = frame.shape[:2]
    
    # Left panel - Vehicle State
    cv2.rectangle(frame, (5, 5), (200, 120), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (200, 120), (100, 100, 100), 1)
    
    cv2.putText(frame, "VLA DRIVING", (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (10, 55), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (10, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Objects: " + str(track_count), (10, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # Status
    if action == 'EMERGENCY':
        cv2.putText(frame, "EMERGENCY!", (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)
    elif action == 'BRAKE':
        cv2.putText(frame, "BRAKING", (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 100, 255), 1)
    elif action == 'SLOW':
        cv2.putText(frame, "SLOWING", (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 200, 255), 1)
    else:
        cv2.putText(frame, "CLEAR", (10, 115), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
    
    # Right panel - Metrics
    cv2.rectangle(frame, (w - 150, 5), (w - 5, 85), (0, 0, 0), -1)
    cv2.rectangle(frame, (w - 150, 5), (w - 5, 85), (100, 100, 100), 1)
    
    fps = metrics.get_fps()
    yolo_lat = metrics.get_avg_yolo_latency()
    
    cv2.putText(frame, "METRICS", (w - 145, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (w - 145, 38), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "YOLO: " + str(round(yolo_lat, 1)) + "ms", (w - 145, 53), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(metrics.get_avg_cte(), 3)), (w - 145, 68), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    cv2.putText(frame, "Brakes: " + str(metrics.brake_events), (w - 145, 83), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
    
    # Bottom panel - VLA Language Output
    cv2.rectangle(frame, (5, h - 95), (w - 5, h - 5), (30, 30, 30), -1)
    cv2.rectangle(frame, (5, h - 95), (w - 5, h - 5), (0, 255, 255), 1)
    
    cv2.putText(frame, "VISION-LANGUAGE-ACTION OUTPUT", (10, h - 78), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
    
    # Scene description (truncate if needed)
    scene_text = "Scene: " + scene_desc[:70]
    cv2.putText(frame, scene_text, (10, h - 60), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 200, 200), 1)
    
    # Reasoning (truncate if needed)
    reason_text = "Reason: " + reasoning[:75]
    cv2.putText(frame, reason_text, (10, h - 42), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200, 255, 200), 1)
    
    # Action explanation
    action_text = "Action: " + action_explanation[:70]
    cv2.putText(frame, action_text, (10, h - 24), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (255, 200, 200), 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

# ============================================
# MAIN
# ============================================

def main():
    global camera_image
    
    print("Loading YOLOv5s (COCO)...")
    model = torch.hub.load(yolo_path, 'yolov5s', source='local', pretrained=True)
    model.conf = 0.4
    print("Model loaded!")
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    
    print("Loading Town02...")
    world = client.load_world('Town02')
    time.sleep(2)
    world_map = world.get_map()
    print("Town02 loaded!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    ego_vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Ego vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=ego_vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Spawn NPCs
    print("Spawning NPCs...")
    npc_vehicles = []
    vehicle_bps = list(blueprint_library.filter('vehicle.*'))
    
    for i in range(1, min(12, len(spawn_points))):
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, spawn_points[i])
            v.set_autopilot(True)
            npc_vehicles.append(v)
        except:
            pass
    print("Spawned " + str(len(npc_vehicles)) + " vehicles")
    
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter('walker.pedestrian.*'))
    controller_bp = blueprint_library.find('controller.ai.walker')
    
    for i in range(8):
        loc = world.get_random_location_from_navigation()
        if loc:
            bp = random.choice(walker_bps)
            try:
                walker = world.spawn_actor(bp, carla.Transform(loc))
                walkers.append(walker)
                ctrl = world.spawn_actor(controller_bp, carla.Transform(), walker)
                controllers.append(ctrl)
                ctrl.start()
                ctrl.go_to_location(world.get_random_location_from_navigation())
                ctrl.set_max_speed(1.2)
            except:
                pass
    print("Spawned " + str(len(walkers)) + " pedestrians")
    
    # Initialize systems
    lane_keeper = LaneKeeper(ego_vehicle, world_map)
    steering_smoother = PerfectSteering()
    tracker = Tracker()
    collision_avoidance = CollisionAvoidance(800, 600)
    vla_reasoner = VLAReasoner()  # VLA Language Module
    metrics = Metrics()
    
    base_throttle = 0.30
    detect_interval = 2
    current_tracks = []
    
    print("")
    print("Waiting for camera...")
    for i in range(50):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            print("Camera ready!")
            break
    
    print("")
    print("========================================")
    print("VLA AUTONOMOUS DRIVING SYSTEM")
    print("========================================")
    print("Vision  : YOLOv5s (COCO) + Tracking")
    print("Language: Scene description + Reasoning")
    print("Action  : Pure Pursuit + Collision Avoid")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Print CoT")
    print("========================================")
    
    cv2.namedWindow('VLA Autonomous Driving', cv2.WINDOW_NORMAL)
    
    try:
        while True:
            world.tick()
            metrics.update_fps()
            
            if camera_image is not None:
                frame = camera_image.copy()
                h, w = frame.shape[:2]
                
                # === VISION: YOLO Detection ===
                if metrics.frame_count % detect_interval == 0:
                    yolo_start = time.time()
                    results = model(frame)
                    detections = filter_detections(results, w, h)
                    metrics.yolo_latency.append(time.time() - yolo_start)
                else:
                    detections = []
                
                # === VISION: Tracking ===
                if len(detections) > 0 or metrics.frame_count % detect_interval == 0:
                    current_tracks = tracker.update(detections)
                
                # === ACTION: Lane Keeping ===
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                waypoints = lane_keeper.get_waypoints()
                curvature = lane_keeper.calculate_curvature(waypoints)
                
                metrics.cte_history.append(cte)
                
                # === ACTION: Collision Avoidance ===
                speed = lane_keeper.get_speed_kmh()
                action, throttle_mult, brake, danger_track = collision_avoidance.check(current_tracks)
                
                if action in ['BRAKE', 'EMERGENCY']:
                    metrics.brake_events += 1
                
                # === LANGUAGE: Scene Analysis ===
                scene_desc = vla_reasoner.analyze_scene(current_tracks, speed, curvature)
                
                # === LANGUAGE: Reasoning ===
                reasoning = vla_reasoner.reason_action(action, danger_track, current_tracks, curvature)
                
                # === ACTION: Control ===
                final_throttle = base_throttle * throttle_mult
                
                if curvature > 0.08:
                    final_throttle *= 0.7
                elif curvature > 0.05:
                    final_throttle *= 0.85
                
                # === LANGUAGE: Action Explanation ===
                action_explanation = vla_reasoner.explain_action(action, steer, final_throttle, brake, danger_track)
                
                control = carla.VehicleControl()
                control.throttle = final_throttle
                control.steer = float(steer)
                control.brake = brake
                ego_vehicle.apply_control(control)
                
                # === VISUALIZATION ===
                frame = draw_lane(frame, ego_vehicle, waypoints)
                frame = draw_tracks(frame, current_tracks, danger_track)
                frame = draw_vla_hud(frame, metrics, speed, steer, cte, action, 
                                     len(current_tracks), final_throttle,
                                     scene_desc, reasoning, action_explanation)
                
                cv2.imshow('VLA Autonomous Driving', frame)
            
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.5, base_throttle + 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.15, base_throttle - 0.02)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('p'):
                # Print Chain of Thought
                cot = vla_reasoner.get_chain_of_thought()
                print("")
                print("=== CHAIN OF THOUGHT ===")
                print("Scene History:")
                for s in cot['scene']:
                    print("  - " + s)
                print("Current Reasoning: " + cot['reasoning'])
                print("Action: " + cot['action'])
                print("========================")
                
    finally:
        print("")
        print("=== FINAL STATS ===")
        print("Runtime: " + str(round(metrics.get_runtime(), 1)) + " s")
        print("Frames: " + str(metrics.frame_count))
        print("Avg FPS: " + str(round(metrics.get_fps(), 1)))
        print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
        print("Brake Events: " + str(metrics.brake_events))
        print("===================")
        
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        ego_vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        ego_vehicle.destroy()
        
        for c in controllers:
            try:
                c.stop()
                c.destroy()
            except:
                pass
        for w in walkers:
            try:
                w.destroy()
            except:
                pass
        for v in npc_vehicles:
            try:
                v.destroy()
            except:
                pass
        
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()