import sys
import time
import numpy as np
import cv2
import math
from collections import deque

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

class PerfectSteering:
    def __init__(self):
        self.history = deque(maxlen=10)
        self.prev_steer = 0.0
        self.smoothing_factor = 0.12
        self.max_rate = 0.03
        
    def smooth(self, raw_steer):
        self.history.append(raw_steer)
        if len(self.history) > 0:
            weights = np.linspace(0.5, 1.0, len(self.history))
            weighted_avg = np.average(list(self.history), weights=weights)
        else:
            weighted_avg = raw_steer
        smoothed = self.prev_steer + self.smoothing_factor * (weighted_avg - self.prev_steer)
        diff = smoothed - self.prev_steer
        if abs(diff) > self.max_rate:
            smoothed = self.prev_steer + self.max_rate * np.sign(diff)
        self.prev_steer = smoothed
        return smoothed

class LaneKeeper:
    def __init__(self, vehicle, world_map):
        self.vehicle = vehicle
        self.map = world_map
        self.wheelbase = 2.5
        self.base_lookahead = 5.0
        
    def get_speed(self):
        vel = self.vehicle.get_velocity()
        return math.sqrt(vel.x**2 + vel.y**2 + vel.z**2)
        
    def get_speed_kmh(self):
        return self.get_speed() * 3.6
    
    def get_adaptive_lookahead(self):
        speed = self.get_speed()
        lookahead = self.base_lookahead + speed * 0.3
        return max(3.0, min(10.0, lookahead))
    
    def get_waypoints(self, count=15, spacing=1.5):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return []
        waypoints = [current_wp]
        wp = current_wp
        for _ in range(count):
            next_wps = wp.next(spacing)
            if len(next_wps) == 0:
                break
            wp = next_wps[0]
            waypoints.append(wp)
        return waypoints
    
    def calculate_curvature(self, waypoints):
        if len(waypoints) < 3:
            return 0.0
        p1 = waypoints[0].transform.location
        p2 = waypoints[len(waypoints)//2].transform.location
        p3 = waypoints[-1].transform.location
        a = math.sqrt((p2.x - p1.x)**2 + (p2.y - p1.y)**2)
        b = math.sqrt((p3.x - p2.x)**2 + (p3.y - p2.y)**2)
        c = math.sqrt((p3.x - p1.x)**2 + (p3.y - p1.y)**2)
        s = (a + b + c) / 2
        area_sq = s * (s - a) * (s - b) * (s - c)
        if area_sq <= 0 or a * b * c == 0:
            return 0.0
        return 4 * math.sqrt(area_sq) / (a * b * c)
    
    def get_cross_track_error(self):
        location = self.vehicle.get_location()
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0
        wp_loc = current_wp.transform.location
        wp_yaw = math.radians(current_wp.transform.rotation.yaw)
        dx = location.x - wp_loc.x
        dy = location.y - wp_loc.y
        cte = dx * math.sin(wp_yaw) - dy * math.cos(wp_yaw)
        return cte
    
    def get_steering(self):
        transform = self.vehicle.get_transform()
        location = transform.location
        yaw = math.radians(transform.rotation.yaw)
        
        current_wp = self.map.get_waypoint(location, project_to_road=True)
        if current_wp is None:
            return 0.0, 0.0, False
        
        lookahead = self.get_adaptive_lookahead()
        
        target_wp = current_wp
        remaining = lookahead
        while remaining > 0:
            next_wps = target_wp.next(min(remaining, 2.0))
            if len(next_wps) == 0:
                break
            target_wp = next_wps[0]
            remaining -= 2.0
        
        target_loc = target_wp.transform.location
        dx = target_loc.x - location.x
        dy = target_loc.y - location.y
        
        local_x = dx * math.cos(yaw) + dy * math.sin(yaw)
        local_y = -dx * math.sin(yaw) + dy * math.cos(yaw)
        
        ld_sq = local_x**2 + local_y**2
        if ld_sq < 0.1:
            return 0.0, 0.0, True
        
        # Pure Pursuit steering calculation
        steering = math.atan2(2.0 * self.wheelbase * local_y, ld_sq)
        steering = max(-1.0, min(1.0, steering / math.radians(70)))
        
        cte = self.get_cross_track_error()
        
        return steering, cte, True

class Metrics:
    def __init__(self):
        self.fps_history = deque(maxlen=30)
        self.last_time = time.time()
        self.frame_count = 0
        self.start_time = time.time()
        self.cte_history = deque(maxlen=100)
        self.steering_history = deque(maxlen=100)
    
    def update_fps(self):
        current_time = time.time()
        dt = current_time - self.last_time
        if dt > 0:
            self.fps_history.append(1.0 / dt)
        self.last_time = current_time
        self.frame_count += 1
    
    def get_fps(self):
        return np.mean(self.fps_history) if len(self.fps_history) > 0 else 0.0
    
    def get_runtime(self):
        return time.time() - self.start_time
    
    def get_avg_cte(self):
        return np.mean(np.abs(list(self.cte_history))) if len(self.cte_history) > 0 else 0.0
    
    def get_steering_smoothness(self):
        if len(self.steering_history) < 2:
            return 0.0
        steers = list(self.steering_history)
        diffs = [abs(steers[i] - steers[i-1]) for i in range(1, len(steers))]
        return np.mean(diffs)

def draw_lane(frame, vehicle, waypoints):
    if len(waypoints) < 2:
        return frame
    
    h, w = frame.shape[:2]
    f = w / (2 * math.tan(math.radians(45)))
    
    transform = vehicle.get_transform()
    vx, vy, vz = transform.location.x, transform.location.y, transform.location.z
    vyaw = math.radians(-transform.rotation.yaw)
    
    left_pts, right_pts, center_pts = [], [], []
    
    for wp in waypoints:
        loc = wp.transform.location
        wyaw = math.radians(wp.transform.rotation.yaw)
        hw = wp.lane_width / 2 * 0.9
        
        for px, py, pts in [(loc.x - hw * math.sin(wyaw), loc.y + hw * math.cos(wyaw), left_pts),
                            (loc.x + hw * math.sin(wyaw), loc.y - hw * math.cos(wyaw), right_pts),
                            (loc.x, loc.y, center_pts)]:
            dx, dy, dz = px - vx, py - vy, loc.z - vz
            lx = dx * math.cos(vyaw) - dy * math.sin(vyaw) - 2.0
            ly = dx * math.sin(vyaw) + dy * math.cos(vyaw)
            lz = dz - 1.4
            
            if lx > 0.5:
                u = int(w/2 - f * ly / lx)
                v = int(h/2 - f * lz / lx)
                if 0 <= u < w and 0 <= v < h:
                    pts.append((u, v))
    
    if len(left_pts) > 2 and len(right_pts) > 2:
        overlay = frame.copy()
        pts = np.array(left_pts + right_pts[::-1], np.int32)
        cv2.fillPoly(overlay, [pts], (0, 120, 0))
        frame = cv2.addWeighted(frame, 0.7, overlay, 0.3, 0)
    
    for i in range(1, len(left_pts)):
        cv2.line(frame, left_pts[i-1], left_pts[i], (255, 50, 50), 3)
    for i in range(1, len(right_pts)):
        cv2.line(frame, right_pts[i-1], right_pts[i], (50, 50, 255), 3)
    for i in range(1, len(center_pts), 2):
        if i < len(center_pts):
            cv2.line(frame, center_pts[i-1], center_pts[i], (0, 220, 220), 2)
    
    return frame

def draw_hud(frame, metrics, speed, steer, cte, curvature, throttle):
    h, w = frame.shape[:2]
    
    # Left panel
    cv2.rectangle(frame, (5, 5), (200, 120), (0, 0, 0), -1)
    cv2.rectangle(frame, (5, 5), (200, 120), (100, 100, 100), 1)
    
    cv2.putText(frame, "LANE KEEPING", (15, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
    cv2.putText(frame, "Speed: " + str(round(speed, 1)) + " km/h", (15, 48), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Throttle: " + str(round(throttle, 2)), (15, 66), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Steer: " + str(round(steer, 3)), (15, 84), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "CTE: " + str(round(cte, 2)) + " m", (15, 102), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Curv: " + str(round(curvature, 4)), (15, 118), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
    
    # Right panel - Metrics
    cv2.rectangle(frame, (w - 160, 5), (w - 5, 100), (0, 0, 0), -1)
    cv2.rectangle(frame, (w - 160, 5), (w - 5, 100), (100, 100, 100), 1)
    
    fps = metrics.get_fps()
    avg_cte = metrics.get_avg_cte()
    smoothness = metrics.get_steering_smoothness()
    
    cv2.putText(frame, "METRICS", (w - 150, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
    cv2.putText(frame, "FPS: " + str(round(fps, 1)), (w - 150, 42), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Avg CTE: " + str(round(avg_cte, 3)) + " m", (w - 150, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Smooth: " + str(round(smoothness, 4)), (w - 150, 78), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    cv2.putText(frame, "Frames: " + str(metrics.frame_count), (w - 150, 96), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)
    
    # Runtime
    mins = int(metrics.get_runtime() // 60)
    secs = int(metrics.get_runtime() % 60)
    cv2.putText(frame, "Time: " + str(mins) + "m " + str(secs) + "s", (10, h - 15), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
    
    return frame

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.load_world("Town04")
    world_map = world.get_map()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '800')
    camera_bp.set_attribute('image_size_y', '600')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    lane_keeper = LaneKeeper(vehicle, world_map)
    steering_smoother = PerfectSteering()
    metrics = Metrics()
    
    throttle = 0.28
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("LANE KEEPING SYSTEM")
    print("========================================")
    print("Q - Quit | W/S - Speed | P - Print stats")
    print("========================================")
    
    try:
        while True:
            world.tick()
            metrics.update_fps()
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                waypoints = lane_keeper.get_waypoints()
                raw_steer, cte, valid = lane_keeper.get_steering()
                steer = steering_smoother.smooth(raw_steer) if valid else 0.0
                curvature = lane_keeper.calculate_curvature(waypoints)
                
                metrics.cte_history.append(cte)
                metrics.steering_history.append(steer)
                
                # Slow down for curves
                current_throttle = throttle
                if curvature > 0.08:
                    current_throttle = throttle * 0.7
                elif curvature > 0.05:
                    current_throttle = throttle * 0.85
                
                control = carla.VehicleControl()
                control.throttle = current_throttle
                control.steer = float(steer)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                speed = lane_keeper.get_speed_kmh()
                
                frame = draw_lane(frame, vehicle, waypoints)
                frame = draw_hud(frame, metrics, speed, steer, cte, curvature, current_throttle)
                
                cv2.imshow('Lane Keeping', frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                throttle = min(0.5, throttle + 0.02)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('s'):
                throttle = max(0.15, throttle - 0.02)
                print("Throttle: " + str(round(throttle, 2)))
            elif key == ord('p'):
                print("")
                print("=== STATS ===")
                print("FPS: " + str(round(metrics.get_fps(), 1)))
                print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
                print("Steering Smoothness: " + str(round(metrics.get_steering_smoothness(), 4)))
                print("=============")
                
    finally:
        print("")
        print("=== FINAL STATS ===")
        print("Runtime: " + str(round(metrics.get_runtime(), 1)) + " s")
        print("Frames: " + str(metrics.frame_count))
        print("Avg FPS: " + str(round(metrics.get_fps(), 1)))
        print("Avg CTE: " + str(round(metrics.get_avg_cte(), 3)) + " m")
        print("Steering Smoothness: " + str(round(metrics.get_steering_smoothness(), 4)))
        print("===================")
        
        print("Cleaning up...")
        control = carla.VehicleControl()
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.3)
        
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()