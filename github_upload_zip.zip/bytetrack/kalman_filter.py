# -*- coding: utf-8 -*-
import numpy as np
from filterpy.kalman import KalmanFilter


def tlwh_to_xyah(tlwh):
    x, y, w, h = tlwh
    cx = x + w / 2.0
    cy = y + h / 2.0
    a = w / (h + 1e-6)
    return np.array([cx, cy, a, h], dtype=np.float32)


def xyah_to_tlwh(xyah):
    cx, cy, a, h = xyah
    w = a * h
    x = cx - w / 2.0
    y = cy - h / 2.0
    return np.array([x, y, w, h], dtype=np.float32)


class KalmanFilterXYAH:
    def __init__(self):
        # state: (cx, cy, a, h, vx, vy, va, vh)
        self.kf = KalmanFilter(dim_x=8, dim_z=4)

        self.kf.F = np.eye(8, dtype=np.float32)
        for i in range(4):
            self.kf.F[i, i + 4] = 1.0

        self.kf.H = np.zeros((4, 8), dtype=np.float32)
        self.kf.H[0, 0] = 1.0
        self.kf.H[1, 1] = 1.0
        self.kf.H[2, 2] = 1.0
        self.kf.H[3, 3] = 1.0

        self.kf.P *= 10.0
        self.kf.R *= 1.0
        self.kf.Q *= 0.01

    def initiate(self, tlwh):
        mean = np.zeros(8, dtype=np.float32)
        mean[:4] = tlwh_to_xyah(tlwh)
        cov = self.kf.P.copy()
        return mean, cov

    def predict(self, mean, cov):
        self.kf.x = mean.reshape(-1, 1)
        self.kf.P = cov
        self.kf.predict()
        return self.kf.x.flatten(), self.kf.P

    def update(self, mean, cov, tlwh):
        z = tlwh_to_xyah(tlwh).reshape(-1, 1)
        self.kf.x = mean.reshape(-1, 1)
        self.kf.P = cov
        self.kf.update(z)
        return self.kf.x.flatten(), self.kf.P