# -*- coding: utf-8 -*-
import numpy as np

try:
    import lap
    _HAVE_LAP = True
except Exception:
    _HAVE_LAP = False


def iou_distance(tracks_tlbr, dets_tlbr):
    if len(tracks_tlbr) == 0 or len(dets_tlbr) == 0:
        return np.empty((len(tracks_tlbr), len(dets_tlbr)), dtype=np.float32)

    cost = np.zeros((len(tracks_tlbr), len(dets_tlbr)), dtype=np.float32)
    for i, tb in enumerate(tracks_tlbr):
        tx1, ty1, tx2, ty2 = tb
        ta = max(0, tx2 - tx1) * max(0, ty2 - ty1)
        for j, db in enumerate(dets_tlbr):
            dx1, dy1, dx2, dy2 = db
            da = max(0, dx2 - dx1) * max(0, dy2 - dy1)
            ix1 = max(tx1, dx1)
            iy1 = max(ty1, dy1)
            ix2 = min(tx2, dx2)
            iy2 = min(ty2, dy2)
            inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
            union = ta + da - inter + 1e-6
            iou = inter / union
            cost[i, j] = 1.0 - iou
    return cost


def linear_assignment(cost_matrix, thresh):
    if cost_matrix.size == 0:
        return [], list(range(cost_matrix.shape[0])), list(range(cost_matrix.shape[1]))

    if _HAVE_LAP:
        _, x, y = lap.lapjv(cost_matrix, extend_cost=True, cost_limit=thresh)
        matches = [(i, xi) for i, xi in enumerate(x) if xi >= 0]
        unmatched_a = [i for i, xi in enumerate(x) if xi < 0]
        unmatched_b = [j for j, yj in enumerate(y) if yj < 0]
        return matches, unmatched_a, unmatched_b

    # fallback: scipy hungarian
    from scipy.optimize import linear_sum_assignment
    r, c = linear_sum_assignment(cost_matrix)
    matches = []
    unmatched_a = list(range(cost_matrix.shape[0]))
    unmatched_b = list(range(cost_matrix.shape[1]))
    for i, j in zip(r, c):
        if cost_matrix[i, j] <= thresh:
            matches.append((i, j))
            unmatched_a.remove(i)
            unmatched_b.remove(j)
    return matches, unmatched_a, unmatched_b