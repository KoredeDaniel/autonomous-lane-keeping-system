# -*- coding: utf-8 -*-

class TrackState:
    New = 0
    Tracked = 1
    Lost = 2
    Removed = 3


class BaseTrack:
    _count = 0

    def __init__(self):
        self.track_id = 0
        self.state = TrackState.New

    @staticmethod
    def next_id():
        BaseTrack._count += 1
        return BaseTrack._count