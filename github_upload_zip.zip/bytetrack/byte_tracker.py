# -*- coding: utf-8 -*-
"""
Lightweight ByteTrack-style tracker (no external deps).
- Two-threshold association: high-confidence updates + low-confidence recovery
- IoU-based matching
- Track aging and removal

This is a simplified ByteTrack variant suitable for CARLA real-time demos.
"""

import numpy as np

def iou_xyxy(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    iw = max(0.0, ix2 - ix1)
    ih = max(0.0, iy2 - iy1)
    inter = iw * ih
    if inter <= 0:
        return 0.0
    area_a = max(0.0, (ax2 - ax1)) * max(0.0, (ay2 - ay1))
    area_b = max(0.0, (bx2 - bx1)) * max(0.0, (by2 - by1))
    union = area_a + area_b - inter + 1e-6
    return float(inter / union)

class Track:
    __slots__ = ["track_id", "bbox", "score", "cls", "age", "time_since_update", "hits"]

    def __init__(self, track_id, bbox, score, cls):
        self.track_id = track_id
        self.bbox = bbox  # [x1,y1,x2,y2]
        self.score = score
        self.cls = cls    # int class id
        self.age = 0
        self.time_since_update = 0
        self.hits = 1

class BYTETracker:
    """
    detections input: Nx6 array [x1,y1,x2,y2,score,cls]
    output: list of Track objects
    """
    def __init__(
        self,
        track_thresh=0.45,      # high conf threshold
        low_thresh=0.15,        # low conf threshold for recovery association
        match_thresh=0.30,      # IoU threshold
        max_time_lost=30        # frames
    ):
        self.track_thresh = float(track_thresh)
        self.low_thresh = float(low_thresh)
        self.match_thresh = float(match_thresh)
        self.max_time_lost = int(max_time_lost)

        self.tracks = []
        self.next_id = 1

    def _greedy_match(self, tracks, dets, iou_thresh):
        """
        Greedy matching by highest IoU first.
        Returns:
            matches: list of (t_idx, d_idx)
            unmatched_t: list
            unmatched_d: list
        """
        if len(tracks) == 0 or len(dets) == 0:
            return [], list(range(len(tracks))), list(range(len(dets)))

        pairs = []
        for ti, t in enumerate(tracks):
            tb = t.bbox
            for di, d in enumerate(dets):
                db = d[:4]
                s = iou_xyxy(tb, db)
                if s >= iou_thresh:
                    pairs.append((s, ti, di))

        pairs.sort(reverse=True, key=lambda x: x[0])
        used_t = set()
        used_d = set()
        matches = []
        for s, ti, di in pairs:
            if ti in used_t or di in used_d:
                continue
            used_t.add(ti)
            used_d.add(di)
            matches.append((ti, di))

        unmatched_t = [i for i in range(len(tracks)) if i not in used_t]
        unmatched_d = [i for i in range(len(dets)) if i not in used_d]
        return matches, unmatched_t, unmatched_d

    def update(self, detections):
        """
        detections: np.ndarray shape (N,6) float32/float64
        """
        # age tracks
        for t in self.tracks:
            t.age += 1
            t.time_since_update += 1

        if detections is None:
            detections = np.zeros((0, 6), dtype=np.float32)

        if len(detections) == 0:
            # remove lost tracks
            self.tracks = [t for t in self.tracks if t.time_since_update <= self.max_time_lost]
            return self.tracks

        dets = detections.astype(np.float32)

        high = dets[dets[:, 4] >= self.track_thresh]
        low  = dets[(dets[:, 4] >= self.low_thresh) & (dets[:, 4] < self.track_thresh)]

        # --- First association with HIGH dets
        matches, un_t, un_d = self._greedy_match(self.tracks, high, self.match_thresh)

        for ti, di in matches:
            d = high[di]
            t = self.tracks[ti]
            t.bbox = d[:4].tolist()
            t.score = float(d[4])
            t.cls = int(d[5])
            t.time_since_update = 0
            t.hits += 1

        # --- Second association: unmatched tracks with LOW dets (ByteTrack idea)
        if len(low) > 0 and len(un_t) > 0:
            tracks_unmatched = [self.tracks[i] for i in un_t]
            matches2, un_t2, un_d2 = self._greedy_match(tracks_unmatched, low, self.match_thresh)

            # map back to original track indices
            for local_ti, di in matches2:
                t = tracks_unmatched[local_ti]
                d = low[di]
                t.bbox = d[:4].tolist()
                t.score = float(d[4])
                t.cls = int(d[5])
                t.time_since_update = 0
                t.hits += 1

        # --- Create new tracks from unmatched HIGH dets
        matched_high_det_indices = set([di for _, di in matches])
        for di in range(len(high)):
            if di in matched_high_det_indices:
                continue
            d = high[di]
            self.tracks.append(Track(self.next_id, d[:4].tolist(), float(d[4]), int(d[5])))
            self.next_id += 1

        # --- Remove long-lost tracks
        self.tracks = [t for t in self.tracks if t.time_since_update <= self.max_time_lost]
        return self.tracks