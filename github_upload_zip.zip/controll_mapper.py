# -*- coding: utf-8 -*-
import numpy as np


class SpeedController:
    def __init__(self):
        self.kp_th = 0.03
        self.kp_br = 0.05
        self.throttle_limit = 0.55

    def compute(self, current_kmh: float, target_kmh: float):
        err = float(target_kmh - current_kmh)

        if target_kmh <= 0.1:
            return 0.0, 0.85

        if err >= 0:
            throttle = np.clip(self.kp_th * err, 0.0, self.throttle_limit)
            brake = 0.0
        else:
            throttle = 0.0
            brake = np.clip(self.kp_br * (-err), 0.0, 0.85)

        return float(throttle), float(brake)