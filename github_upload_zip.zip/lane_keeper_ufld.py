import sys
import os
import time
import numpy as np
import cv2
import torch
import torch.nn as nn

carla_egg = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
sys.path.append(carla_egg)

import carla

camera_image = None

# Ultra-Fast Lane Detection Model Definition
class Conv2dBnRelu(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=3, stride=1, padding=1):
        super(Conv2dBnRelu, self).__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, kernel_size, stride, padding, bias=False)
        self.bn = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)
    
    def forward(self, x):
        return self.relu(self.bn(self.conv(x)))

class ResBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super(ResBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_ch, out_ch, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_ch)
        self.conv2 = nn.Conv2d(out_ch, out_ch, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        
        self.downsample = None
        if stride != 1 or in_ch != out_ch:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 1, stride, bias=False),
                nn.BatchNorm2d(out_ch)
            )
    
    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        out += identity
        return self.relu(out)

class SimpleLaneNet(nn.Module):
    def __init__(self, num_lanes=4, num_points=56):
        super(SimpleLaneNet, self).__init__()
        self.num_lanes = num_lanes
        self.num_points = num_points
        
        # Simple encoder
        self.layer1 = nn.Sequential(
            Conv2dBnRelu(3, 64, 7, 2, 3),
            nn.MaxPool2d(3, 2, 1)
        )
        self.layer2 = nn.Sequential(
            ResBlock(64, 64),
            ResBlock(64, 64)
        )
        self.layer3 = nn.Sequential(
            ResBlock(64, 128, 2),
            ResBlock(128, 128)
        )
        self.layer4 = nn.Sequential(
            ResBlock(128, 256, 2),
            ResBlock(256, 256)
        )
        self.layer5 = nn.Sequential(
            ResBlock(256, 512, 2),
            ResBlock(512, 512)
        )
        
        self.pool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_lanes * num_points)
    
    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = self.pool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x.view(-1, self.num_lanes, self.num_points)

class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0
        self.integral = 0
    
    def compute(self, error, dt):
        self.integral += error * dt
        self.integral = max(-0.5, min(0.5, self.integral))
        derivative = (error - self.prev_error) / dt if dt > 0 else 0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output
    
    def reset(self):
        self.prev_error = 0
        self.integral = 0

class SlidingWindowLaneDetector:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.left_fit = None
        self.right_fit = None
        self.n_windows = 9
        self.margin = 50
        self.minpix = 30
    
    def preprocess(self, frame):
        # Convert to HLS and extract L and S channels
        hls = cv2.cvtColor(frame, cv2.COLOR_BGR2HLS)
        l_channel = hls[:, :, 1]
        s_channel = hls[:, :, 2]
        
        # Threshold L channel for white lanes
        l_binary = np.zeros_like(l_channel)
        l_binary[(l_channel >= 200)] = 1
        
        # Threshold S channel for yellow lanes
        s_binary = np.zeros_like(s_channel)
        s_binary[(s_channel >= 100) & (s_channel <= 255)] = 1
        
        # Combine
        combined = np.zeros_like(l_channel)
        combined[(l_binary == 1) | (s_binary == 1)] = 1
        
        # Apply Sobel for edge detection
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        sobelx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        abs_sobelx = np.absolute(sobelx)
        scaled_sobel = np.uint8(255 * abs_sobelx / np.max(abs_sobelx)) if np.max(abs_sobelx) > 0 else np.zeros_like(abs_sobelx, dtype=np.uint8)
        
        sobel_binary = np.zeros_like(scaled_sobel)
        sobel_binary[(scaled_sobel >= 30) & (scaled_sobel <= 150)] = 1
        
        # Final combination
        final = np.zeros_like(combined)
        final[(combined == 1) | (sobel_binary == 1)] = 1
        
        return final
    
    def perspective_transform(self, img):
        height, width = img.shape[:2]
        
        # Source points (trapezoid on road)
        src = np.float32([
            [width * 0.15, height],
            [width * 0.45, height * 0.6],
            [width * 0.55, height * 0.6],
            [width * 0.85, height]
        ])
        
        # Destination points (rectangle)
        dst = np.float32([
            [width * 0.2, height],
            [width * 0.2, 0],
            [width * 0.8, 0],
            [width * 0.8, height]
        ])
        
        M = cv2.getPerspectiveTransform(src, dst)
        Minv = cv2.getPerspectiveTransform(dst, src)
        
        warped = cv2.warpPerspective(img, M, (width, height))
        
        return warped, M, Minv
    
    def find_lane_pixels(self, binary_warped):
        # Histogram of bottom half
        histogram = np.sum(binary_warped[binary_warped.shape[0]//2:, :], axis=0)
        
        midpoint = len(histogram) // 2
        leftx_base = np.argmax(histogram[:midpoint])
        rightx_base = np.argmax(histogram[midpoint:]) + midpoint
        
        # Sliding windows
        window_height = binary_warped.shape[0] // self.n_windows
        
        nonzero = binary_warped.nonzero()
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        
        leftx_current = leftx_base
        rightx_current = rightx_base
        
        left_lane_inds = []
        right_lane_inds = []
        
        for window in range(self.n_windows):
            win_y_low = binary_warped.shape[0] - (window + 1) * window_height
            win_y_high = binary_warped.shape[0] - window * window_height
            
            win_xleft_low = leftx_current - self.margin
            win_xleft_high = leftx_current + self.margin
            win_xright_low = rightx_current - self.margin
            win_xright_high = rightx_current + self.margin
            
            good_left_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                              (nonzerox >= win_xleft_low) & (nonzerox < win_xleft_high)).nonzero()[0]
            good_right_inds = ((nonzeroy >= win_y_low) & (nonzeroy < win_y_high) &
                               (nonzerox >= win_xright_low) & (nonzerox < win_xright_high)).nonzero()[0]
            
            left_lane_inds.append(good_left_inds)
            right_lane_inds.append(good_right_inds)
            
            if len(good_left_inds) > self.minpix:
                leftx_current = int(np.mean(nonzerox[good_left_inds]))
            if len(good_right_inds) > self.minpix:
                rightx_current = int(np.mean(nonzerox[good_right_inds]))
        
        left_lane_inds = np.concatenate(left_lane_inds) if left_lane_inds else np.array([])
        right_lane_inds = np.concatenate(right_lane_inds) if right_lane_inds else np.array([])
        
        leftx = nonzerox[left_lane_inds] if len(left_lane_inds) > 0 else np.array([])
        lefty = nonzeroy[left_lane_inds] if len(left_lane_inds) > 0 else np.array([])
        rightx = nonzerox[right_lane_inds] if len(right_lane_inds) > 0 else np.array([])
        righty = nonzeroy[right_lane_inds] if len(right_lane_inds) > 0 else np.array([])
        
        return leftx, lefty, rightx, righty
    
    def fit_polynomial(self, binary_warped, leftx, lefty, rightx, righty):
        left_fit = None
        right_fit = None
        
        if len(leftx) > 100:
            try:
                left_fit = np.polyfit(lefty, leftx, 2)
                self.left_fit = left_fit
            except:
                left_fit = self.left_fit
        else:
            left_fit = self.left_fit
        
        if len(rightx) > 100:
            try:
                right_fit = np.polyfit(righty, rightx, 2)
                self.right_fit = right_fit
            except:
                right_fit = self.right_fit
        else:
            right_fit = self.right_fit
        
        return left_fit, right_fit
    
    def calculate_offset(self, left_fit, right_fit, img_width, img_height):
        if left_fit is None and right_fit is None:
            return 0, False
        
        y_eval = img_height - 1
        car_center = img_width / 2
        
        if left_fit is not None and right_fit is not None:
            left_x = left_fit[0] * y_eval**2 + left_fit[1] * y_eval + left_fit[2]
            right_x = right_fit[0] * y_eval**2 + right_fit[1] * y_eval + right_fit[2]
            lane_center = (left_x + right_x) / 2
        elif left_fit is not None:
            left_x = left_fit[0] * y_eval**2 + left_fit[1] * y_eval + left_fit[2]
            lane_center = left_x + 200
        else:
            right_x = right_fit[0] * y_eval**2 + right_fit[1] * y_eval + right_fit[2]
            lane_center = right_x - 200
        
        offset = (lane_center - car_center) / (img_width / 2)
        return offset, True
    
    def draw_lanes(self, original, binary_warped, left_fit, right_fit, Minv):
        if left_fit is None and right_fit is None:
            return original
        
        warp_zero = np.zeros_like(binary_warped).astype(np.uint8)
        color_warp = np.dstack((warp_zero, warp_zero, warp_zero))
        
        ploty = np.linspace(0, binary_warped.shape[0] - 1, binary_warped.shape[0])
        
        pts_left = None
        pts_right = None
        
        if left_fit is not None:
            left_fitx = left_fit[0] * ploty**2 + left_fit[1] * ploty + left_fit[2]
            pts_left = np.array([np.transpose(np.vstack([left_fitx, ploty]))])
        
        if right_fit is not None:
            right_fitx = right_fit[0] * ploty**2 + right_fit[1] * ploty + right_fit[2]
            pts_right = np.array([np.flipud(np.transpose(np.vstack([right_fitx, ploty])))])
        
        # Draw lane area
        if pts_left is not None and pts_right is not None:
            pts = np.hstack((pts_left, pts_right))
            cv2.fillPoly(color_warp, np.int_([pts]), (0, 255, 0))
        
        # Draw lane lines
        if pts_left is not None:
            cv2.polylines(color_warp, np.int_([pts_left]), False, (255, 0, 0), 20)
        if pts_right is not None:
            cv2.polylines(color_warp, np.int_([pts_right]), False, (0, 0, 255), 20)
        
        # Warp back to original perspective
        newwarp = cv2.warpPerspective(color_warp, Minv, (original.shape[1], original.shape[0]))
        result = cv2.addWeighted(original, 1, newwarp, 0.3, 0)
        
        return result
    
    def process(self, frame):
        # Preprocess
        binary = self.preprocess(frame)
        
        # Perspective transform
        binary_warped, M, Minv = self.perspective_transform(binary)
        
        # Find lane pixels
        leftx, lefty, rightx, righty = self.find_lane_pixels(binary_warped)
        
        # Fit polynomial
        left_fit, right_fit = self.fit_polynomial(binary_warped, leftx, lefty, rightx, righty)
        
        # Calculate offset
        offset, detected = self.calculate_offset(left_fit, right_fit, frame.shape[1], frame.shape[0])
        
        # Draw lanes
        result = self.draw_lanes(frame, binary_warped, left_fit, right_fit, Minv)
        
        return result, offset, detected, binary_warped

def process_image(image):
    global camera_image
    array = np.frombuffer(image.raw_data, dtype=np.uint8)
    array = array.reshape((image.height, image.width, 4))
    camera_image = array[:, :, :3].copy()

def main():
    global camera_image
    
    print("Connecting to CARLA...")
    client = carla.Client('localhost', 2000)
    client.set_timeout(10.0)
    world = client.get_world()
    print("Connected!")
    
    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()
    
    # Spawn vehicle
    vehicle_bp = blueprint_library.filter('vehicle.tesla.model3')[0]
    vehicle = world.spawn_actor(vehicle_bp, spawn_points[0])
    print("Vehicle spawned!")
    
    # Camera
    camera_bp = blueprint_library.find('sensor.camera.rgb')
    camera_bp.set_attribute('image_size_x', '640')
    camera_bp.set_attribute('image_size_y', '480')
    camera_bp.set_attribute('fov', '90')
    
    camera_transform = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(camera_bp, camera_transform, attach_to=vehicle)
    camera.listen(lambda img: process_image(img))
    print("Camera attached!")
    
    # Initialize
    lane_detector = SlidingWindowLaneDetector(640, 480)
    steering_pid = PIDController(kp=1.0, ki=0.01, kd=0.3)
    
    base_throttle = 0.35
    show_debug = True
    
    print("")
    print("Waiting for camera...")
    for i in range(30):
        time.sleep(0.1)
        world.tick()
        if camera_image is not None:
            break
    
    print("")
    print("========================================")
    print("ADVANCED LANE KEEPING (Sliding Window)")
    print("========================================")
    print("Controls:")
    print("  Q - Quit")
    print("  W/S - Speed up/down")
    print("  D - Toggle debug")
    print("========================================")
    print("")
    
    last_time = time.time()
    
    try:
        while True:
            world.tick()
            current_time = time.time()
            dt = current_time - last_time
            if dt < 0.01:
                dt = 0.01
            last_time = current_time
            
            if camera_image is not None:
                frame = camera_image.copy()
                
                # Process frame
                display, offset, detected, binary_warped = lane_detector.process(frame)
                
                # PID steering
                if detected:
                    steering = steering_pid.compute(-offset, dt)
                    steering = max(-1.0, min(1.0, steering))
                else:
                    steering = 0.0
                    steering_pid.reset()
                
                # Apply control
                control = carla.VehicleControl()
                control.throttle = base_throttle
                control.steer = float(steering)
                control.brake = 0.0
                vehicle.apply_control(control)
                
                # Info
                status = "LANE DETECTED" if detected else "SEARCHING..."
                color = (0, 255, 0) if detected else (0, 165, 255)
                cv2.putText(display, status, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                cv2.putText(display, "Offset: " + str(round(offset, 3)), (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(display, "Steer: " + str(round(steering, 3)), (10, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                cv2.putText(display, "Speed: " + str(round(base_throttle, 2)), (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
                
                # Steering indicator
                center = 320
                steer_x = center + int(steering * 100)
                cv2.arrowedLine(display, (center, 450), (steer_x, 450), (0, 255, 255), 3)
                
                cv2.imshow('Lane Keeping', display)
                
                if show_debug:
                    debug = cv2.cvtColor((binary_warped * 255).astype(np.uint8), cv2.COLOR_GRAY2BGR)
                    cv2.imshow('Bird Eye View', debug)
            
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('w'):
                base_throttle = min(0.7, base_throttle + 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('s'):
                base_throttle = max(0.1, base_throttle - 0.05)
                print("Throttle: " + str(round(base_throttle, 2)))
            elif key == ord('d'):
                show_debug = not show_debug
                if not show_debug:
                    cv2.destroyWindow('Bird Eye View')
                
    finally:
        print("Stopping...")
        control = carla.VehicleControl()
        control.throttle = 0.0
        control.brake = 1.0
        vehicle.apply_control(control)
        time.sleep(0.5)
        
        print("Cleaning up...")
        camera.stop()
        camera.destroy()
        vehicle.destroy()
        cv2.destroyAllWindows()
        print("Done!")

if __name__ == "__main__":
    main()