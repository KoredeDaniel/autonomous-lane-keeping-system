# -*- coding: utf-8 -*-
"""
CARLA -> YOLO dataset collector (CARLA 0.9.9 / Python 3.7)

Exports YOLO-format labels for 4 classes:
0 vehicle
1 pedestrian
2 traffic_light
3 traffic_sign

Output:
  carla_dataset/
    images/
    labels/
    debug/   (optional overlay images)

Run (from yolov5 folder):
  py -3.7 carla_collect_yolo.py
"""

import os
import sys
import time
import math
import random
import traceback
from pathlib import Path

import numpy as np
import cv2

# ---------------------------
# CONFIG (edit if needed)
# ---------------------------
CARLA_EGG = r"C:\Users\CARLACODES\1_code\carla-0.9.9-py3.7-win-amd64.egg"
if CARLA_EGG not in sys.path:
    sys.path.append(CARLA_EGG)

import carla  # noqa: E402

OUT_ROOT = Path("carla_dataset")
IMG_DIR = OUT_ROOT / "images"
LAB_DIR = OUT_ROOT / "labels"
DBG_DIR = OUT_ROOT / "debug"

SAVE_DEBUG_OVERLAYS = True
DEBUG_EVERY_N = 50

N_FRAMES = 2000
FIXED_DT = 0.05
TOWN = "Town02"

IMG_W = 640
IMG_H = 480
FOV = 90.0

N_NPC_VEHICLES = 20
N_WALKERS = 15

MIN_DEPTH = 1.0
MAX_DEPTH = 60.0
MIN_BOX_PX = 10
MAX_AREA_FRAC = 0.35
MIN_AREA_FRAC = 0.00005

VEHICLE_PREFIX = "vehicle."
WALKER_PREFIX = "walker.pedestrian."
TLIGHT_TYPE = "traffic.traffic_light"
SIGN_PREFIXES = ("traffic.stop", "traffic.speed_limit", "traffic.yield", "traffic.warning")

CLASS_NAMES = ["vehicle", "pedestrian", "traffic_light", "traffic_sign"]


# ---------------------------
# Utilities
# ---------------------------
def ensure_dirs():
    IMG_DIR.mkdir(parents=True, exist_ok=True)
    LAB_DIR.mkdir(parents=True, exist_ok=True)
    if SAVE_DEBUG_OVERLAYS:
        DBG_DIR.mkdir(parents=True, exist_ok=True)


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def build_intrinsics(w, h, fov_deg):
    f = w / (2.0 * math.tan(math.radians(fov_deg) / 2.0))
    K = np.array([
        [f, 0, w / 2.0],
        [0, f, h / 2.0],
        [0, 0, 1.0]
    ], dtype=np.float32)
    return K


def rotation_matrix_from_euler(roll, pitch, yaw):
    cr = math.cos(roll)
    sr = math.sin(roll)
    cp = math.cos(pitch)
    sp = math.sin(pitch)
    cy = math.cos(yaw)
    sy = math.sin(yaw)

    R_yaw = np.array([[cy, -sy, 0],
                      [sy,  cy, 0],
                      [0,    0, 1]], dtype=np.float32)

    R_pitch = np.array([[ cp, 0, sp],
                        [  0, 1,  0],
                        [-sp, 0, cp]], dtype=np.float32)

    R_roll = np.array([[1,  0,   0],
                       [0, cr, -sr],
                       [0, sr,  cr]], dtype=np.float32)

    return R_yaw.dot(R_pitch).dot(R_roll)


def transform_to_matrix(transform):
    loc = transform.location
    rot = transform.rotation

    roll = math.radians(rot.roll)
    pitch = math.radians(rot.pitch)
    yaw = math.radians(rot.yaw)

    R = rotation_matrix_from_euler(roll, pitch, yaw)
    T = np.array([loc.x, loc.y, loc.z], dtype=np.float32).reshape(3, 1)

    M = np.eye(4, dtype=np.float32)
    M[:3, :3] = R
    M[:3, 3:4] = T
    return M


def world_to_camera_matrix(camera_transform):
    cam_to_world = transform_to_matrix(camera_transform)
    return np.linalg.inv(cam_to_world).astype(np.float32)


def project_world_point(world_pt, world_to_cam, K):
    p = np.array([world_pt.x, world_pt.y, world_pt.z, 1.0], dtype=np.float32)
    pc = world_to_cam.dot(p)

    depth = float(pc[0])
    if depth <= MIN_DEPTH or depth > MAX_DEPTH:
        return None

    x = float(pc[0])
    y = float(pc[1])
    z = float(pc[2])

    fx = float(K[0, 0])
    fy = float(K[1, 1])
    cx = float(K[0, 2])
    cy = float(K[1, 2])

    u = cx + fx * (y / x)
    v = cy - fy * (z / x)
    return float(u), float(v), depth


def get_actor_class_id(actor):
    tid = actor.type_id
    if tid.startswith(VEHICLE_PREFIX):
        return 0
    if tid.startswith(WALKER_PREFIX):
        return 1
    if tid == TLIGHT_TYPE or tid.startswith("traffic.traffic_light"):
        return 2
    for p in SIGN_PREFIXES:
        if tid.startswith(p):
            return 3
    return None


def get_actor_bbox_and_transform(actor):
    """
    Returns (carla.BoundingBox, carla.Transform) for an actor.

    Some actors (e.g., TrafficLight) may not expose bounding_box in some CARLA versions.
    For those, we build a small approximate bbox around the actor location.
    """
    tf = actor.get_transform()

    # If actor has bounding_box attribute, use it.
    bb = getattr(actor, "bounding_box", None)
    if bb is not None:
        return bb, tf

    # Fallbacks for traffic lights & signs (approx extents)
    tid = actor.type_id

    if "traffic_light" in tid:
        # Approximate traffic light size (meters)
        # center slightly above base location
        bb = carla.BoundingBox(
            carla.Location(x=0.0, y=0.0, z=2.5),
            carla.Vector3D(x=0.25, y=0.25, z=1.0)
        )
        return bb, tf

    if tid.startswith(SIGN_PREFIXES):
        # Approximate sign size
        bb = carla.BoundingBox(
            carla.Location(x=0.0, y=0.0, z=1.5),
            carla.Vector3D(x=0.35, y=0.15, z=0.6)
        )
        return bb, tf

    # Generic fallback: tiny box at actor origin
    bb = carla.BoundingBox(
        carla.Location(x=0.0, y=0.0, z=1.0),
        carla.Vector3D(x=0.2, y=0.2, z=0.5)
    )
    return bb, tf


def bbox_vertices_world(bb, actor_tf):
    """
    Get world vertices for either:
      - true actor bounding_box (already in actor local space), or
      - our fallback bounding box (also defined in actor local space).

    Approach: create a temp bounding box with same extent/location and use
    get_world_vertices with actor_tf.
    """
    tmp = carla.BoundingBox(bb.location, bb.extent)
    return tmp.get_world_vertices(actor_tf)


def actor_2d_bbox(actor, world_to_cam, K, img_w, img_h):
    bb, tf = get_actor_bbox_and_transform(actor)
    verts = bbox_vertices_world(bb, tf)

    pts = []
    depths = []

    for v in verts:
        proj = project_world_point(v, world_to_cam, K)
        if proj is None:
            continue
        u, vv, d = proj
        pts.append((u, vv))
        depths.append(d)

    if len(pts) < 4:
        return None

    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]

    x1 = clamp(int(min(xs)), 0, img_w - 1)
    y1 = clamp(int(min(ys)), 0, img_h - 1)
    x2 = clamp(int(max(xs)), 0, img_w - 1)
    y2 = clamp(int(max(ys)), 0, img_h - 1)

    w = x2 - x1
    h = y2 - y1
    if w < MIN_BOX_PX or h < MIN_BOX_PX:
        return None

    area = w * h
    frame_area = img_w * img_h
    area_frac = area / float(frame_area)

    if area_frac > MAX_AREA_FRAC or area_frac < MIN_AREA_FRAC:
        return None

    if w > img_w * 0.95 or h > img_h * 0.95:
        return None

    if len(depths) > 0:
        md = float(np.median(depths))
        if md < MIN_DEPTH or md > MAX_DEPTH:
            return None

    return x1, y1, x2, y2


def to_yolo_line(class_id, x1, y1, x2, y2, img_w, img_h):
    bw = (x2 - x1) / float(img_w)
    bh = (y2 - y1) / float(img_h)
    cx = (x1 + x2) / 2.0 / float(img_w)
    cy = (y1 + y2) / 2.0 / float(img_h)
    return f"{class_id} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}"


def draw_debug(frame_bgr, bboxes):
    colors = {0: (0, 255, 0), 1: (0, 0, 255), 2: (0, 255, 255), 3: (255, 0, 255)}
    for cls, x1, y1, x2, y2 in bboxes:
        c = colors.get(cls, (255, 255, 255))
        cv2.rectangle(frame_bgr, (x1, y1), (x2, y2), c, 2)
        cv2.putText(frame_bgr, CLASS_NAMES[cls], (x1, max(15, y1 - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, c, 1, cv2.LINE_AA)
    return frame_bgr


def main():
    ensure_dirs()

    print("Connecting to CARLA...")
    client = carla.Client("localhost", 2000)
    client.set_timeout(20.0)

    world = client.get_world()
    print("Loading map {}...".format(TOWN))
    world = client.load_world(TOWN)
    time.sleep(2.0)

    original_settings = world.get_settings()
    settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = FIXED_DT
    settings.no_rendering_mode = False
    world.apply_settings(settings)

    tm = client.get_trafficmanager(8000)
    tm.set_synchronous_mode(True)

    blueprint_library = world.get_blueprint_library()
    spawn_points = world.get_map().get_spawn_points()

    actors_to_destroy = []

    ego_bp = blueprint_library.filter("vehicle.tesla.model3")[0]
    ego = world.spawn_actor(ego_bp, random.choice(spawn_points))
    ego.set_autopilot(True, tm.get_port())
    actors_to_destroy.append(ego)
    print("Ego vehicle spawned.")

    cam_bp = blueprint_library.find("sensor.camera.rgb")
    cam_bp.set_attribute("image_size_x", str(IMG_W))
    cam_bp.set_attribute("image_size_y", str(IMG_H))
    cam_bp.set_attribute("fov", str(FOV))
    cam_tf = carla.Transform(carla.Location(x=2.0, z=1.4))
    camera = world.spawn_actor(cam_bp, cam_tf, attach_to=ego)
    actors_to_destroy.append(camera)
    print("Camera attached.")

    # NPC vehicles
    vehicle_bps = list(blueprint_library.filter("vehicle.*"))
    npc = []
    for sp in random.sample(spawn_points, min(N_NPC_VEHICLES, len(spawn_points))):
        if sp.location.distance(ego.get_location()) < 5:
            continue
        bp = random.choice(vehicle_bps)
        try:
            v = world.spawn_actor(bp, sp)
            v.set_autopilot(True, tm.get_port())
            npc.append(v)
            actors_to_destroy.append(v)
        except Exception:
            pass
    print("Spawned {} NPC vehicles.".format(len(npc)))

    # Walkers
    walkers = []
    controllers = []
    walker_bps = list(blueprint_library.filter("walker.pedestrian.*"))
    controller_bp = blueprint_library.find("controller.ai.walker")
    for _ in range(N_WALKERS):
        loc = world.get_random_location_from_navigation()
        if not loc:
            continue
        bp = random.choice(walker_bps)
        try:
            w = world.spawn_actor(bp, carla.Transform(loc))
            walkers.append(w)
            actors_to_destroy.append(w)

            ctrl = world.spawn_actor(controller_bp, carla.Transform(), attach_to=w)
            controllers.append(ctrl)
            actors_to_destroy.append(ctrl)

            ctrl.start()
            dest = world.get_random_location_from_navigation()
            if dest:
                ctrl.go_to_location(dest)
            ctrl.set_max_speed(1.4)
        except Exception:
            pass
    print("Spawned {} walkers.".format(len(walkers)))

    K = build_intrinsics(IMG_W, IMG_H, FOV)
    latest = {"img": None}

    def on_image(img):
        arr = np.frombuffer(img.raw_data, dtype=np.uint8)
        arr = arr.reshape((img.height, img.width, 4))[:, :, :3]
        latest["img"] = arr.copy()

    camera.listen(on_image)

    print("Collecting CARLA dataset... Press Ctrl+C to stop.")
    time.sleep(0.5)

    saved = 0
    try:
        while saved < N_FRAMES:
            world.tick()

            if latest["img"] is None:
                continue

            frame_bgr = latest["img"]
            world2cam = world_to_camera_matrix(camera.get_transform())

            # Actor filters
            actors = world.get_actors()
            relevant = []
            relevant.extend(list(actors.filter("vehicle.*")))
            relevant.extend(list(actors.filter("walker.pedestrian.*")))
            relevant.extend(list(actors.filter("traffic.traffic_light*")))
            relevant.extend(list(actors.filter("traffic.stop*")))
            relevant.extend(list(actors.filter("traffic.speed_limit*")))
            relevant.extend(list(actors.filter("traffic.yield*")))
            relevant.extend(list(actors.filter("traffic.warning*")))

            bboxes = []
            for a in relevant:
                if a.id == ego.id:
                    continue
                cls = get_actor_class_id(a)
                if cls is None:
                    continue
                bbox = actor_2d_bbox(a, world2cam, K, IMG_W, IMG_H)
                if bbox is None:
                    continue
                x1, y1, x2, y2 = bbox
                bboxes.append((cls, x1, y1, x2, y2))

            idx = saved + 1
            img_path = IMG_DIR / "{:06d}.jpg".format(idx)
            lab_path = LAB_DIR / "{:06d}.txt".format(idx)

            cv2.imwrite(str(img_path), frame_bgr)

            lines = [to_yolo_line(cls, x1, y1, x2, y2, IMG_W, IMG_H) for cls, x1, y1, x2, y2 in bboxes]
            with open(lab_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

            if SAVE_DEBUG_OVERLAYS and (idx % DEBUG_EVERY_N == 0):
                dbg = draw_debug(frame_bgr.copy(), bboxes)
                cv2.imwrite(str(DBG_DIR / "{:06d}.jpg".format(idx)), dbg)

            saved += 1
            if saved % 50 == 0:
                print("Saved {}".format(saved))

        print("Done collecting.")

    except KeyboardInterrupt:
        print("\nStopped by user.")
    except Exception:
        print("\n[ERROR] Script crashed. Full traceback below:\n")
        print(traceback.format_exc())
    finally:
        print("Cleaning up...")
        try:
            camera.stop()
        except Exception:
            pass

        for c in controllers:
            try:
                c.stop()
            except Exception:
                pass

        for a in reversed(actors_to_destroy):
            try:
                a.destroy()
            except Exception:
                pass

        try:
            world.apply_settings(original_settings)
            tm.set_synchronous_mode(False)
        except Exception:
            pass

        print("Cleanup complete.")


if __name__ == "__main__":
    main()