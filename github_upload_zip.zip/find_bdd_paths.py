# -*- coding: utf-8 -*-
import os
from pathlib import Path

YOLOV5_DIR = r"c:\users\CARLACODES\1_code\yolov5"
BDD_ROOT = os.path.join(YOLOV5_DIR, r"datasets\bdd100k")

def main():
    print("BDD_ROOT =", BDD_ROOT)
    if not os.path.exists(BDD_ROOT):
        print("[ERROR] BDD_ROOT does not exist. Create it and copy BDD100K there.")
        return

    # Show top-level contents
    print("\nTop-level contents:")
    for p in sorted(Path(BDD_ROOT).glob("*")):
        print(" -", p.name)

    # Find any det json files
    print("\nSearching for JSON files that look like detection labels...")
    json_hits = []
    for p in Path(BDD_ROOT).rglob("*.json"):
        name = p.name.lower()
        if "det" in name and ("train" in name or "val" in name):
            json_hits.append(str(p))
    if not json_hits:
        print("[WARN] No detection JSONs found under BDD_ROOT.")
        print("Expected something like: labels\\det_20\\det_train.json and det_val.json")
    else:
        for j in json_hits[:50]:
            print(" -", j)
        if len(json_hits) > 50:
            print(" ... (more omitted)")

    # Find image folders
    print("\nSearching for image folders...")
    candidates = []
    for p in Path(BDD_ROOT).rglob("*"):
        if p.is_dir() and p.name.lower() in ("train", "val"):
            parent = str(p.parent).lower()
            if "images" in parent and ("100k" in parent or "bdd100k" in parent):
                candidates.append(str(p))
    if not candidates:
        print("[WARN] No obvious images/train and images/val found under BDD_ROOT.")
        print("Expected: images\\100k\\train and images\\100k\\val")
    else:
        for c in candidates[:50]:
            print(" -", c)

if __name__ == "__main__":
    main()