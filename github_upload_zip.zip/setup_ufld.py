import os
import urllib.request
import zipfile

base_dir = r"c:\users\CARLACODES\1_code"
ufld_dir = os.path.join(base_dir, "ultra_fast_lane")

# Create folder
if not os.path.exists(ufld_dir):
    os.makedirs(ufld_dir)
    print("Created: " + ufld_dir)

# Download Ultra-Fast Lane Detection model (TuSimple)
model_url = "https://github.com/cfzd/Ultra-Fast-Lane-Detection/releases/download/v1.0/tusimple_18.pth"
model_path = os.path.join(ufld_dir, "tusimple_18.pth")

print("Downloading Ultra-Fast Lane Detection model...")
print("This may take a few minutes...")

try:
    urllib.request.urlretrieve(model_url, model_path)
    print("Model downloaded: " + model_path)
except Exception as e:
    print("Error downloading: " + str(e))
    print("")
    print("Please download manually from:")
    print("https://github.com/cfzd/Ultra-Fast-Lane-Detection/releases")

print("")
print("Done!")
print("")
print("Model saved to: " + ufld_dir)